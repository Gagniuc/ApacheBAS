/* ProgramsScan.exe - compact Win32 helper for ApacheBAS Programs Explorer.
   Freestanding C, no CRT, no import library. Win32 APIs are resolved at runtime
   from the process module list, so the final PE stays very small. */

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
typedef int             i32;
typedef void*           HANDLE;
typedef char*           LPSTR;
typedef const char*     LPCSTR;
typedef void*           LPVOID;
typedef const void*     LPCVOID;
typedef i32             BOOL;

typedef struct {
    u32 dwFileAttributes;
    u32 ftCreationTimeLow, ftCreationTimeHigh;
    u32 ftLastAccessTimeLow, ftLastAccessTimeHigh;
    u32 ftLastWriteTimeLow, ftLastWriteTimeHigh;
    u32 nFileSizeHigh, nFileSizeLow;
    u32 dwReserved0, dwReserved1;
    char cFileName[260];
    char cAlternateFileName[14];
} WIN32_FIND_DATAA;

typedef struct {
    u32 cb;
    LPSTR lpReserved;
    LPSTR lpDesktop;
    LPSTR lpTitle;
    u32 dwX, dwY, dwXSize, dwYSize;
    u32 dwXCountChars, dwYCountChars;
    u32 dwFillAttribute;
    u32 dwFlags;
    u16 wShowWindow;
    u16 cbReserved2;
    u8* lpReserved2;
    HANDLE hStdInput, hStdOutput, hStdError;
} STARTUPINFOA;

typedef struct {
    HANDLE hProcess;
    HANDLE hThread;
    u32 dwProcessId;
    u32 dwThreadId;
} PROCESS_INFORMATION;

#define STDCALL __attribute__((stdcall))
typedef u32    (STDCALL *pGetEnvironmentVariableA)(LPCSTR, LPSTR, u32);
typedef u32    (STDCALL *pGetModuleFileNameA)(HANDLE, LPSTR, u32);
typedef LPSTR  (STDCALL *pGetCommandLineA)(void);
typedef HANDLE (STDCALL *pGetStdHandle)(i32);
typedef BOOL   (STDCALL *pWriteFile)(HANDLE, LPCVOID, u32, u32*, LPVOID);
typedef HANDLE (STDCALL *pFindFirstFileA)(LPCSTR, WIN32_FIND_DATAA*);
typedef BOOL   (STDCALL *pFindNextFileA)(HANDLE, WIN32_FIND_DATAA*);
typedef BOOL   (STDCALL *pFindClose)(HANDLE);
typedef BOOL   (STDCALL *pCreateProcessA)(LPCSTR, LPSTR, LPVOID, LPVOID, BOOL, u32, LPVOID, LPCSTR, STARTUPINFOA*, PROCESS_INFORMATION*);
typedef BOOL   (STDCALL *pCloseHandle)(HANDLE);
typedef void   (STDCALL *pExitProcess)(u32);

static pGetEnvironmentVariableA kGetEnvironmentVariableA;
static pGetModuleFileNameA      kGetModuleFileNameA;
static pGetCommandLineA         kGetCommandLineA;
static pGetStdHandle            kGetStdHandle;
static pWriteFile               kWriteFile;
static pFindFirstFileA          kFindFirstFileA;
static pFindNextFileA           kFindNextFileA;
static pFindClose               kFindClose;
static pCreateProcessA          kCreateProcessA;
static pCloseHandle             kCloseHandle;
static pExitProcess             kExitProcess;

#define PATH_CAP 4096
#define MAX_DEPTH 64
#define FILE_ATTRIBUTE_DIRECTORY 0x10u
#define INVALID_HANDLE_VALUE ((HANDLE)(i32)-1)
#define STD_OUTPUT_HANDLE (-11)

static char root_path[PATH_CAP];
static char module_path[PATH_CAP];
static char arg_path[PATH_CAP];
static char work_path[PATH_CAP];
static char cmd_line[PATH_CAP * 2];
static char dir_stack[MAX_DEPTH][PATH_CAP];
static u32 dir_count;
static u32 program_count;
static HANDLE stdout_handle;

static u8 lower8(u8 c) { return (c >= 'A' && c <= 'Z') ? (u8)(c + 32) : c; }
static u32 slen(const char* s) { u32 n=0; while (s[n]) n++; return n; }
static int seqi(const char* a, const char* b) {
    while (*a && *b) { if (lower8((u8)*a) != lower8((u8)*b)) return 0; a++; b++; }
    return *a == 0 && *b == 0;
}
static int ends_exe(const char* s) {
    u32 n=slen(s); if (n<4) return 0;
    return s[n-4]=='.' && lower8((u8)s[n-3])=='e' && lower8((u8)s[n-2])=='x' && lower8((u8)s[n-1])=='e';
}
static void zero_bytes(void* p, u32 n) { u8* d=(u8*)p; while(n--) *d++=0; }
static int copy_s(char* d, u32 cap, const char* s) {
    u32 i=0; if (!cap) return 0;
    while (s[i]) { if (i+1>=cap) { d[0]=0; return 0; } d[i]=s[i]; i++; }
    d[i]=0; return 1;
}
static int append_s(char* d, u32 cap, const char* s) {
    u32 n=slen(d), i=0; if (n>=cap) return 0;
    while(s[i]) { if(n+i+1>=cap) return 0; d[n+i]=s[i]; i++; }
    d[n+i]=0; return 1;
}
static void slash_back(char* s) { while(*s){ if(*s=='/') *s='\\'; s++; } }
static void slash_forward_copy(char* d, u32 cap, const char* s) {
    u32 i=0; while(s[i] && i+1<cap){ char c=s[i]; d[i]=(c=='\\')?'/':c; i++; } d[i]=0;
}
static void trim_trailing_slash(char* s) {
    u32 n=slen(s);
    while(n>3 && (s[n-1]=='\\' || s[n-1]=='/')) { s[--n]=0; }
}
static int path_parent(char* s) {
    u32 n=slen(s); while(n && s[n-1]!='\\' && s[n-1]!='/') n--;
    if(!n) return 0;
    while(n>3 && (s[n-1]=='\\'||s[n-1]=='/')) n--;
    s[n]=0; return 1;
}
static const char* base_name(const char* s) {
    const char* b=s; while(*s){ if(*s=='\\'||*s=='/') b=s+1; s++; } return b;
}
static int full_same_i(const char* a,const char* b){ return seqi(a,b); }

/* PEB module walker: x86 offsets for PEB/LDR_DATA_TABLE_ENTRY. */
static void* peb_ptr(void) {
    void* p;
    __asm__ volatile ("movl %%fs:0x30,%0" : "=r"(p));
    return p;
}
static int unicode_name_eq_ascii(const u16* w, u16 bytes, const char* a) {
    u32 n=(u32)bytes/2, i=0;
    while(a[i]) { if(i>=n) return 0; if(lower8((u8)w[i]) != lower8((u8)a[i])) return 0; i++; }
    return i==n;
}
static void* find_module_ascii(const char* name) {
    u8* peb=(u8*)peb_ptr();
    u8* ldr=*(u8**)(peb+0x0c);
    u8* head=ldr+0x0c; /* InLoadOrderModuleList */
    u8* e=*(u8**)head;
    while(e && e!=head) {
        u16 len=*(u16*)(e+0x2c);
        u16* buf=*(u16**)(e+0x30);
        if(buf && unicode_name_eq_ascii(buf,len,name)) return *(void**)(e+0x18);
        e=*(u8**)e;
    }
    return 0;
}
static int ascii_eq(const char* a,const char* b){ while(*a&&*b){ if(*a!=*b)return 0;a++;b++;} return *a==0&&*b==0; }

static void* resolve_export_depth(void* module, const char* name, int depth) {
    u8* base=(u8*)module; u32 pe, exp_rva, exp_size, n, names_rva, ord_rva, funcs_rva, i;
    if(!base || depth>4) return 0;
    if(*(u16*)base != 0x5a4d) return 0;
    pe=*(u32*)(base+0x3c);
    if(*(u32*)(base+pe) != 0x00004550) return 0;
    exp_rva=*(u32*)(base+pe+0x78); exp_size=*(u32*)(base+pe+0x7c);
    if(!exp_rva) return 0;
    u8* ed=base+exp_rva;
    n=*(u32*)(ed+24); funcs_rva=*(u32*)(ed+28); names_rva=*(u32*)(ed+32); ord_rva=*(u32*)(ed+36);
    u32* names=(u32*)(base+names_rva); u16* ords=(u16*)(base+ord_rva); u32* funcs=(u32*)(base+funcs_rva);
    for(i=0;i<n;i++) {
        const char* en=(const char*)(base+names[i]);
        if(ascii_eq(en,name)) {
            u32 rva=funcs[ords[i]];
            if(rva>=exp_rva && rva<exp_rva+exp_size) {
                const char* fwd=(const char*)(base+rva); char mod[80]; char fn[96]; u32 m=0,j=0;
                while(fwd[m] && fwd[m]!='.' && m+5<sizeof(mod)){ mod[m]=fwd[m]; m++; }
                if(fwd[m]!='.') return 0; mod[m]=0; append_s(mod,sizeof(mod),".dll"); m++;
                if(fwd[m]=='#') return 0;
                while(fwd[m] && j+1<sizeof(fn)) fn[j++]=fwd[m++]; fn[j]=0;
                void* fm=find_module_ascii(mod); if(!fm) return 0;
                return resolve_export_depth(fm,fn,depth+1);
            }
            return (void*)(base+rva);
        }
    }
    return 0;
}
static void* resolve_export(void* module,const char* name){return resolve_export_depth(module,name,0);}

static int load_apis(void) {
    void* k=find_module_ascii("kernel32.dll");
    if(!k) return 0;
#define R(dst,typ,nm) do{ dst=(typ)resolve_export(k,nm); if(!dst) return 0; }while(0)
    R(kGetEnvironmentVariableA,pGetEnvironmentVariableA,"GetEnvironmentVariableA");
    R(kGetModuleFileNameA,pGetModuleFileNameA,"GetModuleFileNameA");
    R(kGetCommandLineA,pGetCommandLineA,"GetCommandLineA");
    R(kGetStdHandle,pGetStdHandle,"GetStdHandle");
    R(kWriteFile,pWriteFile,"WriteFile");
    R(kFindFirstFileA,pFindFirstFileA,"FindFirstFileA");
    R(kFindNextFileA,pFindNextFileA,"FindNextFileA");
    R(kFindClose,pFindClose,"FindClose");
    R(kCreateProcessA,pCreateProcessA,"CreateProcessA");
    R(kCloseHandle,pCloseHandle,"CloseHandle");
    R(kExitProcess,pExitProcess,"ExitProcess");
#undef R
    return 1;
}

static void out_raw(const char* s) {
    u32 n=slen(s), done=0; if(!stdout_handle) return; kWriteFile(stdout_handle,s,n,&done,0);
}
static void out_sanitized(const char* s) {
    char b[256]; u32 n=0; while(*s){ char c=*s++; if(c=='\r'||c=='\n') c=' '; b[n++]=c; if(n==sizeof(b)){ u32 d=0;kWriteFile(stdout_handle,b,n,&d,0);n=0; } }
    if(n){u32 d=0;kWriteFile(stdout_handle,b,n,&d,0);}
}
static void out_u32(u32 v) {
    char b[16]; u32 i=0,j; if(v==0){out_raw("0");return;} while(v && i<sizeof(b)){ b[i++]=(char)('0'+(v%10)); v/=10; }
    for(j=0;j<i/2;j++){char c=b[j];b[j]=b[i-1-j];b[i-1-j]=c;} b[i]=0; out_raw(b);
}
static void fail_scan(const char* m,u32 code){ out_raw("ERROR=");out_sanitized(m);out_raw("\r\n");kExitProcess(code); }
static void fail_run(const char* m){ out_raw("RUN_OK=0\r\nRUN_ERROR=");out_sanitized(m);out_raw("\r\n");kExitProcess(4); }

static int determine_root(void) {
    u32 n=kGetEnvironmentVariableA("DOCUMENT_ROOT",root_path,PATH_CAP);
    if(n>0 && n<PATH_CAP){ slash_back(root_path);trim_trailing_slash(root_path);return 1; }
    n=kGetEnvironmentVariableA("CONTEXT_DOCUMENT_ROOT",root_path,PATH_CAP);
    if(n>0 && n<PATH_CAP){ slash_back(root_path);trim_trailing_slash(root_path);return 1; }
    n=kGetEnvironmentVariableA("SCRIPT_FILENAME",root_path,PATH_CAP);
    if(!(n>0&&n<PATH_CAP)) n=kGetEnvironmentVariableA("PATH_TRANSLATED",root_path,PATH_CAP);
    if(n>0&&n<PATH_CAP){ slash_back(root_path); if(path_parent(root_path) && path_parent(root_path)){trim_trailing_slash(root_path);return 1;} }
    n=kGetModuleFileNameA(0,root_path,PATH_CAP);
    if(n>0&&n<PATH_CAP){ slash_back(root_path); if(path_parent(root_path)&&path_parent(root_path)&&path_parent(root_path)){trim_trailing_slash(root_path);return 1;} }
    root_path[0]=0; return 0;
}

static int is_dots(const char* n){ return (n[0]=='.'&&n[1]==0)||(n[0]=='.'&&n[1]=='.'&&n[2]==0); }
static int build_child(char* dst,u32 cap,const char* dir,const char* name){ if(!copy_s(dst,cap,dir))return 0;u32 n=slen(dst);if(n&&dst[n-1]!='\\'){if(!append_s(dst,cap,"\\"))return 0;}return append_s(dst,cap,name); }
static int build_search(char* dst,u32 cap,const char* dir){ if(!copy_s(dst,cap,dir))return 0;u32 n=slen(dst);if(n&&dst[n-1]!='\\'){if(!append_s(dst,cap,"\\"))return 0;}return append_s(dst,cap,"*"); }

static void emit_relative(const char* full) {
    u32 rn=slen(root_path); const char* p=full;
    if(rn && full_same_i(root_path,full)) p=full+rn;
    else { u32 i=0; while(i<rn && lower8((u8)root_path[i])==lower8((u8)full[i])) i++; if(i==rn) p=full+rn; }
    while(*p=='\\'||*p=='/') p++;
    out_raw("EXE=");
    while(*p){ char c=*p++; char one[2]; one[0]=(c=='\\')?'/':c;one[1]=0;out_raw(one); }
    out_raw("\r\n");
}

static void scan_dir(u32 depth,int emit) {
    WIN32_FIND_DATAA fd; HANDLE h;
    if(depth>=MAX_DEPTH) return;
    if(!build_search(work_path,PATH_CAP,dir_stack[depth])) return;
    h=kFindFirstFileA(work_path,&fd); if(h==INVALID_HANDLE_VALUE) return;
    if(!emit) dir_count++;
    do {
        const char* name=fd.cFileName;
        if(is_dots(name)) continue;
        if(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            if(depth+1<MAX_DEPTH && build_child(dir_stack[depth+1],PATH_CAP,dir_stack[depth],name)) scan_dir(depth+1,emit);
        } else if(ends_exe(name)) {
            if(!build_child(work_path,PATH_CAP,dir_stack[depth],name)) continue;
            if(module_path[0] && full_same_i(work_path,module_path)) continue;
            if(!emit) program_count++; else emit_relative(work_path);
        }
    } while(kFindNextFileA(h,&fd));
    kFindClose(h);
}

static int has_bad_parent_segment(const char* s) {
    const char* p=s; while(*p){ const char* seg=p; u32 n=0; while(*p&&*p!='\\'&&*p!='/'){p++;n++;} if(n==2&&seg[0]=='.'&&seg[1]=='.')return 1; if(*p)p++; } return 0;
}
static int valid_requested(char* s) {
    u32 n; if(!s[0]||s[0]=='\\'||s[0]=='/')return 0; if(has_bad_parent_segment(s))return 0;
    for(n=0;s[n];n++){ if(s[n]==':'||s[n]=='"'||(u8)s[n]<32)return 0; if(s[n]=='/')s[n]='\\'; }
    return ends_exe(s);
}
static int parse_second_arg(char* out,u32 cap) {
    char* p=kGetCommandLineA(); u32 i=0;
    if(!p)return 0; while(*p==' '||*p=='\t')p++;
    if(*p=='"'){p++;while(*p&&*p!='"')p++;if(*p=='"')p++;} else {while(*p&&*p!=' '&&*p!='\t')p++;}
    while(*p==' '||*p=='\t')p++; if(!*p)return 0;
    if(*p=='"'){p++;while(*p&&*p!='"'&&i+1<cap)out[i++]=*p++;}else{while(*p&&*p!=' '&&*p!='\t'&&i+1<cap)out[i++]=*p++;}
    out[i]=0; return i!=0;
}
static void launch_requested(void) {
    STARTUPINFOA si; PROCESS_INFORMATION pi; u32 i,n;
    if(!valid_requested(arg_path)) fail_run("Invalid executable path");
    if(!build_child(work_path,PATH_CAP,root_path,arg_path)) fail_run("Executable path is too long");
    if(module_path[0] && full_same_i(work_path,module_path)) fail_run("Refusing to start the Programs Explorer helper");
    if(!copy_s(cmd_line,sizeof(cmd_line),"\"" ) || !append_s(cmd_line,sizeof(cmd_line),work_path) || !append_s(cmd_line,sizeof(cmd_line),"\"")) fail_run("Command line is too long");
    copy_s(dir_stack[0],PATH_CAP,work_path); path_parent(dir_stack[0]);
    zero_bytes(&si,sizeof(si));zero_bytes(&pi,sizeof(pi));si.cb=sizeof(si);
    if(!kCreateProcessA(work_path,cmd_line,0,0,0,0,0,dir_stack[0],&si,&pi)) fail_run("CreateProcess failed");
    if(pi.hThread)kCloseHandle(pi.hThread);if(pi.hProcess)kCloseHandle(pi.hProcess);
    out_raw("RUN_OK=1\r\nRUN_PATH=");
    n=slen(arg_path);for(i=0;i<n;i++){char one[2];one[0]=(arg_path[i]=='\\')?'/':arg_path[i];one[1]=0;out_raw(one);}out_raw("\r\n");
    kExitProcess(0);
}

void entry(void) {
    if(!load_apis()) { for(;;){} }
    stdout_handle=kGetStdHandle(STD_OUTPUT_HANDLE);
    module_path[0]=0; kGetModuleFileNameA(0,module_path,PATH_CAP); slash_back(module_path);
    if(!determine_root()) fail_scan("Cannot determine Apache document root",2);
    if(parse_second_arg(arg_path,sizeof(arg_path))) launch_requested();
    copy_s(dir_stack[0],PATH_CAP,root_path);dir_count=0;program_count=0;scan_dir(0,0);
    out_raw("ROOT=");slash_forward_copy(work_path,PATH_CAP,root_path);out_sanitized(work_path);out_raw("\r\nDIRCOUNT=");out_u32(dir_count);out_raw("\r\nPROGRAMCOUNT=");out_u32(program_count);out_raw("\r\n");
    copy_s(dir_stack[0],PATH_CAP,root_path);scan_dir(0,1);
    kExitProcess(0);
}
