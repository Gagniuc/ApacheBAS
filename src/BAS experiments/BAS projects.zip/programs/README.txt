ApacheBAS Programs Explorer - compact helper edition

This package is functionally equivalent to the working v2 package, but replaces
the Go ProgramsScan.exe with a tiny freestanding Win32 C implementation.

Files:
  programs.bas
  tools\ProgramsScan.exe
  src\ProgramsScan.c

ProgramsScan.exe:
  - PE32 / Intel i386
  - 8,704 bytes
  - no C runtime
  - no static Windows import library
  - Win32 APIs resolved at runtime from loaded system modules
  - scans Apache DOCUMENT_ROOT recursively for .exe files
  - launches a selected .exe from DOCUMENT_ROOT
  - preserves the same text protocol used by programs.bas

Installation:
  Replace only tools\ProgramsScan.exe in the already-working Programs Explorer.
  programs.bas is included for completeness and is unchanged from the working v2.

Build used in the ChatGPT Linux environment:
  clang --target=i686-windows-gnu -Os -ffreestanding -fno-builtin \
        -fno-stack-protector -fno-asynchronous-unwind-tables \
        -fomit-frame-pointer -fno-ident -c ProgramsScan.c -o ProgramsScan.o

  ld -m i386pe --entry=_entry --subsystem console --file-alignment=512 \
     --section-alignment=4096 -s -o ProgramsScan.exe ProgramsScan.o

No external runtime is required by the helper.
