<?bas
IF GET_API$ = "1" THEN GOTO API_MODE
GOTO PAGE_MODE

API_MODE:
PRINT "@@CONTENT-TYPE text/plain; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
EXEC "netstat.exe", "-ano"
IF EXEC_OK = 0 THEN GOTO API_ERROR
PRINT EXEC_OUTPUT$
END

API_ERROR:
PRINT "ERROR|"; EXEC_ERROR$; " Use ApacheBAS v0.1.34.1 or newer."
END

PAGE_MODE:
PRINT "@@CONTENT-TYPE text/html; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ApacheBAS Netstat Monitor</title>
<style>
:root{color-scheme:dark;--bg:#050b08;--panel:#09140e;--panel2:#0d1d14;--line:#1c5f3d;--accent:#68f5a5;--text:#effff6;--muted:#9bc8ae;--danger:#ff8383;--warn:#ffe28a}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Consolas,"Courier New",monospace}.app{min-height:100vh;display:grid;grid-template-rows:auto auto auto 1fr auto}.top{display:flex;align-items:center;gap:14px;padding:14px 18px;border-bottom:1px solid var(--line);background:#030705}.lights{display:flex;gap:7px}.lights i{width:11px;height:11px;border:1px solid var(--line);border-radius:50%;display:block}.title{font-weight:700;letter-spacing:.08em}.tag{font-size:11px;color:var(--accent);border:1px solid var(--line);padding:4px 8px;border-radius:20px}.toolbar{display:grid;grid-template-columns:minmax(250px,1fr) 190px auto auto;gap:10px;padding:12px 18px;border-bottom:1px solid #103722;background:var(--panel)}input,select,button{font:inherit;border:1px solid var(--line);background:#06100b;color:var(--text);padding:10px 12px}input:focus,select:focus{outline:1px solid var(--accent)}button{cursor:pointer;color:var(--accent)}button:hover{background:#10271a}.cards{display:grid;grid-template-columns:repeat(5,minmax(110px,1fr));gap:10px;padding:12px 18px;border-bottom:1px solid #103722}.card{border:1px solid var(--line);background:var(--panel);padding:12px}.card b{display:block;color:var(--accent);font-size:20px;margin-top:4px}.card span{color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.06em}.main{padding:16px 18px;overflow:auto}.summary{display:flex;justify-content:space-between;gap:20px;margin-bottom:12px;color:var(--muted);font-size:13px}.tablewrap{border:1px solid var(--line);background:var(--panel);overflow:auto;min-height:360px}table{width:100%;border-collapse:collapse;table-layout:fixed}th,td{text-align:left;padding:9px 11px;border-bottom:1px solid #123722;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}th{position:sticky;top:0;background:#0c2015;color:var(--accent);z-index:2}tbody tr:hover{background:#10261a}.proto{width:8%}.local{width:27%}.remote{width:27%}.state{width:22%}.pid{width:16%;text-align:right}.empty,.error{padding:28px;color:var(--muted)}.error{color:var(--danger)}.warning{display:none;margin:12px 18px 0;padding:10px 12px;border:1px solid #7b6424;color:var(--warn);background:#221c08}.footer{padding:10px 18px;border-top:1px solid var(--line);color:var(--muted);font-size:12px}.dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--accent);margin-right:7px}.paused{background:#d7a536}.bad{background:var(--danger)}.state-listening{color:#8bd2ff}.state-established{color:var(--accent)}.state-time_wait,.state-close_wait{color:var(--warn)}
@media(max-width:900px){.toolbar{grid-template-columns:1fr 1fr}.cards{grid-template-columns:repeat(2,1fr)}.remote{width:32%}.state{width:18%}}
@media(max-width:620px){.toolbar{grid-template-columns:1fr}.cards{grid-template-columns:1fr 1fr}.remote{display:none}.proto{width:15%}.local{width:45%}.state{width:25%}.pid{width:15%}.summary{display:block}}
</style>
</head>
<body>
<div class="app">
  <header class="top"><span class="lights"><i></i><i></i><i></i></span><span class="title">APACHEBAS NETSTAT MONITOR</span><span class="tag">READ ONLY</span></header>
  <section class="toolbar">
    <input id="filter" type="search" placeholder="Filter address, state, protocol or PID">
    <select id="stateFilter">
      <option value="">All states</option>
      <option value="LISTENING">LISTENING</option>
      <option value="ESTABLISHED">ESTABLISHED</option>
      <option value="TIME_WAIT">TIME_WAIT</option>
      <option value="CLOSE_WAIT">CLOSE_WAIT</option>
      <option value="UDP">UDP</option>
    </select>
    <button id="refresh" type="button">Refresh</button>
    <button id="pause" type="button">Pause auto-refresh</button>
  </section>
  <section class="cards">
    <div class="card"><span>Total rows</span><b id="totalCount">0</b></div>
    <div class="card"><span>TCP</span><b id="tcpCount">0</b></div>
    <div class="card"><span>UDP</span><b id="udpCount">0</b></div>
    <div class="card"><span>Listening</span><b id="listeningCount">0</b></div>
    <div class="card"><span>Established</span><b id="establishedCount">0</b></div>
  </section>
  <div id="warning" class="warning">The current EXEC_OUTPUT$ buffer appears full. The netstat list may be truncated.</div>
  <main class="main">
    <div class="summary"><span><span id="statusDot" class="dot"></span><span id="status">Loading network connections...</span></span><span id="updated">Not refreshed yet</span></div>
    <div class="tablewrap">
      <table>
        <thead><tr><th class="proto">Protocol</th><th class="local">Local address</th><th class="remote">Remote address</th><th class="state">State</th><th class="pid">PID</th></tr></thead>
        <tbody id="rows"><tr><td colspan="5" class="empty">Reading Windows netstat output...</td></tr></tbody>
      </table>
    </div>
  </main>
  <footer class="footer">Source: Windows netstat.exe -ano · refresh interval: 5 seconds · ApacheBAS v0.1.34.1 · netstat resolved from Windows System32/PATH</footer>
</div>
<script>
const rows=document.getElementById('rows');
const filter=document.getElementById('filter');
const stateFilter=document.getElementById('stateFilter');
const status=document.getElementById('status');
const statusDot=document.getElementById('statusDot');
const updated=document.getElementById('updated');
const warning=document.getElementById('warning');
const pauseButton=document.getElementById('pause');
let connections=[];
let paused=false;
let busy=false;

function parseNetstat(text){
  return text.replace(/\r/g,'').split('\n').map(line=>line.trim()).filter(line=>/^(TCP|UDP)\s+/i.test(line)).map(line=>{
    const parts=line.split(/\s+/);
    const protocol=(parts[0]||'').toUpperCase();
    if(protocol==='TCP'){
      return {protocol,local:parts[1]||'',remote:parts[2]||'',state:parts[3]||'',pid:parts[4]||'',raw:line};
    }
    return {protocol,local:parts[1]||'',remote:parts[2]||'',state:'UDP',pid:parts[3]||'',raw:line};
  }).filter(c=>c.local && c.pid);
}

function esc(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function stateClass(value){return 'state-'+String(value).toLowerCase().replace(/[^a-z0-9]+/g,'_');}

function updateCounts(){
  document.getElementById('totalCount').textContent=connections.length;
  document.getElementById('tcpCount').textContent=connections.filter(c=>c.protocol==='TCP').length;
  document.getElementById('udpCount').textContent=connections.filter(c=>c.protocol==='UDP').length;
  document.getElementById('listeningCount').textContent=connections.filter(c=>c.state==='LISTENING').length;
  document.getElementById('establishedCount').textContent=connections.filter(c=>c.state==='ESTABLISHED').length;
}

function render(){
  const q=filter.value.trim().toLowerCase();
  const sf=stateFilter.value;
  const list=connections.filter(c=>{
    const matchesText=(c.protocol+' '+c.local+' '+c.remote+' '+c.state+' '+c.pid).toLowerCase().includes(q);
    const matchesState=!sf || (sf==='UDP'?c.protocol==='UDP':c.state===sf);
    return matchesText&&matchesState;
  });
  if(!list.length){rows.innerHTML='<tr><td colspan="5" class="empty">No matching network connections.</td></tr>';return;}
  rows.innerHTML=list.map(c=>`<tr title="${esc(c.raw)}"><td class="proto">${esc(c.protocol)}</td><td class="local">${esc(c.local)}</td><td class="remote">${esc(c.remote)}</td><td class="state ${stateClass(c.state)}">${esc(c.state)}</td><td class="pid">${esc(c.pid)}</td></tr>`).join('');
}

async function refresh(){
  if(paused||busy)return;
  busy=true;
  status.textContent='Refreshing...';
  statusDot.className='dot';
  try{
    const response=await fetch('netstat.bas?api=1&_='+Date.now(),{cache:'no-store'});
    const text=await response.text();
    if(!response.ok)throw new Error('HTTP '+response.status);
    if(text.startsWith('ERROR|'))throw new Error(text.slice(6).trim());
    warning.style.display=text.length>=2040?'block':'none';
    connections=parseNetstat(text);
    updateCounts();
    render();
    status.textContent=connections.length+' network rows received';
    updated.textContent='Updated '+new Date().toLocaleTimeString();
  }catch(error){
    rows.innerHTML='<tr><td colspan="5" class="error">'+esc(error.message)+'</td></tr>';
    status.textContent='Could not read netstat output';
    statusDot.className='dot bad';
  }finally{busy=false;}
}

filter.addEventListener('input',render);
stateFilter.addEventListener('change',render);
document.getElementById('refresh').addEventListener('click',refresh);
pauseButton.addEventListener('click',()=>{
  paused=!paused;
  pauseButton.textContent=paused?'Resume auto-refresh':'Pause auto-refresh';
  statusDot.className=paused?'dot paused':'dot';
  if(!paused)refresh();
});
refresh();
setInterval(refresh,5000);
</script>
</body>
</html>
