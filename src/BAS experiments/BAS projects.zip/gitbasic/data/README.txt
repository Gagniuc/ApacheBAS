GitBASIC compact data store.
Do not expose this directory directly. The included .htaccess denies web access.
