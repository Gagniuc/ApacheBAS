CURRENT_USER$ = ""
AUTH_USER$ = ""
AUTH_TOKEN$ = ""
AUTH_VALID = 0
INCLUDE("includes/load-session.inc")
PRINT "@@CONTENT-TYPE application/json; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
IF CURRENT_USER$ = "" THEN PRINT "@@STATUS 401"
IF CURRENT_USER$ = "" THEN PRINT "{""ok"":0,""error"":""Authentication required.""}"
IF CURRENT_USER$ = "" THEN END
TARGET_REPO_ID$ = GET_REPO$
INCLUDE("includes/load-repo.inc")
IF REPO_FOUND = 0 THEN PRINT "{""ok"":0,""error"":""Repository not found.""}"
IF REPO_FOUND = 0 THEN END
IF REPO_OWNER$ <> CURRENT_USER$ THEN PRINT "{""ok"":0,""error"":""Only the repository owner can upload files.""}"
IF REPO_OWNER$ <> CURRENT_USER$ THEN END
ORIGINAL_NAME$ = GET_FILENAME$
CHECK_FILE_NAME$ = ORIGINAL_NAME$
INCLUDE("includes/validate-file-name.inc")
ORIGINAL_NAME$ = CHECK_FILE_NAME$
IF FILE_NAME_OK = 0 THEN PRINT "{""ok"":0,""error"":""Unsafe filename.""}"
IF FILE_NAME_OK = 0 THEN END
LOW_NAME$ = LCASE$(ORIGINAL_NAME$)
IMAGE_EXT$ = ""
IF RIGHT$(LOW_NAME$, 4) = ".png" THEN IMAGE_EXT$ = ".png"
IF RIGHT$(LOW_NAME$, 4) = ".jpg" THEN IMAGE_EXT$ = ".jpg"
IF RIGHT$(LOW_NAME$, 4) = ".gif" THEN IMAGE_EXT$ = ".gif"
IF RIGHT$(LOW_NAME$, 5) = ".jpeg" THEN IMAGE_EXT$ = ".jpeg"
IF RIGHT$(LOW_NAME$, 5) = ".webp" THEN IMAGE_EXT$ = ".webp"
IF IMAGE_EXT$ = "" THEN PRINT "{""ok"":0,""error"":""Only PNG, JPEG, GIF and WebP image assets are accepted.""}"
IF IMAGE_EXT$ = "" THEN END
DUPLICATE_FILE = 0
SCAN_FILES$ = REPO_FILES_RAW$
WHILE SCAN_FILES$ <> ""
  FILE_BREAK = INSTR(SCAN_FILES$, CHR$(10))
  SCAN_FILE_ID$ = SCAN_FILES$
  IF FILE_BREAK > 0 THEN SCAN_FILE_ID$ = LEFT$(SCAN_FILES$, FILE_BREAK - 1)
  IF FILE_BREAK > 0 THEN SCAN_FILES$ = MID$(SCAN_FILES$, FILE_BREAK + 1, LEN(SCAN_FILES$)) ELSE SCAN_FILES$ = ""
  IF SCAN_FILE_ID$ <> "" THEN TARGET_FILE_ID$ = SCAN_FILE_ID$
  IF SCAN_FILE_ID$ <> "" THEN INCLUDE("includes/load-file.inc")
  IF FILE_FOUND AND LCASE$(FILE_NAME$) = LCASE$(ORIGINAL_NAME$) THEN DUPLICATE_FILE = 1
WEND
IF DUPLICATE_FILE THEN PRINT "{""ok"":0,""error"":""A file with that name already exists.""}"
IF DUPLICATE_FILE THEN END
FILE_COUNTER_RAW$ = READFILE$("data/file-counter.txt")
NEW_FILE_NUMBER = VAL(FILE_COUNTER_RAW$) + 1
NEW_FILE_ID$ = RIGHT$("000000" & STR$(NEW_FILE_NUMBER), 6)
SAVE_NAME$ = "gb_" & TARGET_REPO_ID$ & "_" & NEW_FILE_ID$ & IMAGE_EXT$
SAVEUPLOAD SAVE_NAME$
IF UPLOAD_OK = 0 THEN PRINT "{""ok"":0,""error"":"""; JSON$(UPLOAD_ERROR$); """}"
IF UPLOAD_OK = 0 THEN END
FILE_DESCRIPTION_NEW$ = LEFT$(TRIM$(GET_DESCRIPTION$), 300)
WRITEFILE "data/file-" & NEW_FILE_ID$ & "-meta.txt", TARGET_REPO_ID$ & CHR$(10) & "image" & CHR$(10) & ORIGINAL_NAME$ & CHR$(10) & CURRENT_USER$ & CHR$(10) & UPLOAD_URL$
IF FILE_OK = 0 THEN PRINT "{""ok"":0,""error"":""Metadata could not be saved.""}"
IF FILE_OK = 0 THEN END
WRITEFILE "data/file-" & NEW_FILE_ID$ & "-description.txt", FILE_DESCRIPTION_NEW$
IF FILE_OK = 0 THEN PRINT "{""ok"":0,""error"":""Description could not be saved.""}"
IF FILE_OK = 0 THEN END
APPENDFILE "data/repo-" & TARGET_REPO_ID$ & "-files.txt", NEW_FILE_ID$ & CHR$(10)
IF FILE_OK = 0 THEN PRINT "{""ok"":0,""error"":""Repository index could not be updated.""}"
IF FILE_OK = 0 THEN END
WRITEFILE "data/file-counter.txt", STR$(NEW_FILE_NUMBER)
PRINT "{""ok"":1,""fileId"":"""; JSON$(NEW_FILE_ID$); """,""name"":"""; JSON$(ORIGINAL_NAME$); """,""url"":"""; JSON$(UPLOAD_URL$); """}"
