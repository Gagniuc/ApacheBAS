GitBASIC v1.0 for ApacheBAS-ASM v0.1.33.3

INSTALLATION
------------
Copy the GitBASIC-ApacheBAS-v1.0 folder into XAMPP htdocs and rename it to:

  C:\xampp\htdocs\gitbasic

Open:

  http://localhost/gitbasic/index.bas

FUNCTIONS
---------
- Create account and log in.
- Create public repositories with a description and README.
- Browse public repositories without an account.
- Add source/text files by selecting a local file or pasting content.
- Add a description to every file.
- Upload PNG, JPEG, GIF and WebP image assets, maximum 1 MiB.
- View source files as escaped plain text.
- Open a raw text representation in a separate tab.
- Edit repository descriptions and README text.
- Remove files from a repository and remove repositories from the public index.

CURRENT LIMITS
--------------
- Source/text content is limited to 1400 characters per file because ApacheBAS
  v0.1.33.3 uses compact bounded text variables.
- Binary upload uses the engine's safe SAVEUPLOAD operation and therefore accepts
  image assets only.
- Removing a file or repository removes it from the visible index. Orphaned compact
  data files may remain on disk until RESET_GITBASIC.cmd is run.
- Password hashing is demonstrative and is not suitable for a public Internet service.
- Authentication is carried in the URL/form because this ApacheBAS build did not
  reliably emit dynamic Set-Cookie headers in the tested environment.

SECURITY MODEL
--------------
- Repository source is stored under data/, protected by .htaccess.
- Uploaded images are stored under uploads/.
- Script and executable extensions are denied in uploads/.
- Uploaded .bas, HTML, JavaScript and other source files are stored as text records;
  GitBASIC never executes them.
- No cmd.exe, PowerShell or arbitrary native execution is provided.

Use this application locally or on a trusted LAN. Add HTTPS, stronger password
hashing, CSRF protection, rate limiting and a database before public deployment.
