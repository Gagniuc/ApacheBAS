Image assets uploaded to repositories are stored here.
Executable and script extensions are denied by .htaccess.
