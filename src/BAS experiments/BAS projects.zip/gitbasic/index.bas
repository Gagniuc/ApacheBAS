<?bas
GOTO APP_MAIN

GENERATE_TOKEN:
RANDOMIZE
TOKEN_PART_A$ = RND
TOKEN_PART_B$ = RND
TOKEN_PART_C$ = RND
TOKEN_PART_D$ = RND
NEW_TOKEN$ = MID$(TOKEN_PART_A$, 3, 6) & MID$(TOKEN_PART_B$, 3, 6) & MID$(TOKEN_PART_C$, 3, 6) & MID$(TOKEN_PART_D$, 3, 6)
RETURN

ACTION_REGISTER:
FORM_USER$ = POST_USERNAME$
FORM_PASS$ = POST_PASSWORD$
CHECK_USER$ = FORM_USER$
INCLUDE("includes/validate-user.inc")
FORM_USER$ = CHECK_USER$
IF USER_OK = 0 THEN ERROR$ = "Username: 3-64 characters; use letters, numbers, dot, hyphen, underscore or one @ sign."
IF USER_OK = 0 THEN RETURN
IF LEN(FORM_PASS$) < 6 OR LEN(FORM_PASS$) > 64 THEN ERROR$ = "Password length must be between 6 and 64 characters."
IF LEN(FORM_PASS$) < 6 OR LEN(FORM_PASS$) > 64 THEN RETURN
USER_RECORD_KEY$ = CHR$(10) & FORM_USER$ & "|"
IF INSTR(USERS_TEXT$, USER_RECORD_KEY$) > 0 THEN ERROR$ = "That username is already registered."
IF INSTR(USERS_TEXT$, USER_RECORD_KEY$) > 0 THEN RETURN
HASH_USER$ = FORM_USER$
HASH_PASS$ = FORM_PASS$
INCLUDE("includes/hash-password.inc")
GOSUB GENERATE_TOKEN
NEW_RECORD$ = FORM_USER$ & "|" & HASH_RESULT$ & "|" & NEW_TOKEN$ & CHR$(10)
IF LEN(RAW_USERS_TEXT$) + LEN(NEW_RECORD$) > 1950 THEN ERROR$ = "The compact account store is full."
IF LEN(RAW_USERS_TEXT$) + LEN(NEW_RECORD$) > 1950 THEN RETURN
APPENDFILE "data/users.txt", NEW_RECORD$
IF FILE_OK = 0 THEN ERROR$ = "The account could not be saved: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
RAW_USERS_TEXT$ = RAW_USERS_TEXT$ & NEW_RECORD$
USERS_TEXT$ = CHR$(10) & RAW_USERS_TEXT$
CURRENT_USER$ = FORM_USER$
AUTH_USER$ = FORM_USER$
AUTH_TOKEN$ = NEW_TOKEN$
AUTH_VALID = 1
NOTICE$ = "Account created. You are logged in."
RETURN

ACTION_LOGIN:
FORM_USER$ = POST_USERNAME$
FORM_PASS$ = POST_PASSWORD$
CHECK_USER$ = FORM_USER$
INCLUDE("includes/validate-user.inc")
FORM_USER$ = CHECK_USER$
IF USER_OK = 0 THEN ERROR$ = "Invalid username or password."
IF USER_OK = 0 THEN RETURN
USER_RECORD_KEY$ = CHR$(10) & FORM_USER$ & "|"
USER_RECORD_POSITION = INSTR(USERS_TEXT$, USER_RECORD_KEY$)
IF USER_RECORD_POSITION = 0 THEN ERROR$ = "Invalid username or password."
IF USER_RECORD_POSITION = 0 THEN RETURN
HASH_POSITION = USER_RECORD_POSITION + LEN(USER_RECORD_KEY$)
STORED_HASH$ = MID$(USERS_TEXT$, HASH_POSITION, 24)
AUTH_TAIL$ = MID$(USERS_TEXT$, HASH_POSITION + 25, LEN(USERS_TEXT$))
AUTH_END = INSTR(AUTH_TAIL$, CHR$(10))
STORED_AUTH$ = AUTH_TAIL$
IF AUTH_END > 0 THEN STORED_AUTH$ = LEFT$(AUTH_TAIL$, AUTH_END - 1)
HASH_USER$ = FORM_USER$
HASH_PASS$ = FORM_PASS$
INCLUDE("includes/hash-password.inc")
IF HASH_RESULT$ <> STORED_HASH$ THEN ERROR$ = "Invalid username or password."
IF HASH_RESULT$ <> STORED_HASH$ THEN RETURN
CURRENT_USER$ = FORM_USER$
AUTH_USER$ = FORM_USER$
AUTH_TOKEN$ = STORED_AUTH$
AUTH_VALID = 1
NOTICE$ = "Login successful."
RETURN

ACTION_CREATE_REPO:
IF CURRENT_USER$ = "" THEN ERROR$ = "Log in before creating a repository."
IF CURRENT_USER$ = "" THEN RETURN
NEW_REPO_NAME$ = POST_REPONAME$
CHECK_REPO_NAME$ = NEW_REPO_NAME$
INCLUDE("includes/validate-repo-name.inc")
NEW_REPO_NAME$ = CHECK_REPO_NAME$
IF REPO_NAME_OK = 0 THEN ERROR$ = "Repository name: 2-36 lowercase letters, numbers, dot, hyphen or underscore."
IF REPO_NAME_OK = 0 THEN RETURN
NEW_REPO_DESCRIPTION$ = LEFT$(TRIM$(POST_DESCRIPTION$), 500)
NEW_REPO_README$ = LEFT$(POST_README$, 1400)
DUPLICATE_REPO = 0
SCAN_REPOS$ = READFILE$("data/repos-index.txt")
WHILE SCAN_REPOS$ <> ""
  SCAN_BREAK = INSTR(SCAN_REPOS$, CHR$(10))
  SCAN_REPO_ID$ = SCAN_REPOS$
  IF SCAN_BREAK > 0 THEN SCAN_REPO_ID$ = LEFT$(SCAN_REPOS$, SCAN_BREAK - 1)
  IF SCAN_BREAK > 0 THEN SCAN_REPOS$ = MID$(SCAN_REPOS$, SCAN_BREAK + 1, LEN(SCAN_REPOS$)) ELSE SCAN_REPOS$ = ""
  IF SCAN_REPO_ID$ <> "" THEN TARGET_REPO_ID$ = SCAN_REPO_ID$
  IF SCAN_REPO_ID$ <> "" THEN INCLUDE("includes/load-repo.inc")
  IF REPO_FOUND AND REPO_OWNER$ = CURRENT_USER$ AND REPO_NAME$ = NEW_REPO_NAME$ THEN DUPLICATE_REPO = 1
WEND
IF DUPLICATE_REPO THEN ERROR$ = "You already have a repository with that name."
IF DUPLICATE_REPO THEN RETURN
REPO_COUNTER_RAW$ = READFILE$("data/repo-counter.txt")
NEW_REPO_NUMBER = VAL(REPO_COUNTER_RAW$) + 1
IF NEW_REPO_NUMBER > 999999 THEN ERROR$ = "Repository counter is full."
IF NEW_REPO_NUMBER > 999999 THEN RETURN
NEW_REPO_ID$ = RIGHT$("000000" & STR$(NEW_REPO_NUMBER), 6)
WRITEFILE "data/repo-" & NEW_REPO_ID$ & ".txt", CURRENT_USER$ & CHR$(10) & NEW_REPO_NAME$ & CHR$(10) & DATE$
IF FILE_OK = 0 THEN ERROR$ = "Repository metadata could not be saved: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
WRITEFILE "data/repo-" & NEW_REPO_ID$ & "-description.txt", NEW_REPO_DESCRIPTION$
IF FILE_OK = 0 THEN ERROR$ = "Repository description could not be saved: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
WRITEFILE "data/repo-" & NEW_REPO_ID$ & "-readme.txt", NEW_REPO_README$
IF FILE_OK = 0 THEN ERROR$ = "README could not be saved: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
WRITEFILE "data/repo-" & NEW_REPO_ID$ & "-files.txt", ""
IF FILE_OK = 0 THEN ERROR$ = "Repository file index could not be created: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
APPENDFILE "data/repos-index.txt", NEW_REPO_ID$ & CHR$(10)
IF FILE_OK = 0 THEN ERROR$ = "Repository index could not be updated: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
WRITEFILE "data/repo-counter.txt", STR$(NEW_REPO_NUMBER)
OPEN_REPO_ID$ = NEW_REPO_ID$
NOTICE$ = "Repository created."
RETURN

ACTION_UPDATE_REPO:
IF CURRENT_USER$ = "" THEN ERROR$ = "Authentication required."
IF CURRENT_USER$ = "" THEN RETURN
TARGET_REPO_ID$ = POST_REPO$
INCLUDE("includes/load-repo.inc")
IF REPO_FOUND = 0 THEN ERROR$ = "Repository not found."
IF REPO_FOUND = 0 THEN RETURN
IF REPO_OWNER$ <> CURRENT_USER$ THEN ERROR$ = "Only the repository owner can edit it."
IF REPO_OWNER$ <> CURRENT_USER$ THEN RETURN
UPDATED_DESCRIPTION$ = LEFT$(TRIM$(POST_DESCRIPTION$), 500)
UPDATED_README$ = LEFT$(POST_README$, 1400)
WRITEFILE "data/repo-" & TARGET_REPO_ID$ & "-description.txt", UPDATED_DESCRIPTION$
IF FILE_OK = 0 THEN ERROR$ = "Description could not be updated: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
WRITEFILE "data/repo-" & TARGET_REPO_ID$ & "-readme.txt", UPDATED_README$
IF FILE_OK = 0 THEN ERROR$ = "README could not be updated: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
OPEN_REPO_ID$ = TARGET_REPO_ID$
NOTICE$ = "Repository details updated."
RETURN

ACTION_ADD_TEXT:
IF CURRENT_USER$ = "" THEN ERROR$ = "Authentication required."
IF CURRENT_USER$ = "" THEN RETURN
TARGET_REPO_ID$ = POST_REPO$
INCLUDE("includes/load-repo.inc")
IF REPO_FOUND = 0 THEN ERROR$ = "Repository not found."
IF REPO_FOUND = 0 THEN RETURN
IF REPO_OWNER$ <> CURRENT_USER$ THEN ERROR$ = "Only the repository owner can add files."
IF REPO_OWNER$ <> CURRENT_USER$ THEN RETURN
NEW_FILE_NAME$ = POST_FILENAME$
CHECK_FILE_NAME$ = NEW_FILE_NAME$
INCLUDE("includes/validate-file-name.inc")
NEW_FILE_NAME$ = CHECK_FILE_NAME$
IF FILE_NAME_OK = 0 THEN ERROR$ = "Filename: letters, numbers, dot, hyphen and underscore only; no paths."
IF FILE_NAME_OK = 0 THEN RETURN
NEW_FILE_CONTENT$ = POST_CONTENT$
IF LEN(NEW_FILE_CONTENT$) > 1400 THEN ERROR$ = "Text files are limited to 1400 characters in this compact ApacheBAS demo."
IF LEN(NEW_FILE_CONTENT$) > 1400 THEN RETURN
NEW_FILE_DESCRIPTION$ = LEFT$(TRIM$(POST_FILEDESCRIPTION$), 300)
DUPLICATE_FILE = 0
SCAN_FILES$ = REPO_FILES_RAW$
WHILE SCAN_FILES$ <> ""
  FILE_BREAK = INSTR(SCAN_FILES$, CHR$(10))
  SCAN_FILE_ID$ = SCAN_FILES$
  IF FILE_BREAK > 0 THEN SCAN_FILE_ID$ = LEFT$(SCAN_FILES$, FILE_BREAK - 1)
  IF FILE_BREAK > 0 THEN SCAN_FILES$ = MID$(SCAN_FILES$, FILE_BREAK + 1, LEN(SCAN_FILES$)) ELSE SCAN_FILES$ = ""
  IF SCAN_FILE_ID$ <> "" THEN TARGET_FILE_ID$ = SCAN_FILE_ID$
  IF SCAN_FILE_ID$ <> "" THEN INCLUDE("includes/load-file.inc")
  IF FILE_FOUND AND LCASE$(FILE_NAME$) = LCASE$(NEW_FILE_NAME$) THEN DUPLICATE_FILE = 1
WEND
IF DUPLICATE_FILE THEN ERROR$ = "A file with that name already exists in the repository."
IF DUPLICATE_FILE THEN RETURN
FILE_COUNTER_RAW$ = READFILE$("data/file-counter.txt")
NEW_FILE_NUMBER = VAL(FILE_COUNTER_RAW$) + 1
IF NEW_FILE_NUMBER > 999999 THEN ERROR$ = "File counter is full."
IF NEW_FILE_NUMBER > 999999 THEN RETURN
NEW_FILE_ID$ = RIGHT$("000000" & STR$(NEW_FILE_NUMBER), 6)
WRITEFILE "data/file-" & NEW_FILE_ID$ & "-meta.txt", TARGET_REPO_ID$ & CHR$(10) & "text" & CHR$(10) & NEW_FILE_NAME$ & CHR$(10) & CURRENT_USER$ & CHR$(10)
IF FILE_OK = 0 THEN ERROR$ = "File metadata could not be saved: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
WRITEFILE "data/file-" & NEW_FILE_ID$ & "-description.txt", NEW_FILE_DESCRIPTION$
IF FILE_OK = 0 THEN ERROR$ = "File description could not be saved: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
WRITEFILE "data/file-" & NEW_FILE_ID$ & "-content.txt", NEW_FILE_CONTENT$
IF FILE_OK = 0 THEN ERROR$ = "File content could not be saved: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
APPENDFILE "data/repo-" & TARGET_REPO_ID$ & "-files.txt", NEW_FILE_ID$ & CHR$(10)
IF FILE_OK = 0 THEN ERROR$ = "Repository file index could not be updated: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
WRITEFILE "data/file-counter.txt", STR$(NEW_FILE_NUMBER)
OPEN_REPO_ID$ = TARGET_REPO_ID$
NOTICE$ = "File added to the repository."
RETURN

ACTION_DELETE_FILE:
IF CURRENT_USER$ = "" THEN ERROR$ = "Authentication required."
IF CURRENT_USER$ = "" THEN RETURN
TARGET_REPO_ID$ = POST_REPO$
INCLUDE("includes/load-repo.inc")
IF REPO_FOUND = 0 THEN ERROR$ = "Repository not found."
IF REPO_FOUND = 0 THEN RETURN
IF REPO_OWNER$ <> CURRENT_USER$ THEN ERROR$ = "Only the repository owner can remove files."
IF REPO_OWNER$ <> CURRENT_USER$ THEN RETURN
DELETE_FILE_ID$ = POST_FILE$
TARGET_FILE_ID$ = DELETE_FILE_ID$
INCLUDE("includes/load-file.inc")
IF FILE_FOUND = 0 THEN ERROR$ = "File not found."
IF FILE_FOUND = 0 THEN RETURN
OLD_FILES$ = REPO_FILES_RAW$
NEW_FILES$ = ""
WHILE OLD_FILES$ <> ""
  DELETE_BREAK = INSTR(OLD_FILES$, CHR$(10))
  DELETE_LINE$ = OLD_FILES$
  IF DELETE_BREAK > 0 THEN DELETE_LINE$ = LEFT$(OLD_FILES$, DELETE_BREAK - 1)
  IF DELETE_BREAK > 0 THEN OLD_FILES$ = MID$(OLD_FILES$, DELETE_BREAK + 1, LEN(OLD_FILES$)) ELSE OLD_FILES$ = ""
  IF DELETE_LINE$ <> "" AND DELETE_LINE$ <> DELETE_FILE_ID$ THEN NEW_FILES$ = NEW_FILES$ & DELETE_LINE$ & CHR$(10)
WEND
WRITEFILE "data/repo-" & TARGET_REPO_ID$ & "-files.txt", NEW_FILES$
IF FILE_OK = 0 THEN ERROR$ = "File index could not be updated: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
OPEN_REPO_ID$ = TARGET_REPO_ID$
NOTICE$ = "File removed from the repository."
RETURN

ACTION_DELETE_REPO:
IF CURRENT_USER$ = "" THEN ERROR$ = "Authentication required."
IF CURRENT_USER$ = "" THEN RETURN
TARGET_REPO_ID$ = POST_REPO$
INCLUDE("includes/load-repo.inc")
IF REPO_FOUND = 0 THEN ERROR$ = "Repository not found."
IF REPO_FOUND = 0 THEN RETURN
IF REPO_OWNER$ <> CURRENT_USER$ THEN ERROR$ = "Only the repository owner can delete it."
IF REPO_OWNER$ <> CURRENT_USER$ THEN RETURN
OLD_REPOS$ = READFILE$("data/repos-index.txt")
NEW_REPOS$ = ""
WHILE OLD_REPOS$ <> ""
  REPO_DELETE_BREAK = INSTR(OLD_REPOS$, CHR$(10))
  REPO_DELETE_LINE$ = OLD_REPOS$
  IF REPO_DELETE_BREAK > 0 THEN REPO_DELETE_LINE$ = LEFT$(OLD_REPOS$, REPO_DELETE_BREAK - 1)
  IF REPO_DELETE_BREAK > 0 THEN OLD_REPOS$ = MID$(OLD_REPOS$, REPO_DELETE_BREAK + 1, LEN(OLD_REPOS$)) ELSE OLD_REPOS$ = ""
  IF REPO_DELETE_LINE$ <> "" AND REPO_DELETE_LINE$ <> TARGET_REPO_ID$ THEN NEW_REPOS$ = NEW_REPOS$ & REPO_DELETE_LINE$ & CHR$(10)
WEND
WRITEFILE "data/repos-index.txt", NEW_REPOS$
IF FILE_OK = 0 THEN ERROR$ = "Repository index could not be updated: " & FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
NOTICE$ = "Repository removed from the public index."
OPEN_REPO_ID$ = ""
RETURN

APP_MAIN:
ERROR$ = ""
NOTICE$ = ""
OPEN_REPO_ID$ = ""
CURRENT_USER$ = ""
AUTH_USER$ = ""
AUTH_TOKEN$ = ""
AUTH_VALID = 0
INCLUDE("includes/load-session.inc")
ACTION$ = LCASE$(TRIM$(POST_ACTION$))
IF ACTION$ = "register" THEN GOSUB ACTION_REGISTER
IF ACTION$ = "login" THEN GOSUB ACTION_LOGIN
IF ACTION$ = "create-repo" THEN GOSUB ACTION_CREATE_REPO
IF ACTION$ = "update-repo" THEN GOSUB ACTION_UPDATE_REPO
IF ACTION$ = "add-text" THEN GOSUB ACTION_ADD_TEXT
IF ACTION$ = "delete-file" THEN GOSUB ACTION_DELETE_FILE
IF ACTION$ = "delete-repo" THEN GOSUB ACTION_DELETE_REPO
AUTH_QUERY$ = ""
IF CURRENT_USER$ <> "" THEN AUTH_QUERY$ = "&user=" & CURRENT_USER$ & "&auth=" & AUTH_TOKEN$
PAGE_REPO_ID$ = TRIM$(GET_REPO$)
IF OPEN_REPO_ID$ <> "" THEN PAGE_REPO_ID$ = OPEN_REPO_ID$
REPO_FOUND = 0
IF PAGE_REPO_ID$ <> "" THEN TARGET_REPO_ID$ = PAGE_REPO_ID$
IF PAGE_REPO_ID$ <> "" THEN INCLUDE("includes/load-repo.inc")
PAGE_FILE_ID$ = TRIM$(GET_FILE$)
FILE_FOUND = 0
IF REPO_FOUND AND PAGE_FILE_ID$ <> "" THEN TARGET_FILE_ID$ = PAGE_FILE_ID$
IF REPO_FOUND AND PAGE_FILE_ID$ <> "" THEN INCLUDE("includes/load-file.inc")
IF GET_RAW$ = "1" AND FILE_FOUND AND FILE_TYPE$ = "text" THEN PRINT "@@CONTENT-TYPE text/plain; charset=utf-8"
IF GET_RAW$ = "1" AND FILE_FOUND AND FILE_TYPE$ = "text" THEN PRINT FILE_CONTENT$
IF GET_RAW$ = "1" AND FILE_FOUND AND FILE_TYPE$ = "text" THEN END
IS_OWNER = 0
IF REPO_FOUND AND CURRENT_USER$ <> "" AND REPO_OWNER$ = CURRENT_USER$ THEN IS_OWNER = 1
PAGE_MODE$ = "guest"
IF CURRENT_USER$ <> "" THEN PAGE_MODE$ = "home"
IF REPO_FOUND THEN PAGE_MODE$ = "repo"
IF FILE_FOUND THEN PAGE_MODE$ = "file"
GUEST_CLASS$ = "hidden"
HOME_CLASS$ = "hidden"
REPO_CLASS$ = "hidden"
FILE_CLASS$ = "hidden"
OWNER_TOOLS_CLASS$ = "hidden"
IF PAGE_MODE$ = "guest" THEN GUEST_CLASS$ = ""
IF PAGE_MODE$ = "home" THEN HOME_CLASS$ = ""
IF PAGE_MODE$ = "repo" THEN REPO_CLASS$ = ""
IF PAGE_MODE$ = "file" THEN FILE_CLASS$ = ""
IF PAGE_MODE$ = "repo" AND IS_OWNER THEN OWNER_TOOLS_CLASS$ = ""
PRINT "@@CONTENT-TYPE text/html; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
PRINT "@@HEADER X-Content-Type-Options: nosniff"
PRINT "@@HEADER X-Frame-Options: SAMEORIGIN"
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>GitBASIC · repositories in ApacheBAS</title>
<style>
*{box-sizing:border-box}
body{margin:0;background:#f6f8fa;color:#1f2328;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif}
.hidden{display:none!important}
a{color:#0969da;text-decoration:none}
a:hover{text-decoration:underline}
.top{height:64px;background:#24292f;color:#fff;display:flex;align-items:center}
.topin{width:min(1180px,calc(100% - 32px));margin:auto;display:flex;align-items:center;gap:18px}
.logo{width:38px;height:38px;border-radius:50%;background:#fff;color:#24292f;display:grid;place-items:center;font-weight:900;font-family:Georgia;font-size:18px}
.brand{font-size:20px;font-weight:800;color:#fff}
.tag{color:#afb8c1;font-size:13px}
.spacer{flex:1}
.userpill{display:flex;align-items:center;gap:9px;color:#fff;font-weight:700}
.avatar{width:32px;height:32px;border-radius:50%;background:#57606a;display:grid;place-items:center;color:#fff}
.logout{border:1px solid #6e7781;border-radius:6px;padding:7px 10px;color:#fff;text-decoration:none}
.wrap{width:min(1180px,calc(100% - 32px));margin:24px auto 70px}
.alert,.notice{border-radius:6px;padding:12px 14px;margin-bottom:16px}
.alert{background:#ffebe9;border:1px solid #ff8182;color:#82071e}
.notice{background:#dafbe1;border:1px solid #4ac26b;color:#116329}
.grid{display:grid;grid-template-columns:280px 1fr;gap:24px}
.card{background:#fff;border:1px solid #d0d7de;border-radius:6px}
.pad{padding:18px}
.card h2,.card h3{margin-top:0}
.muted{color:#656d76}
.field{margin-bottom:13px}
.field label{display:block;font-size:13px;font-weight:700;margin-bottom:6px}
.field input,.field textarea{width:100%;border:1px solid #d0d7de;border-radius:6px;padding:9px 10px;font:inherit;background:#fff}
.field textarea{min-height:100px;resize:vertical}
.btn{border:1px solid #1f883d;background:#1f883d;color:#fff;border-radius:6px;padding:8px 13px;font-weight:700;cursor:pointer}
.btn.secondary{background:#f6f8fa;border-color:#d0d7de;color:#24292f}
.btn.danger{background:#cf222e;border-color:#cf222e}
.authsplit{display:grid;grid-template-columns:1.2fr .8fr;gap:28px;align-items:start}
.hero{padding:42px 20px}
.hero h1{font-size:54px;line-height:1.02;margin:0 0 18px;letter-spacing:-2px}
.hero p{font-size:19px;line-height:1.65;color:#57606a}
.authcard{padding:20px}
.sep{height:1px;background:#d8dee4;margin:20px 0}
.repo-list{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px}
.repo-card{padding:17px}
.repo-card h3{margin:0 0 7px;font-size:18px}
.repo-meta{font-size:12px;color:#656d76;margin-top:14px}
.breadcrumb{font-size:20px;margin-bottom:16px}
.breadcrumb b{color:#0969da}
.repo-head{display:flex;gap:18px;align-items:flex-start;justify-content:space-between;margin-bottom:16px}
.repo-head h1{font-size:25px;margin:0 0 6px}
.file-table{width:100%;border-collapse:collapse}
.file-table th,.file-table td{padding:11px 13px;border-top:1px solid #d8dee4;text-align:left}
.file-table th{background:#f6f8fa;font-size:13px}
.file-icon{width:28px}
.readme-head{padding:12px 16px;border-bottom:1px solid #d8dee4;font-weight:700}
.readme{padding:18px;white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.55}
.code-head{padding:11px 14px;background:#f6f8fa;border-bottom:1px solid #d8dee4;display:flex;justify-content:space-between}
.code{margin:0;padding:18px;white-space:pre;overflow:auto;font:13px/1.55 Consolas,"Courier New",monospace;min-height:180px}
.image-view{display:block;max-width:100%;max-height:680px;margin:20px auto}
.tabs{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0}
.tab{border:1px solid #d0d7de;background:#fff;border-radius:6px;padding:8px 11px;cursor:pointer}
.owner-tools{margin-top:18px}
.file-picker-note{font-size:12px;color:#656d76}
.modal{margin-top:16px}
.two{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.footer{text-align:center;color:#656d76;font-size:12px;margin-top:38px}
@media(max-width:800px){.grid,.authsplit{grid-template-columns:1fr}
.hero{padding:18px 0}
.hero h1{font-size:40px}
.top .tag{display:none}
.repo-head{flex-direction:column}
.two{grid-template-columns:1fr}
}

</style>
</head>
<body>
<header class="top"><div class="topin"><a class="logo" href="index.bas?home=1<?= AUTH_QUERY$ ?>">gB</a><a class="brand" href="index.bas?home=1<?= AUTH_QUERY$ ?>">GitBASIC</a><span class="tag">A primitive source repository service in ApacheBAS</span><span class="spacer"></span><?bas IF CURRENT_USER$ <> "" THEN PRINT "<span class=""userpill""><span class=""avatar"">" & HTML$(LEFT$(UCASE$(CURRENT_USER$),1)) & "</span>" & HTML$(CURRENT_USER$) & "</span><a class=""logout"" href=""index.bas"">Log out</a>" ELSE PRINT "<a class=""logout"" href=""index.bas"">Log in</a>" ?></div></header>
<main class="wrap">
<?bas IF ERROR$ <> "" THEN PRINT "<div class=""alert"">" & HTML$(ERROR$) & "</div>" ?>
<?bas IF NOTICE$ <> "" THEN PRINT "<div class=""notice"">" & HTML$(NOTICE$) & "</div>" ?>

<div class="<?= GUEST_CLASS$ ?>">
<section class="authsplit">
  <div class="hero"><h1>Store code.<br>Describe projects.<br>Share repositories.</h1><p>GitBASIC provides accounts, public repositories, README pages, text source files and image assets using ApacheBAS and compact file-based storage.</p></div>
  <div class="card authcard">
    <h2>Log in</h2>
    <form method="post" action="index.bas"><input type="hidden" name="action" value="login"><div class="field"><label>Username</label><input name="username" required></div><div class="field"><label>Password</label><input type="password" name="password" required></div><button class="btn" type="submit">Log in</button></form>
    <div class="sep"></div>
    <h2>Create account</h2>
    <form method="post" action="index.bas"><input type="hidden" name="action" value="register"><div class="field"><label>Username</label><input name="username" minlength="3" maxlength="64" required></div><div class="field"><label>Password</label><input type="password" name="password" minlength="6" maxlength="64" required></div><button class="btn" type="submit">Create account</button></form>
  </div>
</section>
<section style="margin-top:28px"><h2>Explore public repositories</h2><div class="repo-list">
<?bas
GUEST_REPOS$ = ""
IF PAGE_MODE$ = "guest" THEN GUEST_REPOS$ = READFILE$("data/repos-index.txt")
WHILE GUEST_REPOS$ <> ""
  GUEST_BREAK = INSTR(GUEST_REPOS$, CHR$(10))
  GUEST_ID$ = GUEST_REPOS$
  IF GUEST_BREAK > 0 THEN GUEST_ID$ = LEFT$(GUEST_REPOS$, GUEST_BREAK - 1)
  IF GUEST_BREAK > 0 THEN GUEST_REPOS$ = MID$(GUEST_REPOS$, GUEST_BREAK + 1, LEN(GUEST_REPOS$)) ELSE GUEST_REPOS$ = ""
  IF GUEST_ID$ <> "" THEN TARGET_REPO_ID$ = GUEST_ID$
  IF GUEST_ID$ <> "" THEN INCLUDE("includes/load-repo.inc")
  IF REPO_FOUND THEN PRINT "<article class=""card repo-card""><h3><a href=""index.bas?repo=" & TARGET_REPO_ID$ & """>" & HTML$(REPO_OWNER$) & "/" & HTML$(REPO_NAME$) & "</a></h3><div class=""muted"">" & HTML$(REPO_DESCRIPTION$) & "</div><div class=""repo-meta"">Created " & HTML$(REPO_CREATED$) & "</div></article>"
WEND
?>
</div></section>
</div>

<div class="grid <?= HOME_CLASS$ ?>">
<aside>
  <section class="card pad"><h2>Your account</h2><p><b><?= HTML$(CURRENT_USER$) ?></b></p><p class="muted">Create repositories and add source files or image assets.</p></section>
  <section class="card pad" style="margin-top:16px"><h3>New repository</h3>
    <form method="post" action="index.bas"><input type="hidden" name="action" value="create-repo"><input type="hidden" name="user" value="<?= HTML$(CURRENT_USER$) ?>"><input type="hidden" name="auth" value="<?= HTML$(AUTH_TOKEN$) ?>"><div class="field"><label>Name</label><input name="reponame" maxlength="36" placeholder="my-project" required></div><div class="field"><label>Description</label><textarea name="description" maxlength="500" placeholder="What does this project do?"></textarea></div><div class="field"><label>Initial README</label><textarea name="readme" maxlength="1400" placeholder="# My project"></textarea></div><button class="btn" type="submit">Create repository</button></form>
  </section>
</aside>
<section><h1>Repositories</h1><p class="muted">Public repositories available on this GitBASIC server.</p><div class="repo-list">
<?bas
ALL_REPOS$ = ""
IF PAGE_MODE$ = "home" THEN ALL_REPOS$ = READFILE$("data/repos-index.txt")
REPO_TOTAL = 0
WHILE ALL_REPOS$ <> ""
  ALL_BREAK = INSTR(ALL_REPOS$, CHR$(10))
  ALL_ID$ = ALL_REPOS$
  IF ALL_BREAK > 0 THEN ALL_ID$ = LEFT$(ALL_REPOS$, ALL_BREAK - 1)
  IF ALL_BREAK > 0 THEN ALL_REPOS$ = MID$(ALL_REPOS$, ALL_BREAK + 1, LEN(ALL_REPOS$)) ELSE ALL_REPOS$ = ""
  IF ALL_ID$ <> "" THEN TARGET_REPO_ID$ = ALL_ID$
  IF ALL_ID$ <> "" THEN INCLUDE("includes/load-repo.inc")
  IF REPO_FOUND THEN REPO_TOTAL = REPO_TOTAL + 1
  IF REPO_FOUND THEN OWNER_BADGE$ = ""
  IF REPO_FOUND AND REPO_OWNER$ = CURRENT_USER$ THEN OWNER_BADGE$ = " · yours"
  IF REPO_FOUND THEN PRINT "<article class=""card repo-card""><h3><a href=""index.bas?repo=" & TARGET_REPO_ID$ & AUTH_QUERY$ & """>" & HTML$(REPO_OWNER$) & "/" & HTML$(REPO_NAME$) & "</a></h3><div class=""muted"">" & HTML$(REPO_DESCRIPTION$) & "</div><div class=""repo-meta"">Created " & HTML$(REPO_CREATED$) & HTML$(OWNER_BADGE$) & "</div></article>"
WEND
IF PAGE_MODE$ = "home" AND REPO_TOTAL = 0 THEN PRINT "<div class=""card pad muted"">No repositories yet.</div>"
?>
</div></section>
</div>

<div class="<?= REPO_CLASS$ ?>">
<div class="breadcrumb"><a href="index.bas?home=1<?= AUTH_QUERY$ ?>">Repositories</a> / <b><?= HTML$(REPO_OWNER$) ?></b> / <b><?= HTML$(REPO_NAME$) ?></b></div>
<section class="repo-head"><div><h1><?= HTML$(REPO_NAME$) ?></h1><div class="muted"><?= HTML$(REPO_DESCRIPTION$) ?></div></div><div class="muted">Public repository · created <?= HTML$(REPO_CREATED$) ?></div></section>
<section class="card">
<table class="file-table"><thead><tr><th class="file-icon"></th><th>Name</th><th>Description</th><th>Type</th><?bas IF PAGE_MODE$ = "repo" AND IS_OWNER THEN PRINT "<th></th>" ?></tr></thead><tbody>
<?bas
FILES_LIST$ = ""
IF PAGE_MODE$ = "repo" THEN FILES_LIST$ = REPO_FILES_RAW$
FILE_TOTAL = 0
WHILE FILES_LIST$ <> ""
  LIST_BREAK = INSTR(FILES_LIST$, CHR$(10))
  LIST_FILE_ID$ = FILES_LIST$
  IF LIST_BREAK > 0 THEN LIST_FILE_ID$ = LEFT$(FILES_LIST$, LIST_BREAK - 1)
  IF LIST_BREAK > 0 THEN FILES_LIST$ = MID$(FILES_LIST$, LIST_BREAK + 1, LEN(FILES_LIST$)) ELSE FILES_LIST$ = ""
  IF LIST_FILE_ID$ <> "" THEN TARGET_FILE_ID$ = LIST_FILE_ID$
  IF LIST_FILE_ID$ <> "" THEN INCLUDE("includes/load-file.inc")
  IF FILE_FOUND THEN FILE_TOTAL = FILE_TOTAL + 1
  IF FILE_FOUND AND FILE_TYPE$ = "image" THEN FILE_SYMBOL$ = "▧" ELSE FILE_SYMBOL$ = "<>"
  IF FILE_FOUND THEN PRINT "<tr><td class=""file-icon"">" & FILE_SYMBOL$ & "</td><td><a href=""index.bas?repo=" & TARGET_REPO_ID$ & "&file=" & TARGET_FILE_ID$ & AUTH_QUERY$ & """>" & HTML$(FILE_NAME$) & "</a></td><td class=""muted"">" & HTML$(FILE_DESCRIPTION$) & "</td><td>" & HTML$(FILE_TYPE$) & "</td>"
  IF FILE_FOUND AND IS_OWNER THEN PRINT "<td><form method=""post"" action=""index.bas"" onsubmit=""return confirm('Remove this file from the repository?')""><input type=""hidden"" name=""action"" value=""delete-file""><input type=""hidden"" name=""repo"" value=""" & TARGET_REPO_ID$ & """><input type=""hidden"" name=""file"" value=""" & TARGET_FILE_ID$ & """><input type=""hidden"" name=""user"" value=""" & HTML$(CURRENT_USER$) & """><input type=""hidden"" name=""auth"" value=""" & HTML$(AUTH_TOKEN$) & """><button class=""btn secondary"" type=""submit"">Remove</button></form></td>"
  IF FILE_FOUND THEN PRINT "</tr>"
WEND
IF PAGE_MODE$ = "repo" AND FILE_TOTAL = 0 THEN PRINT "<tr><td colspan=""5"" class=""muted"">This repository has no files yet.</td></tr>"
?>
</tbody></table></section>
<section class="card" style="margin-top:18px"><div class="readme-head">README</div><div class="readme"><?bas IF REPO_README$ = "" THEN PRINT "<span class=""muted"">No README yet.</span>" ELSE PRINT HTML$(REPO_README$) ?></div></section>
<section class="owner-tools <?= OWNER_TOOLS_CLASS$ ?>">
<div class="two">
<div class="card pad"><h3>Add a text/source file</h3>
<form method="post" action="index.bas" id="textFileForm"><input type="hidden" name="action" value="add-text"><input type="hidden" name="repo" value="<?= HTML$(TARGET_REPO_ID$) ?>"><input type="hidden" name="user" value="<?= HTML$(CURRENT_USER$) ?>"><input type="hidden" name="auth" value="<?= HTML$(AUTH_TOKEN$) ?>"><div class="field"><label>Select a text file</label><input type="file" id="textPicker"></div><div class="field"><label>Filename</label><input name="filename" id="textFilename" maxlength="80" placeholder="main.bas" required></div><div class="field"><label>Description</label><input name="filedescription" maxlength="300" placeholder="Main program"></div><div class="field"><label>Content</label><textarea name="content" id="textContent" maxlength="1400" placeholder="Paste code or choose a file above"></textarea></div><div class="file-picker-note" id="textFileNote">Text files are limited to 1400 characters.</div><br><button class="btn" type="submit">Add file</button></form>
</div>
<div class="card pad"><h3>Upload an image asset</h3><div class="field"><label>Image</label><input type="file" id="imagePicker" accept="image/png,image/jpeg,image/gif,image/webp"></div><div class="field"><label>Description</label><input id="imageDescription" maxlength="300" placeholder="Screenshot or diagram"></div><button class="btn" id="uploadImage" type="button">Upload image</button><p class="file-picker-note" id="imageStatus">PNG, JPEG, GIF or WebP; maximum 1 MiB.</p><div class="sep"></div><h3>Edit repository</h3>
<form method="post" action="index.bas"><input type="hidden" name="action" value="update-repo"><input type="hidden" name="repo" value="<?= HTML$(TARGET_REPO_ID$) ?>"><input type="hidden" name="user" value="<?= HTML$(CURRENT_USER$) ?>"><input type="hidden" name="auth" value="<?= HTML$(AUTH_TOKEN$) ?>"><div class="field"><label>Description</label><textarea name="description" maxlength="500"><?= HTML$(REPO_DESCRIPTION$) ?></textarea></div><div class="field"><label>README</label><textarea name="readme" maxlength="1400"><?= HTML$(REPO_README$) ?></textarea></div><button class="btn secondary" type="submit">Save changes</button></form>
<form method="post" action="index.bas" style="margin-top:18px" onsubmit="return confirm('Remove this repository from GitBASIC?')"><input type="hidden" name="action" value="delete-repo"><input type="hidden" name="repo" value="<?= HTML$(TARGET_REPO_ID$) ?>"><input type="hidden" name="user" value="<?= HTML$(CURRENT_USER$) ?>"><input type="hidden" name="auth" value="<?= HTML$(AUTH_TOKEN$) ?>"><button class="btn danger" type="submit">Delete repository</button></form>
</div>
</div></section>
</div>

<div class="<?= FILE_CLASS$ ?>">
<div class="breadcrumb"><a href="index.bas?home=1<?= AUTH_QUERY$ ?>">Repositories</a> / <a href="index.bas?repo=<?= HTML$(TARGET_REPO_ID$) ?><?= AUTH_QUERY$ ?>"><?= HTML$(REPO_NAME$) ?></a> / <b><?= HTML$(FILE_NAME$) ?></b></div>
<section class="card"><div class="code-head"><b><?= HTML$(FILE_NAME$) ?></b><span><a href="index.bas?repo=<?= HTML$(TARGET_REPO_ID$) ?><?= AUTH_QUERY$ ?>">Back to repository</a><?bas IF FILE_TYPE$ = "text" THEN PRINT " · <a target=""_blank"" href=""index.bas?repo=" & TARGET_REPO_ID$ & "&file=" & TARGET_FILE_ID$ & "&raw=1" & AUTH_QUERY$ & """>Raw</a>" ?></span></div><?bas IF FILE_DESCRIPTION$ <> "" THEN PRINT "<div class=""pad muted"">" & HTML$(FILE_DESCRIPTION$) & "</div>" ?><?bas IF FILE_TYPE$ = "text" THEN PRINT "<pre class=""code"">" & HTML$(FILE_CONTENT$) & "</pre>" ?><?bas IF FILE_TYPE$ = "image" THEN PRINT "<img class=""image-view"" src=""" & HTML$(FILE_URL$) & """ alt=""" & HTML$(FILE_NAME$) & """>" ?></section>
</div>

<div class="footer">GitBASIC v1.0 · ApacheBAS-ASM v0.1.33.3 · uploaded code is displayed as text and is never executed</div>
</main>
<script>
const textPicker=document.getElementById('textPicker');
const textFilename=document.getElementById('textFilename');
const textContent=document.getElementById('textContent');
const textFileNote=document.getElementById('textFileNote');
if(textPicker){textPicker.addEventListener('change',async()=>{const file=textPicker.files[0];if(!file)return;textFilename.value=file.name;const text=await file.text();if(text.length>1400){textContent.value=text.slice(0,1400);textFileNote.textContent='The file was truncated to 1400 characters.';}else{textContent.value=text;textFileNote.textContent='Loaded '+text.length+' characters from '+file.name+'.';}});}
const uploadImage=document.getElementById('uploadImage');
if(uploadImage){uploadImage.addEventListener('click',async()=>{const picker=document.getElementById('imagePicker');const status=document.getElementById('imageStatus');const description=document.getElementById('imageDescription').value;const file=picker.files[0];if(!file){status.textContent='Choose an image first.';return;}if(file.size>1048576){status.textContent='Image is larger than 1 MiB.';return;}status.textContent='Uploading image...';try{const url='upload-api.bas?repo=<?= HTML$(TARGET_REPO_ID$) ?>&filename='+encodeURIComponent(file.name)+'&description='+encodeURIComponent(description)+'&user='+encodeURIComponent('<?= JSON$(CURRENT_USER$) ?>')+'&auth='+encodeURIComponent('<?= JSON$(AUTH_TOKEN$) ?>');const response=await fetch(url,{method:'POST',headers:{'Content-Type':file.type||'application/octet-stream'},body:file});const result=await response.json();if(!result.ok)throw new Error(result.error||'Upload failed.');status.textContent='Image uploaded.';location.href='index.bas?repo=<?= HTML$(TARGET_REPO_ID$) ?><?= AUTH_QUERY$ ?>';}catch(error){status.textContent='Upload error: '+error.message;}});}
</script>
</body>
</html>
