@echo off
setlocal
cd /d "%~dp0"
>data\users.txt type nul
>data\repos-index.txt echo 000001
>data\repo-counter.txt echo|set /p=1
>data\file-counter.txt echo|set /p=1
>data\repo-000001-files.txt echo 000001
for /f "delims=" %%F in ('dir /b data\repo-*.txt 2^>nul') do if /I not "%%F"=="repo-counter.txt" if /I not "%%F"=="repo-000001.txt" if /I not "%%F"=="repo-000001-description.txt" if /I not "%%F"=="repo-000001-readme.txt" if /I not "%%F"=="repo-000001-files.txt" del /q "data\%%F"
for /f "delims=" %%F in ('dir /b data\file-*.txt 2^>nul') do if /I not "%%F"=="file-counter.txt" if /I not "%%F"=="file-000001-meta.txt" if /I not "%%F"=="file-000001-description.txt" if /I not "%%F"=="file-000001-content.txt" del /q "data\%%F"
for /f "delims=" %%F in ('dir /b uploads\gb_* 2^>nul') do del /q "uploads\%%F"
echo GitBASIC was reset. The public sample repository remains.
pause
