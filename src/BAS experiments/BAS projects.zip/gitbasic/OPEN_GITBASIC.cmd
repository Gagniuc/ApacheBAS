@echo off
start "" "http://localhost/gitbasic/index.bas"
