<?bas
PRINT "@@CONTENT-TYPE text/html; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store, no-cache, must-revalidate"
PRINT "@@HEADER Pragma: no-cache"
PRINT "@@HEADER X-Content-Type-Options: nosniff"
PRINT "@@HEADER X-Frame-Options: SAMEORIGIN"
PRINT "@@HEADER Referrer-Policy: same-origin"

DIRHEX$ = UCASE$(TRIM$(GET_DIR$))
PAGE = INT(VAL(GET_PAGE$))
DPAGE = INT(VAL(GET_DPAGE$))
IF PAGE < 0 OR PAGE > 999 THEN PAGE = 0
IF DPAGE < 0 OR DPAGE > 999 THEN DPAGE = 0

CHECK_HEX$ = DIRHEX$
GOSUB VALIDATE_HEX
IF HEX_OK = 0 THEN DIRHEX$ = ""

EXPLORER_OPEN = 0
IF GET_EXPLORER$ = "1" THEN EXPLORER_OPEN = 1
IF DIRHEX$ <> "" THEN EXPLORER_OPEN = 1

ROOT_CMD$ = "list||" & LTRIM$(STR$(DPAGE))
EXEC "DesktopHelper.exe", ROOT_CMD$
ROOT_RAW$ = EXEC_OUTPUT$
ROOT_ERROR$ = ""
IF EXEC_OK = 0 THEN ROOT_ERROR$ = EXEC_ERROR$
IF EXEC_OK = 1 AND EXEC_CODE <> 0 THEN ROOT_ERROR$ = ROOT_RAW$
IF LEFT$(ROOT_RAW$, 4) = "ERR|" THEN ROOT_ERROR$ = ROOT_RAW$
IF ROOT_ERROR$ <> "" THEN ROOT_RAW$ = "M||0|0" & CHR$(10)

CURRENT_RAW$ = "M||0|0" & CHR$(10)
CURRENT_ERROR$ = ""
IF EXPLORER_OPEN = 0 THEN GOTO PAGE_START
CURRENT_CMD$ = "list|" & DIRHEX$ & "|" & LTRIM$(STR$(PAGE))
EXEC "DesktopHelper.exe", CURRENT_CMD$
CURRENT_RAW$ = EXEC_OUTPUT$
IF EXEC_OK = 0 THEN CURRENT_ERROR$ = EXEC_ERROR$
IF EXEC_OK = 1 AND EXEC_CODE <> 0 THEN CURRENT_ERROR$ = CURRENT_RAW$
IF LEFT$(CURRENT_RAW$, 4) = "ERR|" THEN CURRENT_ERROR$ = CURRENT_RAW$
IF CURRENT_ERROR$ <> "" THEN CURRENT_RAW$ = "M||0|0" & CHR$(10)
GOTO PAGE_START

VALIDATE_HEX:
HEX_OK = 1
IF LEN(CHECK_HEX$) > 200 THEN HEX_OK = 0
IF LEN(CHECK_HEX$) MOD 2 <> 0 THEN HEX_OK = 0
HEX_I = 1
WHILE HEX_I <= LEN(CHECK_HEX$)
  HEX_C = ASC(MID$(CHECK_HEX$, HEX_I, 1))
  HEX_CHAR_OK = 0
  IF HEX_C >= 48 AND HEX_C <= 57 THEN HEX_CHAR_OK = 1
  IF HEX_C >= 65 AND HEX_C <= 70 THEN HEX_CHAR_OK = 1
  IF HEX_C >= 97 AND HEX_C <= 102 THEN HEX_CHAR_OK = 1
  IF HEX_CHAR_OK = 0 THEN HEX_OK = 0
  HEX_I = HEX_I + 1
WEND
RETURN

PAGE_START:
EXPLORER_CLASS$ = "hidden"
IF EXPLORER_OPEN = 1 THEN EXPLORER_CLASS$ = ""
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ApacheBAS Desktop</title>
<style>
:root{--silver:#c0c0c0;--light:#fff;--mid:#dfdfdf;--dark:#808080;--black:#000;--blue:#000080;--teal:#008080}
*{box-sizing:border-box}
html,body{margin:0;width:100%;height:100%;overflow:hidden;font-family:"MS Sans Serif",Tahoma,Arial,sans-serif;font-size:12px;color:#000}
body{background:#008080;user-select:none}
button,input,select{font:inherit}
.desktop{position:absolute;inset:0 0 34px;background:linear-gradient(135deg,#007b7b,#009292 55%,#006c6c);overflow:hidden}
.desktop::after{content:"ApacheBAS Desktop";position:absolute;right:22px;bottom:17px;color:#ffffff28;font-size:42px;font-weight:900;letter-spacing:-2px;pointer-events:none}
.desktop-icons{position:absolute;inset:8px 0 0 8px;display:grid;grid-template-columns:repeat(auto-fill,88px);grid-auto-rows:92px;align-content:start;gap:2px 4px;padding-right:90px;overflow:auto}
.icon{width:84px;height:88px;border:1px solid transparent;background:transparent;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;padding:4px 3px;cursor:default;text-align:center;text-shadow:1px 1px #000;outline:none}
.icon img{width:42px;height:42px;image-rendering:auto;pointer-events:none;filter:drop-shadow(1px 1px 0 #003f3f)}
.icon .label{margin-top:4px;line-height:14px;max-width:80px;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;padding:1px 2px}
.icon.selected .label,.icon:focus .label{background:#000080;color:#fff;outline:1px dotted #fff}
.icon.selected img{filter:drop-shadow(1px 1px 0 #003f3f) saturate(.7) brightness(.85)}
.selection-box{display:none;position:fixed;border:1px dotted #000;outline:1px dotted #fff;background:#0000802b;z-index:1250;pointer-events:none}
.selection-box.visible{display:block}
.page-nav{position:absolute;right:10px;top:10px;background:var(--silver);padding:5px;border:2px outset #fff;display:flex;gap:4px;align-items:center;z-index:2}
.classic-btn{min-height:24px;background:var(--silver);border:2px outset #fff;padding:2px 10px;color:#000;cursor:pointer}
.classic-btn:active{border-style:inset;padding:3px 9px 1px 11px}
.classic-btn[disabled]{color:#777;text-shadow:1px 1px #fff;cursor:default}
.window{position:absolute;background:var(--silver);border:2px outset #fff;box-shadow:2px 2px 0 #0007;min-width:300px;min-height:180px;z-index:20}
.window.hidden{display:none}
.window.maximized{left:0!important;top:0!important;width:100%!important;height:calc(100% - 34px)!important}
#explorerWindow{left:155px;top:55px;width:min(790px,calc(100% - 190px));height:min(540px,calc(100% - 95px))}
#viewerWindow{left:290px;top:105px;width:min(660px,calc(100% - 330px));height:min(470px,calc(100% - 145px))}
#aboutWindow{left:calc(50% - 190px);top:calc(50% - 130px);width:380px;height:260px}
.titlebar{height:24px;background:linear-gradient(90deg,#000080,#1084d0);color:#fff;font-weight:700;display:flex;align-items:center;justify-content:space-between;padding:2px 3px 2px 5px;cursor:move}
.titlebar.inactive{background:linear-gradient(90deg,#7f7f7f,#b5b5b5)}
.titletext{display:flex;align-items:center;gap:5px;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.titletext img{width:16px;height:16px}
.win-controls{display:flex;gap:2px}
.win-controls button{width:20px;height:18px;padding:0;line-height:14px;font-weight:900;background:var(--silver);border:2px outset #fff;color:#000;cursor:pointer}
.win-controls button:active{border-style:inset}
.menubar{height:24px;display:flex;align-items:center;padding:1px 4px;border-bottom:1px solid #808080;background:var(--silver)}
.menugroup{position:relative;height:100%}
.menubutton{height:100%;border:0;background:transparent;padding:2px 8px;cursor:default}
.menubutton:hover,.menugroup.open>.menubutton{background:#000080;color:#fff}
.dropdown{display:none;position:absolute;top:22px;left:0;min-width:170px;background:var(--silver);border:2px outset #fff;padding:2px;z-index:100}
.menugroup.open .dropdown{display:block}
.dropdown button{width:100%;text-align:left;border:0;background:transparent;padding:5px 18px 5px 22px;white-space:nowrap;position:relative}
.dropdown button:hover{background:#000080;color:#fff}
.dropdown button:disabled{color:#777;background:transparent}
.dropdown .sep{height:1px;background:#808080;border-bottom:1px solid #fff;margin:3px 2px}
.toolbar{height:35px;display:flex;align-items:center;gap:4px;padding:4px;border-top:1px solid #fff;border-bottom:1px solid #808080;overflow:hidden;white-space:nowrap}
.toolbar .classic-btn{padding:1px 8px;min-height:25px}
.address-row{height:33px;display:flex;align-items:center;gap:5px;padding:4px;border-bottom:1px solid #808080;min-width:0}
.address-label{padding-left:3px;flex:0 0 auto}
.address{height:24px;flex:1 1 0;min-width:0;width:0;background:#fff;border:2px inset #fff;padding:3px 5px;white-space:nowrap;overflow:auto;text-overflow:clip;user-select:text;color:#000}
.window-body{position:absolute;left:3px;right:3px;top:116px;bottom:24px;background:#fff;border:2px inset #fff;overflow:auto}
.explorer-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(92px,1fr));grid-auto-rows:94px;align-content:start;gap:2px;padding:8px;min-height:100%}
.explorer-grid .icon{color:#000;text-shadow:none}
.explorer-grid .icon.selected .label,.explorer-grid .icon:focus .label{background:#000080;color:#fff;outline:1px dotted #000}
.statusbar{position:absolute;left:3px;right:3px;bottom:3px;height:20px;display:flex;gap:3px}
.statuspart{border:2px inset #fff;padding:1px 5px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;flex:1}
.statuspart.small{flex:0 0 120px;text-align:right}
.viewer-toolbar{position:absolute;left:3px;right:3px;top:27px;height:31px;display:flex;align-items:center;gap:5px;padding:3px 4px;border-top:1px solid #fff;border-bottom:1px solid #808080}
.viewer-toolbar .spacer{flex:1}
#viewerLocation{min-width:0;max-width:45%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.viewer-body{position:absolute;left:3px;right:3px;top:58px;bottom:3px;background:#fff;border:2px inset #fff;overflow:auto;display:flex;align-items:center;justify-content:center}
.viewer-body pre{width:100%;height:100%;margin:0;padding:12px;white-space:pre-wrap;word-break:break-word;font:13px Consolas,"Courier New",monospace;user-select:text}
.viewer-body img{max-width:100%;max-height:100%;object-fit:contain}
.viewer-body iframe{width:100%;height:100%;border:0;background:#fff}
.viewer-body video{max-width:100%;max-height:100%}
.viewer-body audio{width:min(500px,90%)}
.about{padding:18px 20px;line-height:1.5;user-select:text}
.about h2{margin:0 0 10px;display:flex;align-items:center;gap:10px}
.about h2 img{width:42px;height:42px}
.about .rule{height:2px;border-top:1px solid #808080;border-bottom:1px solid #fff;margin:12px 0}
.about-actions{text-align:right;margin-top:16px}
.taskbar{position:absolute;left:0;right:0;bottom:0;height:34px;background:var(--silver);border-top:2px outset #fff;display:flex;align-items:center;padding:2px 4px;z-index:1000;gap:4px}
.start-button{height:28px;font-weight:700;padding:2px 8px 2px 5px;display:flex;align-items:center;gap:4px;background:var(--silver);border:2px outset #fff}
.start-button img{width:20px;height:20px}
.start-button.active{border-style:inset;background:#ddd}
.task-separator{height:26px;border-left:1px solid #808080;border-right:1px solid #fff;margin:0 2px}
.task-button{height:27px;min-width:120px;max-width:210px;text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;background:var(--silver);border:2px outset #fff;padding:2px 8px;display:none}
.task-button.visible{display:block}
.task-button.active{border-style:inset;background:#e1e1e1;font-weight:700}
.tray{margin-left:auto;height:27px;min-width:94px;border:2px inset #fff;display:flex;align-items:center;justify-content:center;padding:0 8px;gap:7px}
.tray-dot{width:8px;height:8px;background:#19a741;border-radius:50%;box-shadow:0 0 0 1px #006b1a}
.start-menu{display:none;position:absolute;left:3px;bottom:33px;width:245px;background:var(--silver);border:2px outset #fff;z-index:1100;padding-left:27px;box-shadow:2px 2px 0 #0007}
.start-menu.open{display:block}
.start-side{position:absolute;left:2px;top:2px;bottom:2px;width:25px;background:linear-gradient(#000080,#1084d0);color:#fff;writing-mode:vertical-rl;transform:rotate(180deg);font-size:16px;font-weight:700;padding:7px 3px;letter-spacing:1px}
.start-items{padding:3px}
.start-item{width:100%;height:43px;border:0;background:transparent;text-align:left;display:flex;align-items:center;gap:10px;padding:4px 8px;cursor:default}
.start-item:hover{background:#000080;color:#fff}
.start-item img{width:30px;height:30px}
.start-sep{height:1px;background:#808080;border-bottom:1px solid #fff;margin:3px}
.context-menu{display:none;position:absolute;min-width:175px;background:var(--silver);border:2px outset #fff;padding:2px;z-index:1300;box-shadow:2px 2px 0 #0006}
.context-menu.open{display:block}
.context-menu button{display:block;width:100%;border:0;background:transparent;text-align:left;padding:5px 20px;white-space:nowrap}
.context-menu button:hover:not(:disabled){background:#000080;color:#fff}
.context-menu button:disabled{color:#777;text-shadow:1px 1px #fff}
.context-menu .sep{height:1px;background:#808080;border-bottom:1px solid #fff;margin:3px}
.modal-shade{display:none;position:absolute;inset:0 0 34px;background:#0004;z-index:1400}
.modal-shade.open{display:block}
.dialog{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(390px,calc(100% - 30px));background:var(--silver);border:2px outset #fff;box-shadow:3px 3px 0 #0008}
.dialog-content{padding:18px 16px 12px;line-height:1.45}
.dialog-content label{display:block;margin-bottom:5px}
.dialog-content input{width:100%;height:25px;background:#fff;border:2px inset #fff;padding:3px 5px;user-select:text}
.dialog-message{white-space:pre-wrap;user-select:text}
.dialog-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:15px}
.desktop-error{position:absolute;left:110px;right:110px;top:9px;background:#fff6c5;border:2px outset #fff;padding:8px;z-index:3;color:#700}
.hidden{display:none!important}
@media(max-width:720px){#explorerWindow,#viewerWindow{left:4px;top:4px;width:calc(100% - 8px);height:calc(100% - 42px)}.desktop-icons{grid-template-columns:repeat(auto-fill,82px)}.task-button{min-width:80px}.desktop::after{display:none}.page-nav{top:auto;bottom:8px}.window-body{top:116px}.menubar{overflow:visible}}
</style>
</head>
<body>
<div id="desktop" class="desktop">
  <div id="rootError" class="desktop-error hidden"></div>
  <div id="desktopIcons" class="desktop-icons" aria-label="Server desktop"></div>
  <div id="desktopPager" class="page-nav hidden"><button id="desktopPrev" class="classic-btn">◀</button><span id="desktopPageText">Page 1</span><button id="desktopNext" class="classic-btn">▶</button></div>
</div>

<section id="explorerWindow" class="window <?= EXPLORER_CLASS$ ?>" data-window="explorer">
  <div class="titlebar"><div class="titletext"><img src="assets/icons/folder.svg" alt=""> <span id="explorerTitle">Desktop Explorer</span></div><div class="win-controls"><button data-min="explorer" title="Minimize">_</button><button data-max="explorer" title="Maximize">□</button><button data-close="explorer" title="Close">×</button></div></div>
  <div class="menubar">
    <div class="menugroup"><button class="menubutton">File</button><div class="dropdown"><button data-cmd="open">Open</button><button data-cmd="download">Download</button><div class="sep"></div><button data-cmd="mkdir">New Folder...</button><button data-cmd="upload">Upload Image...</button><div class="sep"></div><button data-close="explorer">Close</button></div></div>
    <div class="menugroup"><button class="menubutton">Edit</button><div class="dropdown"><button data-cmd="copy">Copy...</button><button data-cmd="move">Move...</button><button data-cmd="rename">Rename...</button><button data-cmd="delete">Delete...</button></div></div>
    <div class="menugroup"><button class="menubutton">View</button><div class="dropdown"><button data-cmd="refresh">Refresh</button><button data-cmd="properties">Properties</button></div></div>
    <div class="menugroup"><button class="menubutton">Help</button><div class="dropdown"><button data-cmd="about">About ApacheBAS Desktop</button></div></div>
  </div>
  <div class="toolbar"><button id="backButton" class="classic-btn">Back</button><button id="upButton" class="classic-btn">Up</button><button class="classic-btn" data-cmd="mkdir">New Folder</button><button class="classic-btn" data-cmd="upload">Upload Image</button><button class="classic-btn" data-cmd="refresh">Refresh</button></div>
  <div class="address-row"><label class="address-label" for="addressBar">Address</label><input id="addressBar" class="address" value="Desktop" readonly spellcheck="false"></div>
  <div class="window-body"><div id="explorerGrid" class="explorer-grid"></div></div>
  <div class="statusbar"><div id="explorerStatus" class="statuspart">Ready</div><div id="explorerPageStatus" class="statuspart small">Page 1</div></div>
</section>

<section id="viewerWindow" class="window hidden" data-window="viewer">
  <div class="titlebar"><div class="titletext"><img id="viewerTitleIcon" src="assets/icons/unknown.svg" alt=""><span id="viewerTitle">Viewer</span></div><div class="win-controls"><button data-min="viewer">_</button><button data-max="viewer">□</button><button data-close="viewer">×</button></div></div>
  <div class="viewer-toolbar"><button id="viewerDesktopButton" class="classic-btn">Desktop</button><button id="viewerNewWindowButton" class="classic-btn">Open in new window</button><div class="spacer"></div><span id="viewerLocation">Desktop</span></div>
  <div id="viewerBody" class="viewer-body"></div>
</section>

<section id="aboutWindow" class="window hidden" data-window="about">
  <div class="titlebar"><div class="titletext"><img src="assets/icons/computer.svg" alt=""><span>About ApacheBAS Desktop</span></div><div class="win-controls"><button data-close="about">×</button></div></div>
  <div class="about"><h2><img src="assets/icons/computer.svg" alt="">ApacheBAS Desktop</h2><div>Classic browser desktop v1.1.1 for ApacheBAS-ASM v0.1.33.3.</div><div class="rule"></div><div>The visible server desktop is the application directory:</div><p><b>apachebas-desktop\desktop\</b></p><div>File operations are restricted to that directory. BASIC applications can be launched through Apache; native EXE/CMD/PowerShell execution is intentionally unavailable.</div><div class="about-actions"><button class="classic-btn" data-close="about">OK</button></div></div>
</section>

<div id="startMenu" class="start-menu"><div class="start-side">ApacheBAS</div><div class="start-items">
  <button class="start-item" data-start="explorer"><img src="assets/icons/computer.svg" alt=""><span><b>File Explorer</b><br>Browse the server desktop</span></button>
  <button class="start-item" data-start="refresh"><img src="assets/icons/refresh.svg" alt=""><span><b>Refresh Desktop</b><br>Reload files and folders</span></button>
  <div class="start-sep"></div>
  <button class="start-item" data-start="about"><img src="assets/icons/info.svg" alt=""><span><b>About</b><br>ApacheBAS Desktop</span></button>
</div></div>

<div id="contextMenu" class="context-menu"><button data-context="open"><b>Open</b></button><button data-context="download">Download</button><div class="sep"></div><button data-context="copy">Copy...</button><button data-context="move">Move...</button><button data-context="rename">Rename...</button><button data-context="delete">Delete...</button><div class="sep"></div><button data-context="properties">Properties</button></div>

<div id="selectionBox" class="selection-box"></div>
<div id="modalShade" class="modal-shade"><div class="dialog"><div class="titlebar"><div id="dialogTitle" class="titletext">ApacheBAS Desktop</div></div><div class="dialog-content"><div id="dialogMessage" class="dialog-message"></div><label id="dialogLabel" class="hidden" for="dialogInput"></label><input id="dialogInput" class="hidden" autocomplete="off"><div class="dialog-actions"><button id="dialogCancel" class="classic-btn">Cancel</button><button id="dialogOk" class="classic-btn">OK</button></div></div></div></div>

<div class="taskbar"><button id="startButton" class="start-button"><img src="assets/icons/start.svg" alt="">Start</button><div class="task-separator"></div><button id="explorerTask" class="task-button">Desktop Explorer</button><button id="viewerTask" class="task-button">Viewer</button><button id="aboutTask" class="task-button">About</button><div class="tray"><span class="tray-dot"></span><span id="clock">00:00</span></div></div>
<input id="uploadInput" class="hidden" type="file" accept="image/png,image/jpeg,image/gif,image/webp">
<pre id="rootRaw" class="hidden"><?bas PRINT HTML$(ROOT_RAW$) ?></pre>
<pre id="currentRaw" class="hidden"><?bas PRINT HTML$(CURRENT_RAW$) ?></pre>
<script>
'use strict';
const initial={dirHex:'<?= DIRHEX$ ?>',page:<?= PAGE ?>,dpage:<?= DPAGE ?>,explorerOpen:<?= EXPLORER_OPEN ?>===1,client:'<?= JSON$(SERVER_REMOTE_ADDR$) ?>'};
const rootError='<?= JSON$(ROOT_ERROR$) ?>';
const currentError='<?= JSON$(CURRENT_ERROR$) ?>';
const $=id=>document.getElementById(id);
const iconBase='assets/icons/';
const dangerousNative=new Set(['exe','com','bat','cmd','ps1','psm1','vbs','vbe','jscript','msi','msp','scr','dll','cpl','reg']);
const textTypes=new Set(['txt','md','csv','log','json','xml','ini','cfg']);
const imageTypes=new Set(['png','jpg','jpeg','gif','webp','bmp','svg']);
const audioTypes=new Set(['mp3','wav','ogg','m4a']);
const videoTypes=new Set(['mp4','webm','ogv']);
let zCounter=30,activeItem=null,contextItem=null,dialogResolver=null,activeScope='desktop',viewerItem=null,suppressBlankClick=false;
const lastSelectedIndex={desktop:-1,explorer:-1};
let rootList=parseList($('rootRaw').textContent,'');
let currentList=parseList($('currentRaw').textContent,initial.dirHex);

function decodeHex(hex){if(!hex)return'';const bytes=[];for(let i=0;i+1<hex.length;i+=2)bytes.push(parseInt(hex.slice(i,i+2),16));try{return new TextDecoder().decode(new Uint8Array(bytes))}catch(e){return String.fromCharCode(...bytes)}}
function encodeHex(text){const bytes=new TextEncoder().encode(text);return Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('').toUpperCase()}
function joinHex(dirHex,nameHex){return dirHex?dirHex+'5C'+nameHex:nameHex}
function parseList(raw,baseHex){const result={meta:{parent:'',page:0,more:false},items:[]};for(const line of raw.replace(/\r/g,'').split('\n')){if(!line)continue;const p=line.split('|');if(p[0]==='M'){result.meta={parent:p[1]||'',page:Number(p[2]||0),more:p[3]==='1'};continue}if((p[0]==='D'||p[0]==='F')&&p[1]){const name=decodeHex(p[1]);result.items.push({kind:p[0],nameHex:p[1],name,size:Number(p[2]||0),baseHex,fullHex:joinHex(baseHex,p[1])})}}return result}
function extension(name){const i=name.lastIndexOf('.');return i>0?name.slice(i+1).toLowerCase():''}
function iconFor(item){if(item.special)return item.icon;if(item.kind==='D')return'folder.svg';const ext=extension(item.name);if(ext==='bas')return'app.svg';if(imageTypes.has(ext))return'image.svg';if(textTypes.has(ext))return'text.svg';if(ext==='pdf')return'pdf.svg';if(ext==='zip'||ext==='7z'||ext==='rar')return'archive.svg';if(ext==='html'||ext==='htm')return'web.svg';if(audioTypes.has(ext)||videoTypes.has(ext))return'media.svg';if(dangerousNative.has(ext))return'executable.svg';return'unknown.svg'}
function formatSize(n){if(!Number.isFinite(n))return'';if(n<1024)return n+' bytes';if(n<1048576)return(n/1024).toFixed(1)+' KB';if(n<1073741824)return(n/1048576).toFixed(1)+' MB';return(n/1073741824).toFixed(1)+' GB'}
function pathText(hex){const p=decodeHex(hex);return p?'Desktop\\'+p:'Desktop'}
function fileUrl(fullHex){const rel=decodeHex(fullHex);return'desktop/'+rel.split(/[\\/]/).map(encodeURIComponent).join('/')}
function navigate(params){const q=new URLSearchParams(location.search);for(const [k,v] of Object.entries(params)){if(v===null||v===undefined||v==='')q.delete(k);else q.set(k,String(v))}location.href='desktop.bas'+(q.toString()?'?'+q.toString():'')}
function scopeIcons(scope){return Array.from(document.querySelectorAll(`.icon[data-scope="${scope}"]`))}
function selectedButtons(scope=activeScope){return scopeIcons(scope).filter(button=>button.classList.contains('selected'))}
function selectedItems(scope=activeScope){return selectedButtons(scope).map(button=>button._item)}
function clearSelection(scope=null){const query=scope?`.icon[data-scope="${scope}"].selected`:'.icon.selected';document.querySelectorAll(query).forEach(x=>x.classList.remove('selected'));if(!scope||scope===activeScope){activeItem=null;contextItem=null}updateSelectionStatus(scope||activeScope)}
function updateSelectionStatus(scope=activeScope){if(scope!=='explorer')return;const items=selectedItems('explorer');if(!items.length){$('explorerStatus').textContent='Ready';return}const real=items.filter(item=>!item.special);const files=real.filter(item=>item.kind==='F');const total=files.reduce((sum,item)=>sum+(Number(item.size)||0),0);$('explorerStatus').textContent=items.length+' object'+(items.length===1?'':'s')+' selected'+(total?' · '+formatSize(total):'')}
function syncActiveItem(scope){const buttons=selectedButtons(scope);activeItem=buttons.length?buttons[buttons.length-1]._item:null;contextItem=activeItem;updateSelectionStatus(scope)}
function renderIcon(item,scope){const button=document.createElement('button');button.className='icon';button.type='button';button.dataset.scope=scope;button.title=item.name;button._item=item;button.innerHTML=`<img src="${iconBase+iconFor(item)}" alt=""><span class="label"></span>`;button.querySelector('.label').textContent=item.name;button.addEventListener('click',e=>selectItem(button,item,scope,e));button.addEventListener('dblclick',e=>{e.stopPropagation();if(selectedButtons(scope).length<=1)openItem(item)});button.addEventListener('contextmenu',e=>{e.preventDefault();selectItem(button,item,scope,e,true);showContext(e.clientX,e.clientY,item)});return button}
function selectItem(button,item,scope,event,contextClick=false){if(activeScope!==scope){clearSelection();activeScope=scope;lastSelectedIndex[scope]=-1}const icons=scopeIcons(scope),index=icons.indexOf(button);if(contextClick){if(!button.classList.contains('selected')){clearSelection(scope);button.classList.add('selected')}}else if(event?.shiftKey&&lastSelectedIndex[scope]>=0){if(!event.ctrlKey&&!event.metaKey)clearSelection(scope);const a=Math.min(lastSelectedIndex[scope],index),b=Math.max(lastSelectedIndex[scope],index);for(let i=a;i<=b;i++)icons[i].classList.add('selected')}else if(event?.ctrlKey||event?.metaKey){button.classList.toggle('selected')}else{clearSelection(scope);button.classList.add('selected')}if(button.classList.contains('selected'))lastSelectedIndex[scope]=index;syncActiveItem(scope);contextItem=item;event?.stopPropagation()}
function renderDesktop(){const host=$('desktopIcons');host.textContent='';const specials=[{special:true,kind:'D',name:'My Computer',icon:'computer.svg',action:'computer'},{special:true,kind:'D',name:'Network Neighborhood',icon:'network.svg',action:'network'},{special:true,kind:'D',name:'Recycle Bin',icon:'recycle.svg',action:'recycle'}];for(const item of [...specials,...rootList.items])host.appendChild(renderIcon(item,'desktop'));const pager=$('desktopPager');const needed=rootList.meta.page>0||rootList.meta.more;pager.classList.toggle('hidden',!needed);$('desktopPageText').textContent='Page '+(rootList.meta.page+1);$('desktopPrev').disabled=rootList.meta.page<=0;$('desktopNext').disabled=!rootList.meta.more}
function renderExplorer(){const host=$('explorerGrid');host.textContent='';if(currentError){host.textContent='Directory error: '+currentError;return}if(!currentList.items.length){const empty=document.createElement('div');empty.style.cssText='padding:25px;color:#666;grid-column:1/-1';empty.textContent='This folder is empty.';host.appendChild(empty)}else for(const item of currentList.items)host.appendChild(renderIcon(item,'explorer'));$('addressBar').value=pathText(initial.dirHex);$('addressBar').title=pathText(initial.dirHex);$('explorerTitle').textContent=pathText(initial.dirHex)+' - Desktop Explorer';$('explorerPageStatus').textContent='Page '+(currentList.meta.page+1)+(currentList.meta.more?' · more':'');$('upButton').disabled=!initial.dirHex;$('explorerTask').classList.toggle('visible',!$('explorerWindow').classList.contains('hidden'));bringToFront($('explorerWindow'))}
function openItem(item){hideMenus();if(item.special){if(item.action==='computer'){navigate({explorer:1,dir:null,page:0});return}if(item.action==='network'){showMessage('Network Neighborhood','This desktop is connected to the Apache server at '+location.host+'.\n\nRemote access is controlled by the application .htaccess file.');return}if(item.action==='recycle'){showMessage('Recycle Bin','The Recycle Bin is decorative in this version. Delete operations are permanent and require confirmation.');return}}if(item.kind==='D'){navigate({explorer:1,dir:item.fullHex,page:0});return}const ext=extension(item.name);if(dangerousNative.has(ext)){showMessage('Execution blocked','Native '+ext.toUpperCase()+' files are not launched from the browser. This prevents the desktop from becoming a command shell. You may download the file instead.');return}openViewer(item)}
async function openViewer(item){const body=$('viewerBody');body.textContent='';viewerItem=item;$('viewerTitle').textContent=item.name;$('viewerTitleIcon').src=iconBase+iconFor(item);$('viewerLocation').textContent=pathText(item.baseHex);const ext=extension(item.name),url=fileUrl(item.fullHex);try{if(ext==='bas'||ext==='html'||ext==='htm'||ext==='pdf'){const frame=document.createElement('iframe');frame.src=url;frame.title=item.name;body.appendChild(frame)}else if(textTypes.has(ext)){const r=await fetch(url,{cache:'no-store'});if(!r.ok)throw new Error('HTTP '+r.status);const pre=document.createElement('pre');pre.textContent=await r.text();body.appendChild(pre)}else if(imageTypes.has(ext)){const img=document.createElement('img');img.src=url;img.alt=item.name;body.appendChild(img)}else if(videoTypes.has(ext)){const v=document.createElement('video');v.src=url;v.controls=true;v.autoplay=false;body.appendChild(v)}else if(audioTypes.has(ext)){const a=document.createElement('audio');a.src=url;a.controls=true;body.appendChild(a)}else{await downloadItem(item);return}showWindow('viewer')}catch(error){showMessage('Open failed',String(error.message||error))}}
function showWindow(name){const win=$(name+'Window');win.classList.remove('hidden');$(name+'Task')?.classList.add('visible');bringToFront(win)}
function hideWindow(name){$(name+'Window').classList.add('hidden');$(name+'Task')?.classList.remove('visible');if(name==='viewer')$('viewerBody').textContent=''}
function bringToFront(win){if(!win||win.classList.contains('hidden'))return;win.style.zIndex=String(++zCounter);document.querySelectorAll('.window .titlebar').forEach(x=>x.classList.add('inactive'));win.querySelector('.titlebar')?.classList.remove('inactive');document.querySelectorAll('.task-button').forEach(x=>x.classList.remove('active'));$(win.dataset.window+'Task')?.classList.add('active')}
function makeDraggable(win){const bar=win.querySelector('.titlebar');let sx=0,sy=0,sl=0,st=0,drag=false;bar.addEventListener('mousedown',e=>{if(e.target.closest('button')||win.classList.contains('maximized'))return;drag=true;sx=e.clientX;sy=e.clientY;sl=win.offsetLeft;st=win.offsetTop;bringToFront(win);e.preventDefault()});window.addEventListener('mousemove',e=>{if(!drag)return;win.style.left=Math.max(0,sl+e.clientX-sx)+'px';win.style.top=Math.max(0,st+e.clientY-sy)+'px'});window.addEventListener('mouseup',()=>drag=false)}
function hideMenus(){document.querySelectorAll('.menugroup.open').forEach(x=>x.classList.remove('open'));$('contextMenu').classList.remove('open');$('startMenu').classList.remove('open');$('startButton').classList.remove('active')}
function showContext(x,y,item){contextItem=item;const menu=$('contextMenu');menu.classList.add('open');const items=selectedItems(activeScope);const one=items.length===1&&!items[0].special;menu.querySelector('[data-context="download"]').style.display=one&&items[0].kind==='F'?'block':'none';menu.querySelector('[data-context="rename"]').disabled=!one;menu.querySelector('[data-context="properties"]').disabled=!one;const rect=menu.getBoundingClientRect();menu.style.left=Math.min(x,innerWidth-rect.width-3)+'px';menu.style.top=Math.min(y,innerHeight-rect.height-36)+'px'}
function requireItems(){const items=selectedItems(activeScope);if(!items.length)throw new Error('Select one or more files or folders first.');if(items.some(item=>item.special))throw new Error('System desktop icons cannot be used in this operation.');return items}
function requireSingleItem(){const items=requireItems();if(items.length!==1)throw new Error('This operation requires exactly one selected item.');return items[0]}
async function api(op,data){const body=new URLSearchParams({op,...data});const r=await fetch('action.bas',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body,cache:'no-store',credentials:'same-origin'});let j;try{j=await r.json()}catch{throw new Error('Invalid server response')}if(!r.ok||!j.ok)throw new Error(j.error||('HTTP '+r.status));return j}
function currentDestinationHex(){return !$('explorerWindow').classList.contains('hidden')?initial.dirHex:''}
function validateRelativePath(text){const value=text.trim().replace(/\//g,'\\').replace(/^Desktop\\?/i,'');if(!value)return'';const parts=value.split('\\');if(parts.some(p=>!p||p==='.'||p==='..'||/[\\/:*?"<>|]/.test(p)))throw new Error('Use a relative folder path such as Documents or Documents\\Reports.');return encodeHex(value)}
async function command(name){hideMenus();try{if(name==='open'){openItem(requireSingleItem());return}if(name==='download'){await downloadItem(requireSingleItem());return}if(name==='refresh'){location.reload();return}if(name==='about'){showWindow('about');return}if(name==='properties'){showProperties(requireSingleItem());return}if(name==='mkdir'){const folder=await askText('New Folder','Folder name:', 'New Folder');if(folder===null)return;await api('mkdir',{dst:currentDestinationHex(),name:folder});location.reload();return}if(name==='upload'){$('uploadInput').click();return}if(name==='rename'){const item=requireSingleItem();const newName=await askText('Rename','New name:',item.name);if(newName===null||newName===item.name)return;await api('rename',{src:item.fullHex,name:newName});location.reload();return}if(name==='delete'){const items=requireItems();const sample=items.slice(0,5).map(item=>'• '+item.name).join('\n');const extra=items.length>5?'\n• … and '+(items.length-5)+' more':'';if(!(await askConfirm('Delete',`Delete ${items.length} selected object${items.length===1?'':'s'} permanently?\n\n${sample}${extra}\n\nFolders must be empty.`)))return;for(const item of items)await api('delete',{src:item.fullHex});location.reload();return}if(name==='copy'||name==='move'){const items=requireItems();if(name==='copy'&&items.some(item=>item.kind==='D'))throw new Error('Folder copy is not supported. Select files only, or move folders.');const suggestion=!$('explorerWindow').classList.contains('hidden')?decodeHex(initial.dirHex):'';const dest=await askText(name==='copy'?'Copy selected items':'Move selected items','Destination folder relative to Desktop (leave empty for Desktop):',suggestion);if(dest===null)return;const dstHex=validateRelativePath(dest);for(const item of items)await api(name,{src:item.fullHex,dst:dstHex});location.reload();return}}catch(error){showMessage('Operation failed',String(error.message||error))}}
async function downloadItem(item){if(item.kind!=='F')throw new Error('Folders cannot be downloaded directly.');const slot=String(Date.now());const r=await fetch('export.bas?path='+encodeURIComponent(item.fullHex)+'&slot='+slot,{cache:'no-store',credentials:'same-origin'});const j=await r.json();if(!r.ok||!j.ok)throw new Error(j.error||'Download failed');const a=document.createElement('a');a.href=j.url+'?t='+Date.now();a.download=item.name;document.body.appendChild(a);a.click();a.remove()}
function showProperties(item){showMessage('Properties',`Name: ${item.name}\nType: ${item.kind==='D'?'File folder':(extension(item.name).toUpperCase()||'File')}\nLocation: ${pathText(item.baseHex)}\nSize: ${item.kind==='D'?'—':formatSize(item.size)}\nServer path: desktop\\${decodeHex(item.fullHex)}`)}
function openDialog(title,message,label,value,mode){$('dialogTitle').textContent=title;$('dialogMessage').textContent=message||'';$('dialogLabel').classList.toggle('hidden',!label);$('dialogInput').classList.toggle('hidden',!label);$('dialogLabel').textContent=label||'';$('dialogInput').value=value||'';$('dialogCancel').classList.toggle('hidden',mode==='message');$('modalShade').classList.add('open');if(label)setTimeout(()=>$('dialogInput').select(),0);return new Promise(resolve=>dialogResolver={resolve,mode,hasInput:!!label})}
function closeDialog(ok){if(!dialogResolver)return;const d=dialogResolver;dialogResolver=null;$('modalShade').classList.remove('open');if(d.mode==='message'){d.resolve(true);return}if(!ok){d.resolve(null);return}d.resolve(d.hasInput?$('dialogInput').value:true)}
function askText(title,label,value=''){return openDialog(title,'',label,value,'input')}
async function askConfirm(title,message){const r=await openDialog(title,message,'','', 'confirm');return r===true}
function showMessage(title,message){return openDialog(title,message,'','', 'message')}

function installRubberBand(host,scope){let active=false,startX=0,startY=0,dragging=false,baseSelected=new Set();host.addEventListener('mousedown',e=>{if(e.button!==0||e.target.closest('.icon')||e.target.closest('button,input'))return;active=true;activeScope=scope;startX=e.clientX;startY=e.clientY;dragging=false;baseSelected=new Set((e.ctrlKey||e.metaKey)?selectedButtons(scope):[]);if(!(e.ctrlKey||e.metaKey))clearSelection(scope);e.preventDefault();e.stopPropagation()});window.addEventListener('mousemove',e=>{if(!active)return;const dx=e.clientX-startX,dy=e.clientY-startY;if(!dragging&&Math.hypot(dx,dy)<4)return;dragging=true;const left=Math.min(startX,e.clientX),top=Math.min(startY,e.clientY),right=Math.max(startX,e.clientX),bottom=Math.max(startY,e.clientY);const box=$('selectionBox');box.style.left=left+'px';box.style.top=top+'px';box.style.width=(right-left)+'px';box.style.height=(bottom-top)+'px';box.classList.add('visible');for(const button of scopeIcons(scope)){const r=button.getBoundingClientRect();const hit=r.right>=left&&r.left<=right&&r.bottom>=top&&r.top<=bottom;button.classList.toggle('selected',hit||baseSelected.has(button))}syncActiveItem(scope)});window.addEventListener('mouseup',e=>{if(!active)return;const wasDragging=dragging;active=false;dragging=false;$('selectionBox').classList.remove('visible');if(!wasDragging)clearSelection(scope);else{suppressBlankClick=true;setTimeout(()=>suppressBlankClick=false,0)}syncActiveItem(scope);e.stopPropagation()})}
installRubberBand($('desktopIcons'),'desktop');
installRubberBand($('explorerGrid'),'explorer');
$('desktop').addEventListener('click',e=>{if(suppressBlankClick)return;if(!e.target.closest('.icon')&&!e.target.closest('.window')&&!e.target.closest('.page-nav'))clearSelection('desktop');hideMenus()});
$('desktopPrev').onclick=()=>navigate({dpage:Math.max(0,rootList.meta.page-1)});
$('desktopNext').onclick=()=>navigate({dpage:rootList.meta.page+1});
$('backButton').onclick=()=>history.back();
$('upButton').onclick=()=>navigate({explorer:1,dir:currentList.meta.parent||null,page:0});
$('startButton').onclick=e=>{e.stopPropagation();const open=$('startMenu').classList.toggle('open');$('startButton').classList.toggle('active',open);$('contextMenu').classList.remove('open')};
document.querySelectorAll('[data-start]').forEach(b=>b.onclick=()=>{const c=b.dataset.start;hideMenus();if(c==='explorer')navigate({explorer:1,dir:null,page:0});if(c==='refresh')location.reload();if(c==='about')showWindow('about')});
document.querySelectorAll('.menubutton').forEach(b=>b.onclick=e=>{e.stopPropagation();const group=b.parentElement;document.querySelectorAll('.menugroup.open').forEach(x=>{if(x!==group)x.classList.remove('open')});group.classList.toggle('open')});
document.querySelectorAll('[data-cmd]').forEach(b=>b.onclick=()=>command(b.dataset.cmd));
document.querySelectorAll('[data-context]').forEach(b=>b.onclick=()=>{activeItem=contextItem;command(b.dataset.context)});
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>hideWindow(b.dataset.close));
document.querySelectorAll('[data-min]').forEach(b=>b.onclick=()=>hideWindow(b.dataset.min));
document.querySelectorAll('[data-max]').forEach(b=>b.onclick=()=>{const w=$(b.dataset.max+'Window');w.classList.toggle('maximized');bringToFront(w)});
document.querySelectorAll('.window').forEach(w=>{makeDraggable(w);w.addEventListener('mousedown',()=>bringToFront(w))});
$('explorerTask').onclick=()=>{$('explorerWindow').classList.contains('hidden')?showWindow('explorer'):bringToFront($('explorerWindow'))};
$('viewerTask').onclick=()=>{$('viewerWindow').classList.contains('hidden')?showWindow('viewer'):bringToFront($('viewerWindow'))};
$('aboutTask').onclick=()=>{$('aboutWindow').classList.contains('hidden')?showWindow('about'):bringToFront($('aboutWindow'))};
$('viewerDesktopButton').onclick=()=>hideWindow('viewer');
$('viewerNewWindowButton').onclick=()=>{if(viewerItem)window.open(fileUrl(viewerItem.fullHex),'_blank','noopener')};
document.addEventListener('keydown',e=>{if($('modalShade').classList.contains('open')||e.target.matches('input,textarea'))return;if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='a'){e.preventDefault();clearSelection(activeScope);for(const button of scopeIcons(activeScope))button.classList.add('selected');syncActiveItem(activeScope)}if(e.key==='Escape')clearSelection(activeScope);if(e.key==='Delete'&&selectedItems(activeScope).length){e.preventDefault();command('delete')}});
$('dialogOk').onclick=()=>closeDialog(true);$('dialogCancel').onclick=()=>closeDialog(false);$('dialogInput').addEventListener('keydown',e=>{if(e.key==='Enter')closeDialog(true);if(e.key==='Escape')closeDialog(false)});
$('uploadInput').addEventListener('change',async()=>{const file=$('uploadInput').files[0];if(!file)return;if(file.size>1048576){showMessage('Upload failed','Images are limited to 1 MiB.');return}try{const dir=currentDestinationHex();const r=await fetch('upload.bas?dir='+encodeURIComponent(dir)+'&filename='+encodeURIComponent(file.name),{method:'POST',headers:{'Content-Type':file.type||'application/octet-stream'},body:file,credentials:'same-origin'});const j=await r.json();if(!r.ok||!j.ok)throw new Error(j.error||'Upload failed');location.reload()}catch(error){showMessage('Upload failed',String(error.message||error))}finally{$('uploadInput').value=''}});
document.addEventListener('click',e=>{if(!e.target.closest('.menugroup')&&!e.target.closest('#startMenu')&&!e.target.closest('#startButton')&&!e.target.closest('#contextMenu'))hideMenus()});
document.addEventListener('contextmenu',e=>{if(!e.target.closest('.icon'))hideMenus()});
function tick(){const d=new Date();$('clock').textContent=d.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}tick();setInterval(tick,1000);
if(rootError){$('rootError').textContent='Desktop listing error: '+rootError;$('rootError').classList.remove('hidden')}
renderDesktop();if(initial.explorerOpen)renderExplorer();
</script>
</body>
</html>
