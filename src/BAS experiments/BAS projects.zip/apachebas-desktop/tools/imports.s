        .section .idata$2,"dw"
        .p2align 2
dll0_descriptor:
        .rva dll0_ilt
        .long 0
        .long 0
        .rva dll0_name
        .rva dll0_iat

        .section .idata$3,"dw"
        .zero 20

        .section .idata$4,"dw"
        .p2align 2
dll0_ilt:
        .rva hn_ExitProcess
        .rva hn_GetCommandLineA
        .rva hn_GetModuleFileNameA
        .rva hn_GetFileAttributesA
        .rva hn_FindFirstFileA
        .rva hn_FindNextFileA
        .rva hn_FindClose
        .rva hn_CreateDirectoryA
        .rva hn_RemoveDirectoryA
        .rva hn_DeleteFileA
        .rva hn_MoveFileA
        .rva hn_CopyFileA
        .rva hn_GetLastError
        .rva hn_GetStdHandle
        .rva hn_WriteFile
        .long 0

        .section .idata$5,"dw"
        .p2align 2
dll0_iat:
        .globl __imp__ExitProcess@4
__imp__ExitProcess@4: .rva hn_ExitProcess
        .globl __imp__GetCommandLineA@0
__imp__GetCommandLineA@0: .rva hn_GetCommandLineA
        .globl __imp__GetModuleFileNameA@12
__imp__GetModuleFileNameA@12: .rva hn_GetModuleFileNameA
        .globl __imp__GetFileAttributesA@4
__imp__GetFileAttributesA@4: .rva hn_GetFileAttributesA
        .globl __imp__FindFirstFileA@8
__imp__FindFirstFileA@8: .rva hn_FindFirstFileA
        .globl __imp__FindNextFileA@8
__imp__FindNextFileA@8: .rva hn_FindNextFileA
        .globl __imp__FindClose@4
__imp__FindClose@4: .rva hn_FindClose
        .globl __imp__CreateDirectoryA@8
__imp__CreateDirectoryA@8: .rva hn_CreateDirectoryA
        .globl __imp__RemoveDirectoryA@4
__imp__RemoveDirectoryA@4: .rva hn_RemoveDirectoryA
        .globl __imp__DeleteFileA@4
__imp__DeleteFileA@4: .rva hn_DeleteFileA
        .globl __imp__MoveFileA@8
__imp__MoveFileA@8: .rva hn_MoveFileA
        .globl __imp__CopyFileA@12
__imp__CopyFileA@12: .rva hn_CopyFileA
        .globl __imp__GetLastError@0
__imp__GetLastError@0: .rva hn_GetLastError
        .globl __imp__GetStdHandle@4
__imp__GetStdHandle@4: .rva hn_GetStdHandle
        .globl __imp__WriteFile@20
__imp__WriteFile@20: .rva hn_WriteFile
        .long 0

        .section .idata$6,"dw"
        .p2align 1
hn_ExitProcess: .short 0; .asciz "ExitProcess"; .p2align 1
hn_GetCommandLineA: .short 0; .asciz "GetCommandLineA"; .p2align 1
hn_GetModuleFileNameA: .short 0; .asciz "GetModuleFileNameA"; .p2align 1
hn_GetFileAttributesA: .short 0; .asciz "GetFileAttributesA"; .p2align 1
hn_FindFirstFileA: .short 0; .asciz "FindFirstFileA"; .p2align 1
hn_FindNextFileA: .short 0; .asciz "FindNextFileA"; .p2align 1
hn_FindClose: .short 0; .asciz "FindClose"; .p2align 1
hn_CreateDirectoryA: .short 0; .asciz "CreateDirectoryA"; .p2align 1
hn_RemoveDirectoryA: .short 0; .asciz "RemoveDirectoryA"; .p2align 1
hn_DeleteFileA: .short 0; .asciz "DeleteFileA"; .p2align 1
hn_MoveFileA: .short 0; .asciz "MoveFileA"; .p2align 1
hn_CopyFileA: .short 0; .asciz "CopyFileA"; .p2align 1
hn_GetLastError: .short 0; .asciz "GetLastError"; .p2align 1
hn_GetStdHandle: .short 0; .asciz "GetStdHandle"; .p2align 1
hn_WriteFile: .short 0; .asciz "WriteFile"; .p2align 1
dll0_name: .asciz "KERNEL32.dll"; .p2align 1
