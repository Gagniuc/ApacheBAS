/*
  DesktopHelper.exe - sandboxed file helper for ApacheBAS Desktop.
  Win32 PE32, no C runtime, no shell execution.

  IMPORTANT SECURITY PROPERTY:
  Every operation is confined to the nearest parent directory named "desktop".
  Absolute paths, drive prefixes, traversal, and reparse points are rejected.
*/

typedef void *HANDLE;
typedef void *LPVOID;
typedef const char *LPCSTR;
typedef char *LPSTR;
typedef unsigned long DWORD;
typedef unsigned int UINT;
typedef int BOOL;
typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef long LONG;

#define NULL ((void *)0)
#define TRUE 1
#define FALSE 0
#define INVALID_HANDLE_VALUE ((HANDLE)(LONG)-1)
#define INVALID_FILE_ATTRIBUTES 0xFFFFFFFFUL
#define FILE_ATTRIBUTE_DIRECTORY 0x00000010UL
#define FILE_ATTRIBUTE_REPARSE_POINT 0x00000400UL
#define STD_OUTPUT_HANDLE ((DWORD)-11)
#define MOVEFILE_COPY_ALLOWED 0x00000002UL
#define PATH_CAP 768U
#define ARG_CAP 1900U
#define OUTPUT_CAP 2020U
#define PAGE_SIZE 8

typedef struct { DWORD dwLowDateTime; DWORD dwHighDateTime; } FILETIME;
typedef struct {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD nFileSizeHigh;
    DWORD nFileSizeLow;
    DWORD dwReserved0;
    DWORD dwReserved1;
    char cFileName[260];
    char cAlternateFileName[14];
} WIN32_FIND_DATAA;
typedef char WIN32_FIND_DATAA_size_must_be_320[(sizeof(WIN32_FIND_DATAA) == 320) ? 1 : -1];

__declspec(dllimport) void   __stdcall ExitProcess(UINT code);
__declspec(dllimport) char * __stdcall GetCommandLineA(void);
__declspec(dllimport) DWORD  __stdcall GetModuleFileNameA(HANDLE module, LPSTR filename, DWORD size);
__declspec(dllimport) DWORD  __stdcall GetFileAttributesA(LPCSTR filename);
__declspec(dllimport) HANDLE __stdcall FindFirstFileA(LPCSTR pattern, WIN32_FIND_DATAA *data);
__declspec(dllimport) BOOL   __stdcall FindNextFileA(HANDLE find, WIN32_FIND_DATAA *data);
__declspec(dllimport) BOOL   __stdcall FindClose(HANDLE find);
__declspec(dllimport) BOOL   __stdcall CreateDirectoryA(LPCSTR path, LPVOID security);
__declspec(dllimport) BOOL   __stdcall RemoveDirectoryA(LPCSTR path);
__declspec(dllimport) BOOL   __stdcall DeleteFileA(LPCSTR path);
__declspec(dllimport) BOOL   __stdcall MoveFileA(LPCSTR existing_name, LPCSTR new_name);
__declspec(dllimport) BOOL   __stdcall CopyFileA(LPCSTR existing_name, LPCSTR new_name, BOOL fail_if_exists);
__declspec(dllimport) DWORD  __stdcall GetLastError(void);
__declspec(dllimport) HANDLE __stdcall GetStdHandle(DWORD id);
__declspec(dllimport) BOOL   __stdcall WriteFile(HANDLE file, const void *buffer, DWORD bytes, DWORD *written, LPVOID overlapped);

static char module_path[PATH_CAP];
static char app_root[PATH_CAP];
static char storage_root[PATH_CAP];
static char uploads_root[PATH_CAP];
static char downloads_root[PATH_CAP];
static char arg_buffer[ARG_CAP];
static char work_a[PATH_CAP];
static char work_b[PATH_CAP];
static char rel_a[PATH_CAP];
static char rel_b[PATH_CAP];
static char name_a[260];
static char output_buffer[OUTPUT_CAP];
static DWORD output_length = 0;
static DWORD stdout_written = 0;

static DWORD s_len(const char *s) { DWORD n = 0; if (!s) return 0; while (s[n]) ++n; return n; }
static BOOL s_copy(char *dst, DWORD cap, const char *src) {
    DWORD i = 0; if (!dst || !src || cap == 0) return FALSE;
    while (src[i]) { if (i + 1 >= cap) return FALSE; dst[i] = src[i]; ++i; }
    dst[i] = 0; return TRUE;
}
static BOOL s_append(char *dst, DWORD cap, const char *src) {
    DWORD n = s_len(dst), i = 0; if (!dst || !src || n >= cap) return FALSE;
    while (src[i]) { if (n + i + 1 >= cap) return FALSE; dst[n + i] = src[i]; ++i; }
    dst[n + i] = 0; return TRUE;
}
static BOOL s_equal_ci(const char *a, const char *b) {
    DWORD i = 0; char ca, cb; if (!a || !b) return FALSE;
    for (;;) {
        ca = a[i]; cb = b[i];
        if (ca >= 'A' && ca <= 'Z') ca = (char)(ca + 32);
        if (cb >= 'A' && cb <= 'Z') cb = (char)(cb + 32);
        if (ca != cb) return FALSE;
        if (!ca) return TRUE;
        ++i;
    }
}
static BOOL s_starts_ci(const char *text, const char *prefix) {
    DWORD i = 0; char a, b;
    while (prefix[i]) {
        a = text[i]; b = prefix[i];
        if (a >= 'A' && a <= 'Z') a = (char)(a + 32);
        if (b >= 'A' && b <= 'Z') b = (char)(b + 32);
        if (a != b) return FALSE;
        ++i;
    }
    return TRUE;
}
static BOOL strip_last_component(char *path) {
    DWORD n = s_len(path); if (!n) return FALSE;
    while (n && (path[n-1] == '\\' || path[n-1] == '/')) path[--n] = 0;
    while (n) { if (path[n-1] == '\\' || path[n-1] == '/') { path[n-1] = 0; return TRUE; } --n; }
    return FALSE;
}
static const char *base_name(const char *path) {
    const char *p = path, *last = path;
    while (*p) { if (*p == '\\' || *p == '/') last = p + 1; ++p; }
    return last;
}
static BOOL append_char(char *dst, DWORD cap, char c) {
    DWORD n = s_len(dst); if (n + 1 >= cap) return FALSE; dst[n] = c; dst[n+1] = 0; return TRUE;
}
static void out_reset(void) { output_length = 0; output_buffer[0] = 0; }
static BOOL out_text(const char *text) {
    DWORD i = 0; if (!text) return FALSE;
    while (text[i]) { if (output_length + 1 >= OUTPUT_CAP) return FALSE; output_buffer[output_length++] = text[i++]; }
    output_buffer[output_length] = 0; return TRUE;
}
static BOOL out_char(char c) {
    if (output_length + 1 >= OUTPUT_CAP) return FALSE;
    output_buffer[output_length++] = c; output_buffer[output_length] = 0; return TRUE;
}
static BOOL out_uint(DWORD value) {
    char temp[16]; DWORD n = 0;
    if (value == 0) return out_char('0');
    while (value && n < 15) { temp[n++] = (char)('0' + (value % 10)); value /= 10; }
    while (n) if (!out_char(temp[--n])) return FALSE;
    return TRUE;
}
static BOOL out_hex(const char *text) {
    static const char digits[] = "0123456789ABCDEF";
    DWORD i = 0; unsigned char c;
    while (text && text[i]) {
        c = (unsigned char)text[i++];
        if (!out_char(digits[c >> 4]) || !out_char(digits[c & 15])) return FALSE;
    }
    return TRUE;
}
static void flush_and_exit(UINT code) {
    HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);
    if (out && out != INVALID_HANDLE_VALUE && output_length) WriteFile(out, output_buffer, output_length, &stdout_written, NULL);
    ExitProcess(code);
}
static void error_exit(DWORD code, const char *message) {
    out_reset(); out_text("ERR|"); out_uint(code); out_text("|"); out_text(message); flush_and_exit(1);
}
static void ok_exit(const char *message) {
    out_reset(); out_text("OK|"); out_text(message ? message : "Done"); flush_and_exit(0);
}
static int hex_value(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}
static BOOL hex_decode(const char *hex, char *dst, DWORD cap) {
    DWORD i = 0, n = 0; int a, b;
    if (!hex || !dst || cap == 0) return FALSE;
    while (hex[i]) {
        a = hex_value(hex[i++]); if (a < 0 || !hex[i]) return FALSE;
        b = hex_value(hex[i++]); if (b < 0) return FALSE;
        if (n + 1 >= cap) return FALSE;
        dst[n++] = (char)((a << 4) | b);
    }
    dst[n] = 0; return TRUE;
}
static BOOL read_one_argument(void) {
    char *p = GetCommandLineA(); DWORD n = 0;
    if (!p) return FALSE;
    if (*p == '"') { ++p; while (*p && *p != '"') ++p; if (*p == '"') ++p; }
    else while (*p && *p != ' ' && *p != '\t') ++p;
    while (*p == ' ' || *p == '\t') ++p;
    if (*p == '"') {
        ++p;
        while (*p && *p != '"') { if (n + 1 >= ARG_CAP) return FALSE; arg_buffer[n++] = *p++; }
    } else {
        while (*p && *p != '\r' && *p != '\n') { if (n + 1 >= ARG_CAP) return FALSE; arg_buffer[n++] = *p++; }
    }
    arg_buffer[n] = 0; return n > 0;
}
static int split_fields(char *text, char **fields, int max_fields) {
    int count = 0; char *p = text;
    if (!text || !fields || max_fields <= 0) return 0;
    fields[count++] = p;
    while (*p && count < max_fields) {
        if (*p == '|') { *p = 0; fields[count++] = p + 1; }
        ++p;
    }
    return count;
}
static BOOL locate_app(void) {
    DWORD n, attrs; int level;
    n = GetModuleFileNameA(NULL, module_path, PATH_CAP - 1);
    if (!n || n >= PATH_CAP - 1) return FALSE;
    module_path[n] = 0;
    if (!s_copy(app_root, PATH_CAP, module_path) || !strip_last_component(app_root)) return FALSE;
    for (level = 0; level < 6; ++level) {
        if (!s_copy(work_a, PATH_CAP, app_root) || !s_append(work_a, PATH_CAP, "\\desktop")) return FALSE;
        attrs = GetFileAttributesA(work_a);
        if (attrs != INVALID_FILE_ATTRIBUTES && (attrs & FILE_ATTRIBUTE_DIRECTORY) && !(attrs & FILE_ATTRIBUTE_REPARSE_POINT)) {
            if (!s_copy(storage_root, PATH_CAP, work_a)) return FALSE;
            if (!s_copy(uploads_root, PATH_CAP, app_root) || !s_append(uploads_root, PATH_CAP, "\\uploads")) return FALSE;
            if (!s_copy(downloads_root, PATH_CAP, app_root) || !s_append(downloads_root, PATH_CAP, "\\downloads")) return FALSE;
            return TRUE;
        }
        if (!strip_last_component(app_root)) break;
    }
    return FALSE;
}
static BOOL component_is_dot(const char *start, DWORD length) {
    return (length == 1 && start[0] == '.') || (length == 2 && start[0] == '.' && start[1] == '.');
}
static BOOL validate_relative(const char *rel) {
    DWORD i = 0, start = 0, len; unsigned char c;
    if (!rel) return FALSE;
    if (s_len(rel) >= 100) return FALSE;
    if (rel[0] == '\\' || rel[0] == '/' || (rel[0] && rel[1] == ':')) return FALSE;
    for (;;) {
        c = (unsigned char)rel[i];
        if (c == ':' || c == '*' || c == '?' || c == '"' || c == '<' || c == '>' || c == '|') return FALSE;
        if (c && c < 32) return FALSE;
        if (c == '/' || c == '\\' || c == 0) {
            len = i - start;
            if (len == 0 && c != 0) return FALSE;
            if (component_is_dot(rel + start, len)) return FALSE;
            if (c == 0) break;
            start = i + 1;
        }
        ++i;
    }
    return TRUE;
}
static BOOL join_storage(const char *rel, char *full, DWORD cap) {
    if (!validate_relative(rel)) return FALSE;
    if (!s_copy(full, cap, storage_root)) return FALSE;
    if (rel[0]) { if (!s_append(full, cap, "\\") || !s_append(full, cap, rel)) return FALSE; }
    return TRUE;
}
static BOOL path_has_reparse(const char *rel) {
    DWORD i = 0; char part[PATH_CAP]; DWORD attrs;
    if (!s_copy(part, PATH_CAP, storage_root)) return TRUE;
    if (!rel[0]) return FALSE;
    if (!s_append(part, PATH_CAP, "\\")) return TRUE;
    while (rel[i]) {
        if (!append_char(part, PATH_CAP, rel[i])) return TRUE;
        if (rel[i] == '\\' || rel[i] == '/') {
            part[s_len(part)-1] = 0;
            attrs = GetFileAttributesA(part);
            if (attrs != INVALID_FILE_ATTRIBUTES && (attrs & FILE_ATTRIBUTE_REPARSE_POINT)) return TRUE;
            if (!append_char(part, PATH_CAP, '\\')) return TRUE;
        }
        ++i;
    }
    attrs = GetFileAttributesA(part);
    if (attrs != INVALID_FILE_ATTRIBUTES && (attrs & FILE_ATTRIBUTE_REPARSE_POINT)) return TRUE;
    return FALSE;
}
static BOOL safe_name(const char *name) {
    DWORD i = 0, n; unsigned char c;
    if (!name) return FALSE; n = s_len(name);
    if (n == 0 || n > 80 || name[n-1] == ' ' || name[n-1] == '.') return FALSE;
    if ((name[0] == '.' && n <= 2) || s_equal_ci(name, ".") || s_equal_ci(name, "..")) return FALSE;
    while (name[i]) {
        c = (unsigned char)name[i++];
        if (c < 32 || c == '\\' || c == '/' || c == ':' || c == '*' || c == '?' || c == '"' || c == '<' || c == '>' || c == '|') return FALSE;
    }
    if (s_equal_ci(name, "CON") || s_equal_ci(name, "PRN") || s_equal_ci(name, "AUX") || s_equal_ci(name, "NUL")) return FALSE;
    if ((s_starts_ci(name, "COM") || s_starts_ci(name, "LPT")) && name[3] >= '1' && name[3] <= '9' && (name[4] == 0 || name[4] == '.')) return FALSE;
    return TRUE;
}
static BOOL make_child_rel(const char *dir, const char *name, char *out, DWORD cap) {
    if (!validate_relative(dir) || !safe_name(name)) return FALSE;
    if (!s_copy(out, cap, dir)) return FALSE;
    if (out[0] && !s_append(out, cap, "\\")) return FALSE;
    return s_append(out, cap, name);
}
static BOOL get_parent_rel(const char *rel, char *parent, DWORD cap) {
    if (!s_copy(parent, cap, rel)) return FALSE;
    if (!parent[0]) return TRUE;
    if (!strip_last_component(parent)) parent[0] = 0;
    return TRUE;
}
static BOOL parse_page(const char *text, DWORD *page) {
    DWORD v = 0, i = 0; if (!text || !text[0]) { *page = 0; return TRUE; }
    while (text[i]) { if (text[i] < '0' || text[i] > '9') return FALSE; v = v * 10 + (DWORD)(text[i]-'0'); if (v > 999) return FALSE; ++i; }
    *page = v; return TRUE;
}
static BOOL list_command(const char *hex_rel, const char *page_text) {
    WIN32_FIND_DATAA data; HANDLE find; DWORD page, skip, shown = 0, seen = 0; BOOL more = FALSE; DWORD attrs;
    if (!hex_decode(hex_rel, rel_a, PATH_CAP) || !validate_relative(rel_a) || path_has_reparse(rel_a)) return FALSE;
    if (!parse_page(page_text, &page)) return FALSE;
    if (!join_storage(rel_a, work_a, PATH_CAP)) return FALSE;
    attrs = GetFileAttributesA(work_a);
    if (attrs == INVALID_FILE_ATTRIBUTES || !(attrs & FILE_ATTRIBUTE_DIRECTORY)) return FALSE;
    if (!s_copy(work_b, PATH_CAP, work_a) || !s_append(work_b, PATH_CAP, "\\*")) return FALSE;

    find = FindFirstFileA(work_b, &data);
    skip = page * PAGE_SIZE;
    if (find != INVALID_HANDLE_VALUE) {
        do {
            if (s_equal_ci(data.cFileName, ".") || s_equal_ci(data.cFileName, "..")) continue;
            if (data.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) continue;
            if (s_len(data.cFileName) > 80 || !safe_name(data.cFileName)) continue;
            if (seen++ < skip) continue;
            if (shown >= PAGE_SIZE) { more = TRUE; break; }
            ++shown;
        } while (FindNextFileA(find, &data));
        FindClose(find);
    }

    out_reset();
    get_parent_rel(rel_a, rel_b, PATH_CAP);
    out_text("M|"); out_hex(rel_b); out_text("|"); out_uint(page); out_text("|"); out_char(more ? '1' : '0'); out_text("\n");

    find = FindFirstFileA(work_b, &data); seen = 0; shown = 0;
    if (find != INVALID_HANDLE_VALUE) {
        do {
            if (s_equal_ci(data.cFileName, ".") || s_equal_ci(data.cFileName, "..")) continue;
            if (data.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) continue;
            if (s_len(data.cFileName) > 80 || !safe_name(data.cFileName)) continue;
            if (seen++ < skip) continue;
            if (shown >= PAGE_SIZE) break;
            ++shown;
            out_char((data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ? 'D' : 'F');
            out_text("|"); out_hex(data.cFileName); out_text("|");
            if (data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) out_char('0');
            else if (data.nFileSizeHigh) out_text("4294967295");
            else out_uint(data.nFileSizeLow);
            out_text("\n");
        } while (FindNextFileA(find, &data));
        FindClose(find);
    }
    return TRUE;
}
static void require_existing_safe(const char *rel, char *full, BOOL allow_root) {
    DWORD attrs;
    if (!validate_relative(rel) || (!allow_root && !rel[0]) || path_has_reparse(rel) || !join_storage(rel, full, PATH_CAP)) error_exit(10, "Unsafe or invalid path");
    attrs = GetFileAttributesA(full);
    if (attrs == INVALID_FILE_ATTRIBUTES) error_exit(GetLastError(), "Path does not exist");
}
static void command_mkdir(const char *dir_hex, const char *name_hex) {
    if (!hex_decode(dir_hex, rel_a, PATH_CAP) || !hex_decode(name_hex, name_a, 260)) error_exit(11, "Invalid encoding");
    require_existing_safe(rel_a, work_a, TRUE);
    if (!(GetFileAttributesA(work_a) & FILE_ATTRIBUTE_DIRECTORY)) error_exit(12, "Destination is not a folder");
    if (!make_child_rel(rel_a, name_a, rel_b, PATH_CAP) || !join_storage(rel_b, work_b, PATH_CAP)) error_exit(13, "Invalid folder name");
    if (!CreateDirectoryA(work_b, NULL)) error_exit(GetLastError(), "Folder could not be created");
    ok_exit("Folder created");
}
static void command_rename(const char *src_hex, const char *name_hex) {
    if (!hex_decode(src_hex, rel_a, PATH_CAP) || !hex_decode(name_hex, name_a, 260)) error_exit(14, "Invalid encoding");
    require_existing_safe(rel_a, work_a, FALSE);
    get_parent_rel(rel_a, rel_b, PATH_CAP);
    if (!make_child_rel(rel_b, name_a, rel_b, PATH_CAP) || !join_storage(rel_b, work_b, PATH_CAP)) error_exit(15, "Invalid new name");
    if (!MoveFileA(work_a, work_b)) error_exit(GetLastError(), "Rename failed; the target may already exist");
    ok_exit("Item renamed");
}
static void command_copy_move(const char *src_hex, const char *dst_hex, BOOL move) {
    DWORD attrs;
    if (!hex_decode(src_hex, rel_a, PATH_CAP) || !hex_decode(dst_hex, rel_b, PATH_CAP)) error_exit(16, "Invalid encoding");
    require_existing_safe(rel_a, work_a, FALSE);
    attrs = GetFileAttributesA(work_a);
    require_existing_safe(rel_b, work_b, TRUE);
    if (!(GetFileAttributesA(work_b) & FILE_ATTRIBUTE_DIRECTORY)) error_exit(17, "Destination is not a folder");
    if (!make_child_rel(rel_b, base_name(rel_a), rel_b, PATH_CAP) || !join_storage(rel_b, work_b, PATH_CAP)) error_exit(18, "Invalid destination");
    if (move) {
        if (!MoveFileA(work_a, work_b)) error_exit(GetLastError(), "Move failed; the target may already exist");
        ok_exit("Item moved");
    }
    if (attrs & FILE_ATTRIBUTE_DIRECTORY) error_exit(19, "Folder copy is not supported; move it or create a new folder");
    if (!CopyFileA(work_a, work_b, TRUE)) error_exit(GetLastError(), "Copy failed; the target may already exist");
    ok_exit("File copied");
}
static void command_delete(const char *src_hex) {
    DWORD attrs;
    if (!hex_decode(src_hex, rel_a, PATH_CAP)) error_exit(20, "Invalid encoding");
    require_existing_safe(rel_a, work_a, FALSE);
    attrs = GetFileAttributesA(work_a);
    if (attrs & FILE_ATTRIBUTE_DIRECTORY) {
        if (!RemoveDirectoryA(work_a)) error_exit(GetLastError(), "Only empty folders can be deleted");
    } else {
        if (!DeleteFileA(work_a)) error_exit(GetLastError(), "File could not be deleted");
    }
    ok_exit("Item deleted");
}
static BOOL digits_only(const char *s) { DWORD i = 0; if (!s || !s[0] || s_len(s) > 12) return FALSE; while (s[i]) { if (s[i] < '0' || s[i] > '9') return FALSE; ++i; } return TRUE; }
static void command_export(const char *src_hex, const char *slot) {
    DWORD attrs;
    if (!hex_decode(src_hex, rel_a, PATH_CAP) || !digits_only(slot)) error_exit(21, "Invalid export request");
    require_existing_safe(rel_a, work_a, FALSE); attrs = GetFileAttributesA(work_a);
    if (attrs & FILE_ATTRIBUTE_DIRECTORY) error_exit(22, "Folders cannot be downloaded directly");
    if (!s_copy(work_b, PATH_CAP, downloads_root) || !s_append(work_b, PATH_CAP, "\\export-") || !s_append(work_b, PATH_CAP, slot) || !s_append(work_b, PATH_CAP, ".bin")) error_exit(23, "Export path too long");
    if (!CopyFileA(work_a, work_b, FALSE)) error_exit(GetLastError(), "Export failed");
    out_reset(); out_text("OK|downloads/export-"); out_text(slot); out_text(".bin"); flush_and_exit(0);
}
static void command_import(const char *dir_hex, const char *upload_hex, const char *name_hex) {
    DWORD attrs;
    if (!hex_decode(dir_hex, rel_a, PATH_CAP) || !hex_decode(upload_hex, rel_b, PATH_CAP) || !hex_decode(name_hex, name_a, 260)) error_exit(24, "Invalid upload encoding");
    if (!safe_name(rel_b) || !safe_name(name_a)) error_exit(25, "Unsafe upload filename");
    require_existing_safe(rel_a, work_a, TRUE); attrs = GetFileAttributesA(work_a);
    if (!(attrs & FILE_ATTRIBUTE_DIRECTORY)) error_exit(26, "Upload destination is not a folder");
    if (!s_copy(work_a, PATH_CAP, uploads_root) || !s_append(work_a, PATH_CAP, "\\") || !s_append(work_a, PATH_CAP, rel_b)) error_exit(27, "Upload path too long");
    attrs = GetFileAttributesA(work_a); if (attrs == INVALID_FILE_ATTRIBUTES || (attrs & FILE_ATTRIBUTE_DIRECTORY) || (attrs & FILE_ATTRIBUTE_REPARSE_POINT)) error_exit(28, "Uploaded file was not found");
    if (!make_child_rel(rel_a, name_a, rel_b, PATH_CAP) || !join_storage(rel_b, work_b, PATH_CAP)) error_exit(29, "Invalid destination name");
    if (!MoveFileA(work_a, work_b)) error_exit(GetLastError(), "Import failed; the target may already exist");
    ok_exit("File uploaded");
}

void start(void) {
    char *fields[6]; int count;
    if (!locate_app()) error_exit(2, "Application desktop root was not found");
    if (!read_one_argument()) error_exit(3, "Missing command");
    count = split_fields(arg_buffer, fields, 6);
    if (count >= 3 && s_equal_ci(fields[0], "list")) {
        if (!list_command(fields[1], fields[2])) error_exit(4, "Directory could not be listed");
        flush_and_exit(0);
    }
    if (count >= 3 && s_equal_ci(fields[0], "mkdir")) command_mkdir(fields[1], fields[2]);
    if (count >= 3 && s_equal_ci(fields[0], "rename")) command_rename(fields[1], fields[2]);
    if (count >= 3 && s_equal_ci(fields[0], "copy")) command_copy_move(fields[1], fields[2], FALSE);
    if (count >= 3 && s_equal_ci(fields[0], "move")) command_copy_move(fields[1], fields[2], TRUE);
    if (count >= 2 && s_equal_ci(fields[0], "delete")) command_delete(fields[1]);
    if (count >= 3 && s_equal_ci(fields[0], "export")) command_export(fields[1], fields[2]);
    if (count >= 4 && s_equal_ci(fields[0], "import")) command_import(fields[1], fields[2], fields[3]);
    error_exit(5, "Unknown or incomplete command");
}
