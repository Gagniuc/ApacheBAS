APACHEBAS DESKTOP v1.1.1
========================

1. Copiază folderul "apachebas-desktop" în:
   C:\xampp\htdocs\

2. Deschide:
   http://localhost/apachebas-desktop/desktop.bas

Directorul vizibil ca desktop este:
   C:\xampp\htdocs\apachebas-desktop\desktop\

FUNCȚIONALITĂȚI
- desktop clasic cu iconițe, meniu Start, taskbar și ferestre;
- selectare multiplă cu Ctrl+click, Shift+click, Ctrl+A sau dreptunghi de selecție;
- copiere, mutare și ștergere pentru mai multe elemente selectate;
- deschiderea directoarelor într-o fereastră Explorer;
- aplicațiile .bas și paginile HTML se deschid într-o fereastră a desktopului;
- buton Desktop pentru revenire imediată dintr-o aplicație deschisă;
- deschidere opțională într-o filă/fereastră separată;
- câmp Address reparat și complet vizibil;
- deschidere imagini, texte, PDF, audio și video în browser;
- redenumire, creare directoare, ștergere și download;
- upload PNG/JPG/GIF/WebP de maximum 1 MiB.

SELECTARE MULTIPLĂ
- Ctrl+click: adaugă sau elimină un element din selecție;
- Shift+click: selectează intervalul dintre două iconițe;
- Ctrl+A: selectează toate iconițele din zona activă;
- tragere pe fundal: desenează un dreptunghi de selecție;
- Escape: anulează selecția;
- Delete: șterge elementele selectate după confirmare.

LIMITĂ DE SECURITATE
Toate operațiile native sunt limitate la directorul desktop. Nu există shell și nu sunt lansate EXE, CMD, PowerShell sau alte comenzi native din browser.

Accesul este local implicit. Pentru LAN, rulează SETUP_REMOTE_ACCESS.cmd.

REPARATIE v1.1.1
Patchul include helperul complet si toate iconitele. ApacheBAS cauta DesktopHelper.exe in subdirectorul tools al aplicatiei, deci tools\DesktopHelper.exe trebuie pastrat.
