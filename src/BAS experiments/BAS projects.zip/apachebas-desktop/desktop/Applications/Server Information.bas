<?bas
PRINT "@@CONTENT-TYPE text/html; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Server Information</title><style>
body{margin:0;background:#008080;font-family:Tahoma,Arial,sans-serif;font-size:13px;padding:50px}
.win{max-width:620px;margin:auto;background:#c0c0c0;border:2px outset #fff;box-shadow:4px 4px #0007}
.title{background:linear-gradient(90deg,#000080,#1084d0);color:#fff;padding:5px 7px;font-weight:bold}
.body{padding:18px}.row{display:grid;grid-template-columns:170px 1fr;border-bottom:1px solid #aaa;padding:7px 0}.v{background:#fff;border:2px inset #fff;padding:3px 6px;font-family:Consolas,monospace}
</style></head><body><div class="win"><div class="title">Server Information</div><div class="body">
<div class="row"><b>Remote client</b><span class="v"><?= HTML$(SERVER_REMOTE_ADDR$) ?></span></div>
<div class="row"><b>Request method</b><span class="v"><?= HTML$(SERVER_REQUEST_METHOD$) ?></span></div>
<div class="row"><b>Server software</b><span class="v"><?= HTML$(SERVER_NAME$ + ":" + SERVER_PORT$) ?></span></div>
<div class="row"><b>Date</b><span class="v"><?= HTML$(DATE$) ?></span></div>
<div class="row"><b>Time</b><span class="v"><?= HTML$(TIME$) ?></span></div>
<p>This BASIC application was launched from ApacheBAS Desktop.</p></div></div></body></html>
