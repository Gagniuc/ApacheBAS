<?bas
PRINT "@@CONTENT-TYPE text/html; charset=utf-8"
?>
<!doctype html><meta charset="utf-8"><title>Hello Desktop</title><style>body{margin:0;background:#008080;font:14px Tahoma,Arial;padding:80px}.w{max-width:440px;margin:auto;background:#c0c0c0;border:2px outset white;box-shadow:4px 4px #0008}.t{background:#000080;color:white;padding:5px;font-weight:bold}.b{padding:25px;text-align:center}.ok{background:#c0c0c0;border:2px outset white;padding:5px 25px}</style><div class="w"><div class="t">ApacheBAS Application</div><div class="b"><h2>Hello from the server desktop!</h2><p>This page is an executable <code>.bas</code> file stored inside the Desktop directory.</p><button class="ok" onclick="window.close()">OK</button></div></div>
