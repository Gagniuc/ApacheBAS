@echo off
cd /d "%~dp0"
> .htaccess echo Options -Indexes
>>.htaccess echo Require local
>>.htaccess echo.
>>.htaccess echo ^<FilesMatch "^^\."^>
>>.htaccess echo     Require all denied
>>.htaccess echo ^</FilesMatch^>
echo Local-only access restored.
pause
