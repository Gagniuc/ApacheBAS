PRINT "@@CONTENT-TYPE application/json; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
PATH_HEX$ = UCASE$(TRIM$(GET_PATH$))
SLOT$ = TRIM$(GET_SLOT$)
ERROR$ = ""
IF PATH_HEX$ = "" THEN ERROR$ = "Invalid file path."
IF LEN(PATH_HEX$) > 200 THEN ERROR$ = "Invalid file path."
IF LEN(PATH_HEX$) MOD 2 <> 0 THEN ERROR$ = "Invalid file path."
I = 1
WHILE I <= LEN(PATH_HEX$)
  C = ASC(MID$(PATH_HEX$, I, 1))
  OKC = 0
  IF C >= 48 AND C <= 57 THEN OKC = 1
  IF C >= 65 AND C <= 70 THEN OKC = 1
  IF C >= 97 AND C <= 102 THEN OKC = 1
  IF OKC = 0 THEN ERROR$ = "Invalid file path."
  I = I + 1
WEND
IF LEN(SLOT$) < 1 THEN ERROR$ = "Invalid download slot."
IF LEN(SLOT$) > 12 THEN ERROR$ = "Invalid download slot."
I = 1
WHILE I <= LEN(SLOT$)
  C = ASC(MID$(SLOT$, I, 1))
  IF C < 48 OR C > 57 THEN ERROR$ = "Invalid download slot."
  I = I + 1
WEND
IF ERROR$ <> "" THEN GOTO FAIL
CMD$ = "export|" & PATH_HEX$ & "|" & SLOT$
EXEC "DesktopHelper.exe", CMD$
RESULT$ = EXEC_OUTPUT$
IF EXEC_OK = 0 THEN ERROR$ = EXEC_ERROR$
IF EXEC_OK = 0 THEN GOTO FAIL
IF LEFT$(RESULT$, 3) = "OK|" THEN GOTO SUCCESS
ERROR$ = RESULT$
GOTO FAIL
SUCCESS:
PRINT "{""ok"":true,""url"":""" & JSON$(MID$(RESULT$, 4)) & """}"
END
FAIL:
IF ERROR$ = "" THEN ERROR$ = "Download preparation failed."
PRINT "@@STATUS 400"
PRINT "{""ok"":false,""error"":""" & JSON$(ERROR$) & """}"
