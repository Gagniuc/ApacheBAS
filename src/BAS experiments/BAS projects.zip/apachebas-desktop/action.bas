PRINT "@@CONTENT-TYPE application/json; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
OP$ = LCASE$(TRIM$(POST_OP$))
SRC$ = UCASE$(TRIM$(POST_SRC$))
DST$ = UCASE$(TRIM$(POST_DST$))
NAME$ = TRIM$(POST_NAME$)
ERROR$ = ""

OP_OK = 0
IF OP$ = "copy" THEN OP_OK = 1
IF OP$ = "move" THEN OP_OK = 1
IF OP$ = "rename" THEN OP_OK = 1
IF OP$ = "mkdir" THEN OP_OK = 1
IF OP$ = "delete" THEN OP_OK = 1
IF OP_OK = 0 THEN ERROR$ = "Unsupported operation."
IF ERROR$ <> "" THEN GOTO FAIL

NEED_SRC = 0
IF OP$ = "copy" THEN NEED_SRC = 1
IF OP$ = "move" THEN NEED_SRC = 1
IF OP$ = "rename" THEN NEED_SRC = 1
IF OP$ = "delete" THEN NEED_SRC = 1
IF NEED_SRC = 0 THEN GOTO SRC_DONE
CHECK_HEX$ = SRC$
GOSUB VALIDATE_HEX
IF HEX_OK = 0 THEN ERROR$ = "Invalid source path."
IF SRC$ = "" THEN ERROR$ = "Invalid source path."
SRC_DONE:

NEED_DST = 0
IF OP$ = "copy" THEN NEED_DST = 1
IF OP$ = "move" THEN NEED_DST = 1
IF OP$ = "mkdir" THEN NEED_DST = 1
IF NEED_DST = 0 THEN GOTO DST_DONE
CHECK_HEX$ = DST$
GOSUB VALIDATE_HEX
IF HEX_OK = 0 THEN ERROR$ = "Invalid destination path."
DST_DONE:
IF ERROR$ <> "" THEN GOTO FAIL

NAME_HEX$ = ""
NEED_NAME = 0
IF OP$ = "rename" THEN NEED_NAME = 1
IF OP$ = "mkdir" THEN NEED_NAME = 1
IF NEED_NAME = 0 THEN GOTO NAME_DONE
GOSUB ENCODE_NAME
NAME_DONE:
IF ERROR$ <> "" THEN GOTO FAIL

CMD$ = ""
IF OP$ = "copy" THEN CMD$ = "copy|" & SRC$ & "|" & DST$
IF OP$ = "move" THEN CMD$ = "move|" & SRC$ & "|" & DST$
IF OP$ = "rename" THEN CMD$ = "rename|" & SRC$ & "|" & NAME_HEX$
IF OP$ = "mkdir" THEN CMD$ = "mkdir|" & DST$ & "|" & NAME_HEX$
IF OP$ = "delete" THEN CMD$ = "delete|" & SRC$
EXEC "DesktopHelper.exe", CMD$
RESULT$ = EXEC_OUTPUT$
IF EXEC_OK = 0 THEN ERROR$ = EXEC_ERROR$
IF EXEC_OK = 0 THEN GOTO FAIL
IF LEFT$(RESULT$, 3) = "OK|" THEN GOTO SUCCESS
ERROR$ = RESULT$
IF LEFT$(ERROR$, 4) = "ERR|" THEN ERROR$ = MID$(ERROR$, 5)
GOTO FAIL

VALIDATE_HEX:
HEX_OK = 1
IF LEN(CHECK_HEX$) > 200 THEN HEX_OK = 0
I = 1
WHILE I <= LEN(CHECK_HEX$)
  C = ASC(MID$(CHECK_HEX$, I, 1))
  OKC = 0
  IF C >= 48 AND C <= 57 THEN OKC = 1
  IF C >= 65 AND C <= 70 THEN OKC = 1
  IF C >= 97 AND C <= 102 THEN OKC = 1
  IF OKC = 0 THEN HEX_OK = 0
  I = I + 1
WEND
IF LEN(CHECK_HEX$) MOD 2 <> 0 THEN HEX_OK = 0
RETURN

ENCODE_NAME:
IF LEN(NAME$) < 1 THEN GOTO NAME_BAD_LENGTH
IF LEN(NAME$) > 80 THEN GOTO NAME_BAD_LENGTH
IF RIGHT$(NAME$, 1) = "." THEN GOTO NAME_BAD_END
IF RIGHT$(NAME$, 1) = " " THEN GOTO NAME_BAD_END
I = 1
WHILE I <= LEN(NAME$)
  CH$ = MID$(NAME$, I, 1)
  C = ASC(CH$)
  BAD = 0
  IF C < 32 THEN BAD = 1
  IF CH$ = "\" THEN BAD = 1
  IF CH$ = "/" THEN BAD = 1
  IF CH$ = ":" THEN BAD = 1
  IF CH$ = "*" THEN BAD = 1
  IF CH$ = "?" THEN BAD = 1
  IF CH$ = CHR$(34) THEN BAD = 1
  IF CH$ = "<" THEN BAD = 1
  IF CH$ = ">" THEN BAD = 1
  IF CH$ = "|" THEN BAD = 1
  IF BAD = 1 THEN GOTO NAME_BAD_CHAR
  NAME_HEX$ = NAME_HEX$ & RIGHT$("0" & HEX$(C), 2)
  I = I + 1
WEND
RETURN
NAME_BAD_LENGTH:
ERROR$ = "Name must contain 1 to 80 characters."
RETURN
NAME_BAD_END:
ERROR$ = "A name cannot end with a dot or space."
RETURN
NAME_BAD_CHAR:
ERROR$ = "The name contains a forbidden Windows filename character."
RETURN

SUCCESS:
PRINT "{""ok"":true,""message"":""" & JSON$(MID$(RESULT$, 4)) & """}"
END

FAIL:
IF ERROR$ = "" THEN ERROR$ = "Operation failed."
PRINT "@@STATUS 400"
PRINT "{""ok"":false,""error"":""" & JSON$(ERROR$) & """}"
