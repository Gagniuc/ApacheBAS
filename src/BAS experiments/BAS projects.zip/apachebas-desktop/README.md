# ApacheBAS Desktop v1.1.1

A classic Windows-inspired browser desktop for ApacheBAS-ASM v0.1.33.3.

## Features

- desktop icons, Start menu, taskbar, clock and draggable windows;
- multi-selection with Ctrl-click, Shift-click, Ctrl+A and rubber-band selection;
- batch copy, move and permanent delete for selected items;
- Explorer-style folder browsing;
- corrected, fully visible Address field;
- `.bas` applications and HTML pages open inside a desktop viewer window;
- Desktop button returns immediately from an embedded application;
- optional Open in new window button;
- contextual menus and classic File/Edit/View/Help menus;
- rename, new folder, controlled download and validated image upload;
- browser viewers for text, images, PDF, audio and video;
- local-only Apache access by default;
- optional HTTP Basic authentication for a trusted LAN.

## Multiple selection

- Ctrl-click toggles individual icons.
- Shift-click selects a continuous icon range.
- Ctrl+A selects all icons in the active desktop or Explorer area.
- Dragging over empty space creates a Windows-style selection rectangle.
- Escape clears the selection.
- Delete asks for confirmation and processes the selected items.

## Desktop root

All manageable files are confined to:

`apachebas-desktop/desktop/`

The native helper rejects absolute paths, drive prefixes, traversal, unsafe names and reparse points. It invokes no shell and does not launch native executables.

## Installation

Copy `apachebas-desktop` to `C:\xampp\htdocs\` and open:

`http://localhost/apachebas-desktop/desktop.bas`

For LAN access, run `SETUP_REMOTE_ACCESS.cmd` and use HTTPS before exposure outside a trusted network.

## v1.1.1 repair

The patch includes the complete runtime helper and icon set. ApacheBAS resolves `EXEC "DesktopHelper.exe"` from the application's `tools` directory, so `tools/DesktopHelper.exe` must remain present beside the application files.
