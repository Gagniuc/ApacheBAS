<?bas
IF GET_API$ = "start" THEN START GET_FILE$
IF GET_API$ = "start" THEN PRINT "@@CONTENT-TYPE text/plain; charset=utf-8"
IF GET_API$ = "start" THEN PRINT "@@HEADER Cache-Control: no-store"
IF GET_API$ = "start" THEN PRINT "START_OK="; START_OK
IF GET_API$ = "start" THEN PRINT "START_ERROR="; START_ERROR$
IF GET_API$ = "start" THEN END
PRINT "@@CONTENT-TYPE text/html; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ApacheBAS Programs Explorer</title>
<style>
:root{color-scheme:dark;--bg:#06110c;--panel:#0b1d14;--panel2:#10281d;--line:#1e6a43;--accent:#6fffab;--text:#f3fff8;--muted:#a7d7bf;--bad:#ff8f8f;--sel:#153d29}
*{box-sizing:border-box}html,body{margin:0;min-height:100%;background:#020604;color:var(--text);font:14px Consolas,"Courier New",monospace}button,input{font:inherit}.app{min-height:100vh;background:var(--bg)}.top{height:52px;display:flex;align-items:center;gap:10px;padding:0 16px;background:#020503;border-bottom:1px solid var(--line)}.title{font-weight:700;letter-spacing:.08em}.badge{border:1px solid var(--line);border-radius:999px;color:var(--accent);padding:4px 9px;font-size:12px}.spacer{flex:1}.toolbar{display:flex;gap:8px;padding:12px 16px;background:var(--panel);border-bottom:1px solid var(--line)}button{height:34px;border:1px solid var(--line);background:#0a2015;color:var(--text);padding:0 13px;cursor:pointer}button:hover{background:#173d2a}.search{flex:1;min-width:160px;height:34px;border:1px solid var(--line);background:#030b07;color:var(--text);padding:0 10px;outline:none}.summary{display:flex;align-items:center;gap:18px;padding:10px 16px;color:var(--muted);border-bottom:1px solid #173c2a}.summary b{color:var(--accent)}.table{width:100%;border-collapse:collapse}.table th,.table td{text-align:left;padding:10px 14px;border-bottom:1px solid #10281d}.table th{position:sticky;top:0;background:#081810;color:var(--muted);font-size:12px}.row{cursor:default;user-select:none}.row:hover{background:#0e2419}.row.selected{background:var(--sel);outline:1px solid #2e7550;outline-offset:-1px}.path{color:var(--muted);font-size:12px}.icon{display:inline-block;width:24px}.empty,.error{padding:30px;color:var(--muted)}.error{color:var(--bad)}.status{position:sticky;bottom:0;min-height:30px;display:flex;align-items:center;padding:0 14px;background:#020503;border-top:1px solid var(--line);color:var(--muted)}.status b{color:var(--accent)}
@media(max-width:720px){.table th:nth-child(3),.table td:nth-child(3){display:none}.toolbar{flex-wrap:wrap}.search{flex-basis:100%}}
</style>
</head>
<body>
<div class="app">
 <div class="top"><div class="title">APACHEBAS PROGRAMS EXPLORER</div><div class="badge">DOUBLE-CLICK TO START</div><div class="spacer"></div></div>
 <div class="toolbar"><button id="scan">Scan again</button><input id="search" class="search" placeholder="Filter by program name or path" autocomplete="off"></div>
 <div class="summary"><span>Programs: <b id="programCount">0</b></span><span>Directories scanned: <b id="dirCount">0</b></span></div>
 <table class="table"><thead><tr><th>Program</th><th>Relative path</th><th>Action</th></tr></thead><tbody id="programs"></tbody></table>
 <div id="message" class="empty">Scanning the server tree...</div>
 <div id="status" class="status"><b>READY</b>&nbsp; Waiting.</div>
</div>
<script>
'use strict';
(() => {
 const pageUrl=new URL(location.href); pageUrl.search=''; pageUrl.hash='';
 const rootUrl=new URL('./',pageUrl);
 const programsEl=document.getElementById('programs');
 const messageEl=document.getElementById('message');
 const statusEl=document.getElementById('status');
 const searchEl=document.getElementById('search');
 const programCountEl=document.getElementById('programCount');
 const dirCountEl=document.getElementById('dirCount');
 let programs=[],selectedRow=null,scanToken=0,scannedDirectories=0;
 const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const relative=u=>decodeURIComponent(u.pathname.slice(rootUrl.pathname.length));
 const inside=u=>u.origin===rootUrl.origin&&u.pathname.startsWith(rootUrl.pathname);
 function setStatus(text,bad=false){statusEl.innerHTML=`<b style="${bad?'color:var(--bad)':''}">${bad?'ERROR':'READY'}</b>&nbsp; ${esc(text)}`}
 function directChildren(html,url){
  const doc=new DOMParser().parseFromString(html,'text/html'),out=[],seen=new Set();
  for(const a of doc.querySelectorAll('a[href]')){
   const raw=a.getAttribute('href')||'';
   if(!raw||raw==='../'||raw==='./'||raw.startsWith('?')||raw.startsWith('#'))continue;
   let target; try{target=new URL(raw,url)}catch{continue}
   target.search='';target.hash='';
   if(!inside(target)||target.href===url.href||seen.has(target.href))continue;
   const isDir=target.pathname.endsWith('/');
   const parent=isDir?new URL('../',target).href:new URL('./',target).href;
   if(parent!==url.href)continue;
   seen.add(target.href);
   const name=decodeURIComponent(target.pathname.split('/').filter(Boolean).pop()||'');
   out.push({url:target,name,isDir});
  }
  if(!out.length&&!/Index of|Directory listing/i.test(doc.title+' '+doc.body.textContent.slice(0,400)))throw new Error('Apache directory listing is disabled. Enable Options +Indexes for this directory tree.');
  return out;
 }
 async function scanDirectory(url,token,visited){
  if(token!==scanToken||visited.has(url.href))return;
  visited.add(url.href);scannedDirectories++;dirCountEl.textContent=scannedDirectories;
  setStatus(`Scanning /${relative(url)} ...`);
  let response;
  try{response=await fetch(url.href,{cache:'no-store',credentials:'same-origin'})}catch(e){return}
  if(!response.ok)return;
  let children;try{children=directChildren(await response.text(),url)}catch(e){if(url.href===rootUrl.href)throw e;return}
  for(const item of children){
   if(token!==scanToken)return;
   if(item.isDir){await scanDirectory(item.url,token,visited);continue}
   if(item.name.toLowerCase().endsWith('.exe')){
    programs.push({name:item.name,path:relative(item.url),url:item.url});
    programs.sort((a,b)=>a.name.localeCompare(b.name,undefined,{numeric:true,sensitivity:'base'})||a.path.localeCompare(b.path));
    render();
   }
  }
 }
 function render(){
  const q=searchEl.value.trim().toLowerCase();
  const shown=programs.filter(p=>!q||p.name.toLowerCase().includes(q)||p.path.toLowerCase().includes(q));
  programsEl.innerHTML='';programCountEl.textContent=programs.length;
  messageEl.style.display=shown.length?'none':'block';
  messageEl.textContent=programs.length?'No program matches the filter.':'No .exe program was found.';
  for(const p of shown){
   const row=document.createElement('tr');row.className='row';
   row.innerHTML=`<td><span class="icon">⚙</span><strong>${esc(p.name)}</strong></td><td class="path">${esc(p.path)}</td><td>Double-click to start</td>`;
   row.onclick=()=>{if(selectedRow)selectedRow.classList.remove('selected');selectedRow=row;row.classList.add('selected');setStatus(`Selected: ${p.path}`)};
   row.ondblclick=()=>startProgram(p);
   programsEl.appendChild(row);
  }
 }
 async function startProgram(program){
  try{
   setStatus(`Starting ${program.path} ...`);
   const api=new URL(pageUrl);api.searchParams.set('api','start');api.searchParams.set('file',program.path);
   const response=await fetch(api.href,{cache:'no-store',credentials:'same-origin'});
   const text=await response.text();
   if(!response.ok||!text.includes('START_OK=1'))throw new Error(text.trim()||`HTTP ${response.status}`);
   setStatus(`Started on the server: ${program.path}`);
  }catch(e){setStatus(e.message,true);alert('The program could not be started.\n\n'+e.message)}
 }
 async function scan(){
  const token=++scanToken;programs=[];scannedDirectories=0;selectedRow=null;render();messageEl.style.display='block';messageEl.textContent='Scanning the server tree...';
  try{await scanDirectory(rootUrl,token,new Set());if(token===scanToken)setStatus(`Scan complete: ${programs.length} program(s) found.`)}catch(e){messageEl.style.display='block';messageEl.className='error';messageEl.textContent=e.message;setStatus(e.message,true)}
 }
 document.getElementById('scan').onclick=scan;searchEl.oninput=render;scan();
})();
</script>
</body>
</html>
