<?bas
IF GET_API$ = "start" THEN START GET_FILE$
IF GET_API$ = "start" THEN PRINT "@@CONTENT-TYPE text/plain; charset=utf-8"
IF GET_API$ = "start" THEN PRINT "@@HEADER Cache-Control: no-store"
IF GET_API$ = "start" THEN PRINT "START_OK="; START_OK
IF GET_API$ = "start" THEN PRINT "START_ERROR="; START_ERROR$
IF GET_API$ = "start" THEN END
PRINT "@@CONTENT-TYPE text/html; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ApacheBAS Server Explorer</title>
<style>
:root{color-scheme:dark;--bg:#06110c;--p:#0b1d14;--p2:#10281d;--line:#1e6a43;--a:#6fffab;--t:#f3fff8;--m:#a7d7bf;--bad:#ff8f8f;--sel:#153d29}
*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#000;color:var(--t);font:14px Consolas,"Courier New",monospace}button,input{font:inherit}.app{height:100%;display:grid;grid-template-rows:42px 44px 1fr 28px;background:var(--bg);border:1px solid #173c2a}.titlebar,.toolbar,.viewerbar{display:flex;align-items:center;gap:8px}.titlebar{padding:0 10px;background:#020503;border-bottom:1px solid var(--line)}.title{font-weight:700;letter-spacing:.08em}.badge{color:var(--a);border:1px solid var(--line);border-radius:999px;padding:3px 8px;font-size:12px}.spacer{flex:1}.toolbar{padding:7px 10px;background:var(--p);border-bottom:1px solid var(--line)}button{border:1px solid var(--line);background:#0a2015;color:var(--t);height:29px;padding:0 10px;cursor:pointer}button:hover{background:#173d2a}button:disabled{opacity:.35;cursor:default}.close:hover{background:#702020}.address{flex:1;height:29px;border:1px solid var(--line);background:#030b07;color:var(--m);padding:5px 8px;outline:none}.workspace{min-height:0;display:grid;grid-template-columns:270px 1fr}.treepane{border-right:1px solid var(--line);display:grid;grid-template-rows:34px 1fr;background:#07160f}.head{padding:9px;color:var(--m);font-size:12px;letter-spacing:.08em;border-bottom:1px solid #173c2a}.tree,.files{overflow:auto}.tree{padding:8px}.tree-line{height:29px;display:flex;align-items:center;gap:7px;padding:0 7px;cursor:pointer;border:1px solid transparent;white-space:nowrap}.tree-line:hover,.tree-line.active{background:var(--sel);border-color:#275c40}.children{margin-left:16px;border-left:1px dotted #28583f;padding-left:4px}.filepane{min-width:0;display:grid;grid-template-rows:34px 1fr}.row{height:34px;display:grid;grid-template-columns:minmax(260px,1fr) 130px 150px;align-items:center;padding:0 10px;border-bottom:1px solid #10281d}.row.header{background:#081810;color:var(--m);font-size:12px}.row.item{cursor:default;user-select:none}.row.item:hover{background:#0e2419}.row.item.selected{background:var(--sel);outline:1px solid #2e7550;outline-offset:-1px}.name{display:flex;align-items:center;gap:9px;min-width:0}.filename{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.meta{color:var(--m);font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.status{display:flex;align-items:center;padding:0 9px;background:#020503;border-top:1px solid var(--line);color:var(--m);font-size:12px}.status b{color:var(--a)}.empty,.error{padding:24px;color:var(--m);white-space:pre-wrap}.error{color:var(--bad)}.overlay{position:fixed;inset:0;z-index:20;background:rgba(0,0,0,.74);display:grid;place-items:center;padding:26px}.overlay[hidden]{display:none}.viewer{width:min(1120px,96vw);height:min(800px,92vh);display:grid;grid-template-rows:40px 1fr;background:#041009;border:1px solid var(--line);box-shadow:0 25px 90px #000}.viewerbar{padding:0 9px;background:var(--p);border-bottom:1px solid var(--line)}.viewertitle{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.viewerbody{min-height:0;overflow:auto;padding:14px}.viewerbody pre{margin:0;white-space:pre-wrap;overflow-wrap:anywhere;color:#dfffea}.viewerbody iframe{width:100%;height:100%;border:0;background:#fff}.viewerbody img{display:block;max-width:100%;max-height:100%;margin:auto}.viewerbody video,.viewerbody audio{display:block;max-width:100%;margin:auto}.notice{max-width:760px;margin:30px auto;padding:20px;border:1px solid var(--line);background:var(--p);line-height:1.6}.notice a{color:var(--a)}
@media(max-width:760px){.workspace{grid-template-columns:1fr}.treepane{display:none}.row{grid-template-columns:minmax(180px,1fr) 90px}.row>*:last-child{display:none}.badge{display:none}}
</style>
</head>
<body>
<div class="app" id="app">
 <div class="titlebar"><div class="title">APACHEBAS SERVER EXPLORER</div><div class="badge">READ ONLY</div><div class="spacer"></div><button class="close" id="closeApp">X</button></div>
 <div class="toolbar"><button id="back">&larr;</button><button id="up">&uarr;</button><button id="refresh">Refresh</button><input id="address" class="address" spellcheck="false"><button id="go">Go</button></div>
 <main class="workspace">
  <aside class="treepane"><div class="head">DIRECTORY TREE</div><div id="tree" class="tree"></div></aside>
  <section class="filepane"><div class="row header"><div>Name</div><div>Type / size</div><div>Modified</div></div><div id="files" class="files" tabindex="0"></div></section>
 </main>
 <div id="status" class="status"><b>READY</b>&nbsp; Double-click a folder or file.</div>
</div>
<div id="overlay" class="overlay" hidden><div class="viewer"><div class="viewerbar"><strong id="viewerTitle" class="viewertitle">Viewer</strong><div class="spacer"></div><button class="close" id="closeViewer">X</button></div><div id="viewerBody" class="viewerbody"></div></div></div>
<script>
'use strict';
(() => {
 const explorerUrl=new URL(location.href); explorerUrl.search=''; explorerUrl.hash='';
 const rootUrl=new URL('./',explorerUrl); let currentUrl=new URL(rootUrl),historyStack=[],selected=null;
 const cache=new Map(),expanded=new Set(['']);
 const $=id=>document.getElementById(id),filesEl=$('files'),treeEl=$('tree'),statusEl=$('status'),addressEl=$('address'),overlay=$('overlay'),viewerBody=$('viewerBody'),viewerTitle=$('viewerTitle');
 const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function status(text,bad=false){statusEl.innerHTML=`<b style="${bad?'color:var(--bad)':''}">${bad?'ERROR':'READY'}</b>&nbsp; ${esc(text)}`}
 function within(u){return u.origin===rootUrl.origin&&u.pathname.startsWith(rootUrl.pathname)}
 function rel(u){return decodeURIComponent(u.pathname.slice(rootUrl.pathname.length))}
 function dirUrl(input){const u=new URL(input,currentUrl);u.search='';u.hash='';if(!u.pathname.endsWith('/'))u.pathname+='/';if(!within(u))throw new Error('Path is outside this explorer root.');return u}
 function icon(i){if(i.isDir)return '📁';const e=i.ext;if(e==='bas')return '▶';if(e==='exe')return '⚙';if(['txt','log','md','csv','json','xml','ini','cfg','conf','css','js','vbs','ps1','bat','cmd','inc','asm','c','cpp','h','py','php'].includes(e))return '📄';if(['png','jpg','jpeg','gif','webp','bmp','svg','ico'].includes(e))return '🖼';if(e==='pdf')return '📕';if(['html','htm'].includes(e))return '🌐';if(['mp3','wav','ogg','flac'].includes(e))return '🎵';if(['mp4','webm','avi','mov'].includes(e))return '🎬';if(['zip','7z','rar','gz'].includes(e))return '📦';return '📎'}
 async function readDir(url,force=false){const key=url.href;if(!force&&cache.has(key))return cache.get(key);const r=await fetch(url.href,{cache:'no-store',credentials:'same-origin'});if(!r.ok)throw new Error(`HTTP ${r.status} reading ${url.pathname}`);const html=await r.text(),doc=new DOMParser().parseFromString(html,'text/html'),out=[],seen=new Set();for(const a of doc.querySelectorAll('a[href]')){const raw=a.getAttribute('href')||'';if(!raw||raw.startsWith('?')||raw.startsWith('#')||raw==='../'||raw==='./')continue;let target;try{target=new URL(raw,url)}catch{continue}target.search='';target.hash='';if(!within(target)||target.href===url.href||seen.has(target.href))continue;const isDir=target.pathname.endsWith('/');const parent=isDir?new URL('../',target).href:new URL('./',target).href;if(parent!==url.href)continue;seen.add(target.href);const name=decodeURIComponent(target.pathname.split('/').filter(Boolean).pop()||'/'),row=a.closest('tr'),cells=row?[...row.querySelectorAll('td')].map(x=>x.textContent.trim()):[];let size='',modified='';if(cells.length){modified=cells.find(x=>/\d{4}[-/]\d{2}[-/]\d{2}|\d{2}[-/]\w{3}[-/]\d{4}/.test(x))||'';size=cells.find(x=>/^\d+(?:\.\d+)?\s*(?:[KMGTP]?B)?$/i.test(x))||''}out.push({name,url:target,isDir,ext:isDir?'':(name.includes('.')?name.split('.').pop().toLowerCase():''),size,modified})}if(!out.length&&!/Index of|Directory listing/i.test(doc.title+' '+doc.body.textContent.slice(0,300)))throw new Error('Apache directory listing is disabled. Copy the supplied .htaccess into the same directory as server_explorer.bas.');out.sort((a,b)=>Number(b.isDir)-Number(a.isDir)||a.name.localeCompare(b.name,undefined,{numeric:true,sensitivity:'base'}));cache.set(key,out);return out}
 async function navigate(input,push=true,force=false){try{const next=dirUrl(input);status(`Reading /${rel(next)} ...`);const entries=await readDir(next,force);if(push&&next.href!==currentUrl.href)historyStack.push(currentUrl.href);currentUrl=next;selected=null;addressEl.value='/'+rel(currentUrl);renderFiles(entries);expanded.add(rel(currentUrl));await renderTree();$('back').disabled=!historyStack.length;$('up').disabled=currentUrl.href===rootUrl.href;status(`${entries.length} item(s) in /${rel(currentUrl)}`)}catch(e){filesEl.innerHTML=`<div class="error">${esc(e.message)}</div>`;status(e.message,true)}}
 function renderFiles(entries){filesEl.innerHTML='';if(!entries.length){filesEl.innerHTML='<div class="empty">This directory is empty.</div>';return}for(const item of entries){const row=document.createElement('div');row.className='row item';row.innerHTML=`<div class="name"><span>${icon(item)}</span><span class="filename">${esc(item.name)}</span></div><div class="meta">${esc(item.isDir?'Directory':item.size||item.ext.toUpperCase()||'File')}</div><div class="meta">${esc(item.modified)}</div>`;row.onclick=()=>{filesEl.querySelectorAll('.selected').forEach(x=>x.classList.remove('selected'));row.classList.add('selected');selected=item;status(`${item.isDir?'Directory':'File'}: ${rel(item.url)}`)};row.ondblclick=()=>openItem(item);filesEl.appendChild(row)}}
 async function renderTree(){treeEl.innerHTML='';treeEl.appendChild(await treeNode(rootUrl,'SERVER ROOT',0))}
 async function treeNode(url,label,depth){const wrap=document.createElement('div'),line=document.createElement('div'),r=rel(url),isOpen=expanded.has(r);line.className='tree-line'+(url.href===currentUrl.href?' active':'');line.innerHTML=`<span>${isOpen?'▾':'▸'}</span><span>📁</span><span>${esc(label)}</span>`;line.onclick=async ev=>{ev.stopPropagation();isOpen?expanded.delete(r):expanded.add(r);await navigate(url,true,false)};wrap.appendChild(line);if(isOpen&&depth<12){const ch=document.createElement('div');ch.className='children';try{for(const i of (await readDir(url)).filter(x=>x.isDir))ch.appendChild(await treeNode(i.url,i.name,depth+1))}catch(e){ch.innerHTML=`<div class="error">${esc(e.message)}</div>`}wrap.appendChild(ch)}return wrap}
 function show(title,html){viewerTitle.textContent=title;viewerBody.innerHTML=html;overlay.hidden=false}
 function closeViewer(){overlay.hidden=true;viewerBody.innerHTML=''}
 function openTab(url){const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener';document.body.appendChild(a);a.click();a.remove()}
 async function textView(item){try{status(`Opening ${rel(item.url)} ...`);const r=await fetch(item.url.href,{cache:'no-store',credentials:'same-origin'});if(!r.ok)throw new Error(`HTTP ${r.status}`);show(item.name,`<pre>${esc(await r.text())}</pre>`);status(`Opened ${rel(item.url)}`)}catch(e){status(e.message,true)}}
 async function runExe(item){
  const r=rel(item.url).replace(/\\/g,'/');
  try{
   status(`Launching ${r} ...`);
   const api=new URL(explorerUrl);
   api.searchParams.set('api','start');
   api.searchParams.set('file',r);
   const response=await fetch(api.href,{cache:'no-store',credentials:'same-origin'});
   const text=await response.text();
   if(!response.ok||!text.includes('START_OK=1')){
    show(`Launch failed — ${item.name}`,`<pre>${esc(text||`HTTP ${response.status}`)}</pre>`);
    status(`Could not launch ${r}`,true);
    return;
   }
   status(`Launched on the server: ${r}`);
  }catch(e){status(e.message,true)}
 }
 async function openItem(item){if(item.isDir)return navigate(item.url);const e=item.ext;if(e==='bas'){show(item.name,`<iframe src="${esc(item.url.href)}"></iframe>`);return status(`Executed BASIC page: ${rel(item.url)}`)}if(e==='exe')return runExe(item);if(['txt','log','md','csv','json','xml','ini','cfg','conf','css','js','vbs','ps1','bat','cmd','inc','asm','c','cpp','h','py','php'].includes(e))return textView(item);if(['png','jpg','jpeg','gif','webp','bmp','svg','ico'].includes(e)){show(item.name,`<img alt="" src="${esc(item.url.href)}">`);return}if(e==='pdf'||['html','htm'].includes(e)){show(item.name,`<iframe src="${esc(item.url.href)}"></iframe>`);return}if(['mp4','webm','avi','mov'].includes(e)){show(item.name,`<video controls autoplay src="${esc(item.url.href)}"></video>`);return}if(['mp3','wav','ogg','flac'].includes(e)){show(item.name,`<audio controls autoplay src="${esc(item.url.href)}"></audio>`);return}openTab(item.url.href);status(`Browser opened/downloaded: ${rel(item.url)}`)}
 $('refresh').onclick=()=>{cache.delete(currentUrl.href);navigate(currentUrl,false,true)};$('back').onclick=()=>{const p=historyStack.pop();if(p)navigate(p,false)};$('up').onclick=()=>{if(currentUrl.href!==rootUrl.href)navigate(new URL('../',currentUrl))};$('go').onclick=()=>{try{const v=addressEl.value.trim(),u=v.startsWith('/')?new URL(v.slice(1),rootUrl):new URL(v,currentUrl);navigate(u)}catch(e){status(e.message,true)}};addressEl.onkeydown=e=>{if(e.key==='Enter')$('go').click()};filesEl.onkeydown=e=>{if(e.key==='Enter'&&selected)openItem(selected)};$('closeViewer').onclick=closeViewer;overlay.onclick=e=>{if(e.target===overlay)closeViewer()};document.onkeydown=e=>{if(e.key==='Escape'&&!overlay.hidden)closeViewer()};$('closeApp').onclick=()=>{window.close();setTimeout(()=>document.body.innerHTML='<div class="notice"><h2>Explorer closed</h2><p>You may close this tab.</p></div>',100)};
 navigate(rootUrl,false);
})();
</script>
</body>
</html>
