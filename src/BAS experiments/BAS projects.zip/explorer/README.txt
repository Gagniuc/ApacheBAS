ApacheBAS Server Explorer v2

COPY:
  server_explorer.bas
  .htaccess

directly into the directory you want to browse.

For the whole XAMPP web root, copy both files directly into:
  C:\xampp\htdocs\

Then open:
  http://127.0.0.1/server_explorer.bas

Double-click behavior:
- directory: navigate
- .bas: execute inside the viewer
- text/code: read-only viewer
- images/PDF/HTML/media: viewer
- other files: browser open/download
- .exe in tools\: execute with ApacheBAS EXEC
- .exe elsewhere: browser download/open only, because ApacheBAS v0.1.33.3 itself limits EXEC to tools\
