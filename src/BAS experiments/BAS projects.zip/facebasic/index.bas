<?bas
GOTO APP_MAIN

GENERATE_TOKEN:
RANDOMIZE
TOKEN_PART_A$ = RND
TOKEN_PART_B$ = RND
TOKEN_PART_C$ = RND
TOKEN_PART_D$ = RND
NEW_TOKEN$ = MID$(TOKEN_PART_A$, 3, 6) & MID$(TOKEN_PART_B$, 3, 6) & MID$(TOKEN_PART_C$, 3, 6) & MID$(TOKEN_PART_D$, 3, 6)
RETURN

ACTION_REGISTER:
FORM_USER$ = POST_USERNAME$
FORM_PASS$ = POST_PASSWORD$
CHECK_USER$ = FORM_USER$
INCLUDE("includes/validate-user.inc")
FORM_USER$ = CHECK_USER$
IF USER_OK = 0 THEN ERROR$ = "Username: 3-64 characters; use letters, numbers, dot, hyphen, underscore or one @ sign."
IF USER_OK = 0 THEN RETURN
IF LEN(FORM_PASS$) < 6 OR LEN(FORM_PASS$) > 64 THEN ERROR$ = "Password length must be between 6 and 64 characters."
IF LEN(FORM_PASS$) < 6 OR LEN(FORM_PASS$) > 64 THEN RETURN
ALL_USERS$ = USERS_TEXT$
USER_RECORD_KEY$ = CHR$(10) + FORM_USER$ + "|"
EXISTING_POSITION = INSTR(ALL_USERS$, USER_RECORD_KEY$)
IF EXISTING_POSITION > 0 THEN ERROR$ = "That username is already registered."
IF EXISTING_POSITION > 0 THEN RETURN
HASH_USER$ = FORM_USER$
HASH_PASS$ = FORM_PASS$
INCLUDE("includes/hash-password.inc")
GOSUB GENERATE_TOKEN
NEW_RECORD$ = FORM_USER$ + "|" + HASH_RESULT$ + "|" + NEW_TOKEN$ + CHR$(10)
IF LEN(ALL_USERS$) + LEN(NEW_RECORD$) > 1950 THEN ERROR$ = "The compact user store is full. Reset the demo or move accounts to a database."
IF LEN(ALL_USERS$) + LEN(NEW_RECORD$) > 1950 THEN RETURN
APPENDFILE "data/users.txt", NEW_RECORD$
IF FILE_OK = 0 THEN ERROR$ = "The account could not be saved: " + FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
USERS_TEXT$ = USERS_TEXT$ + NEW_RECORD$
AUTH_USER$ = FORM_USER$
AUTH_TOKEN$ = NEW_TOKEN$
AUTH_VALID = 1
CURRENT_USER$ = FORM_USER$
NOTICE$ = "Account created successfully. You are now logged in."
RETURN

ACTION_LOGIN:
FORM_USER$ = POST_USERNAME$
FORM_PASS$ = POST_PASSWORD$
CHECK_USER$ = FORM_USER$
INCLUDE("includes/validate-user.inc")
FORM_USER$ = CHECK_USER$
IF USER_OK = 0 THEN ERROR$ = "Invalid username or password."
IF USER_OK = 0 THEN RETURN
ALL_USERS$ = USERS_TEXT$
USER_RECORD_KEY$ = CHR$(10) + FORM_USER$ + "|"
USER_RECORD_POSITION = INSTR(ALL_USERS$, USER_RECORD_KEY$)
IF USER_RECORD_POSITION = 0 THEN ERROR$ = "Invalid username or password."
IF USER_RECORD_POSITION = 0 THEN RETURN
HASH_POSITION = USER_RECORD_POSITION + LEN(USER_RECORD_KEY$)
STORED_HASH$ = MID$(ALL_USERS$, HASH_POSITION, 24)
AUTH_TAIL$ = MID$(ALL_USERS$, HASH_POSITION + 25, LEN(ALL_USERS$))
AUTH_END = INSTR(AUTH_TAIL$, CHR$(10))
STORED_AUTH$ = AUTH_TAIL$
IF AUTH_END > 0 THEN STORED_AUTH$ = LEFT$(AUTH_TAIL$, AUTH_END - 1)
HASH_USER$ = FORM_USER$
HASH_PASS$ = FORM_PASS$
INCLUDE("includes/hash-password.inc")
IF HASH_RESULT$ <> STORED_HASH$ THEN ERROR$ = "Invalid username or password."
IF HASH_RESULT$ <> STORED_HASH$ THEN RETURN
IF LEN(STORED_AUTH$) < 6 OR LEN(STORED_AUTH$) > 24 THEN ERROR$ = "This account has no valid access token. Recreate the account after resetting the demo."
IF LEN(STORED_AUTH$) < 6 OR LEN(STORED_AUTH$) > 24 THEN RETURN
AUTH_USER$ = FORM_USER$
AUTH_TOKEN$ = STORED_AUTH$
AUTH_VALID = 1
CURRENT_USER$ = FORM_USER$
NOTICE$ = "Login successful."
RETURN

ACTION_POST:
IF CURRENT_USER$ = "" THEN ERROR$ = "The authentication token was not accepted. Please log in again."
IF CURRENT_USER$ = "" THEN RETURN
BODY$ = TRIM$(POST_TEXT$)
BODY$ = LEFT$(BODY$, 500)
IMAGE$ = TRIM$(POST_IMAGE$)
IMAGE_OK = 0
IF IMAGE$ = "" THEN GOTO POST_IMAGE_DONE
IMAGE_OK = 1
IF LEN(IMAGE$) < 13 OR LEN(IMAGE$) > 120 THEN IMAGE_OK = 0
IF LEFT$(IMAGE$, 8) <> "uploads/" THEN IMAGE_OK = 0
IMAGE_I = 1
WHILE IMAGE_I <= LEN(IMAGE$)
  IMAGE_C = ASC(MID$(IMAGE$, IMAGE_I, 1))
  IMAGE_CHAR_OK = 0
  IF IMAGE_C >= 48 AND IMAGE_C <= 57 THEN IMAGE_CHAR_OK = 1
  IF IMAGE_C >= 65 AND IMAGE_C <= 90 THEN IMAGE_CHAR_OK = 1
  IF IMAGE_C >= 97 AND IMAGE_C <= 122 THEN IMAGE_CHAR_OK = 1
  IF IMAGE_C = 95 OR IMAGE_C = 45 OR IMAGE_C = 46 THEN IMAGE_CHAR_OK = 1
  IF IMAGE_C = 47 AND IMAGE_I = 8 THEN IMAGE_CHAR_OK = 1
  IF IMAGE_CHAR_OK = 0 THEN IMAGE_OK = 0
  IMAGE_I = IMAGE_I + 1
WEND
IMAGE_LOW$ = LCASE$(IMAGE$)
IMAGE_EXT_OK = 0
IF RIGHT$(IMAGE_LOW$, 4) = ".png" THEN IMAGE_EXT_OK = 1
IF RIGHT$(IMAGE_LOW$, 4) = ".jpg" THEN IMAGE_EXT_OK = 1
IF RIGHT$(IMAGE_LOW$, 4) = ".gif" THEN IMAGE_EXT_OK = 1
IF RIGHT$(IMAGE_LOW$, 5) = ".jpeg" THEN IMAGE_EXT_OK = 1
IF RIGHT$(IMAGE_LOW$, 5) = ".webp" THEN IMAGE_EXT_OK = 1
IF IMAGE_EXT_OK = 0 THEN IMAGE_OK = 0
POST_IMAGE_DONE:
IF BODY$ = "" AND IMAGE$ = "" THEN ERROR$ = "Write some text, upload an image, or use both."
IF BODY$ = "" AND IMAGE$ = "" THEN RETURN
IF IMAGE$ <> "" AND IMAGE_OK = 0 THEN ERROR$ = "The submitted image path is invalid. Please upload the image again."
IF IMAGE$ <> "" AND IMAGE_OK = 0 THEN RETURN
OLD_COUNTER$ = READFILE$("data/counter.txt")
NEW_POST_NUMBER = VAL(OLD_COUNTER$) + 1
POST_ID$ = RIGHT$("00000000" + STR$(NEW_POST_NUMBER), 8)
POST_PATH$ = "data/post-" + POST_ID$ + ".txt"
TEXT_HTML$ = HTML$(BODY$)
IMAGE_HTML$ = ""
IF IMAGE_OK THEN IMAGE_HTML$ = "<img class=""post-image"" src=""" & IMAGE$ & """ alt=""Posted image"">"
POST_AVATAR_CONTENT$ = HTML$(LEFT$(UCASE$(CURRENT_USER$), 1))
IF PROFILE_IMAGE$ <> "" THEN POST_AVATAR_CONTENT$ = "<img src=""" & HTML$(PROFILE_IMAGE$) & """ alt=""Profile picture"">"
ENTRY$ = "<article class=""post""><div class=""post-head""><div class=""avatar small user-avatar"" data-user=""" & HTML$(CURRENT_USER$) & """>" & POST_AVATAR_CONTENT$ & "</div><div><strong>@" & HTML$(CURRENT_USER$) & "</strong><span>" & HTML$(DATE$ & " " & TIME$) & "</span></div></div><div class=""post-text"">" & TEXT_HTML$ & "</div>" & IMAGE_HTML$ & "</article>"
WRITEFILE POST_PATH$, ENTRY$
POST_WRITE_OK = FILE_OK
POST_WRITE_ERROR$ = FILE_ERROR$
IF POST_WRITE_OK = 0 THEN ERROR$ = "The post could not be saved: " + POST_WRITE_ERROR$
IF POST_WRITE_OK = 0 THEN RETURN
WRITEFILE "data/counter.txt", STR$(NEW_POST_NUMBER)
IF FILE_OK = 0 THEN ERROR$ = "The post index could not be updated: " + FILE_ERROR$
IF FILE_OK = 0 THEN RETURN
NOTICE$ = "Post published successfully."
RETURN

APP_MAIN:
ERROR$ = ""
NOTICE$ = ""
CURRENT_USER$ = ""
AUTH_USER$ = ""
AUTH_TOKEN$ = ""
AUTH_VALID = 0
INCLUDE("includes/load-session.inc")
INCLUDE("includes/load-avatar.inc")
ACTION$ = LCASE$(TRIM$(POST_ACTION$))
IF UCASE$(SERVER_REQUEST_METHOD$) = "POST" AND ACTION$ = "" THEN ERROR$ = "The POST request arrived, but ApacheBAS did not parse the action field."
IF ACTION$ = "register" THEN GOSUB ACTION_REGISTER
IF ACTION$ = "login" THEN GOSUB ACTION_LOGIN
IF ACTION$ = "post" THEN GOSUB ACTION_POST
IF ACTION$ = "login" AND ERROR$ = "" AND CURRENT_USER$ = "" THEN ERROR$ = "Login was processed, but authentication was not opened."
IF ACTION$ = "register" AND ERROR$ = "" AND CURRENT_USER$ = "" THEN ERROR$ = "The account was saved, but authentication was not opened."
INCLUDE("includes/load-avatar.inc")
COUNTER_TEXT$ = READFILE$("data/counter.txt")
POST_COUNT = VAL(COUNTER_TEXT$)
AUTH_CLASS$ = ""
APP_CLASS$ = "hidden"
LOGGED_CLASS$ = "hidden"
GUEST_CLASS$ = ""
IF CURRENT_USER$ <> "" THEN AUTH_CLASS$ = "hidden"
IF CURRENT_USER$ <> "" THEN APP_CLASS$ = ""
IF CURRENT_USER$ <> "" THEN LOGGED_CLASS$ = ""
IF CURRENT_USER$ <> "" THEN GUEST_CLASS$ = "hidden"
INITIAL$ = "?"
IF CURRENT_USER$ <> "" THEN INITIAL$ = LEFT$(UCASE$(CURRENT_USER$), 1)
AVATAR_CONTENT$ = HTML$(INITIAL$)
IF PROFILE_IMAGE$ <> "" THEN AVATAR_CONTENT$ = "<img src=""" & HTML$(PROFILE_IMAGE$) & """ alt=""Profile picture"">"
AVATARS_CLIENT$ = ""
IF CURRENT_USER$ <> "" THEN AVATARS_CLIENT$ = AVATARS_RAW$
PRINT "@@CONTENT-TYPE text/html; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
PRINT "@@HEADER X-Content-Type-Options: nosniff"
PRINT "@@HEADER X-Frame-Options: DENY"
PRINT "@@HEADER Referrer-Policy: same-origin"
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>FaceBASIC · ApacheBAS social network</title>
<style>
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:#eef1f5;color:#172033;font-family:Inter,Segoe UI,Arial,sans-serif}
.hidden{display:none!important}
.topbar{position:sticky;top:0;z-index:20;height:64px;background:#1769e0;color:#fff;box-shadow:0 2px 14px #142b4d33}
.top-inner{max-width:1050px;height:100%;margin:auto;padding:0 20px;display:flex;align-items:center;justify-content:space-between}
.brand{display:flex;align-items:center;gap:11px;font-weight:800;font-size:21px;letter-spacing:-.4px}
.brand-mark{width:38px;height:38px;border-radius:11px;background:#fff;color:#1769e0;display:grid;place-items:center;font:900 20px Georgia}
.top-note{font-size:13px;color:#dbe9ff}
.logout{text-decoration:none;border:1px solid #ffffff66;background:#ffffff17;color:#fff;border-radius:9px;padding:8px 12px;cursor:pointer;font-weight:700}
.page{max-width:1050px;margin:auto;padding:28px 20px 70px}
.alert{background:#fff0f0;border:1px solid #efb2b2;color:#9d2020;padding:13px 15px;border-radius:11px;margin-bottom:18px;box-shadow:0 4px 14px #2230470b}
.notice{background:#effbf2;border:1px solid #9bd3aa;color:#17652d;padding:13px 15px;border-radius:11px;margin-bottom:18px;box-shadow:0 4px 14px #2230470b}
.auth-shell{display:grid;grid-template-columns:1.15fr .85fr;gap:24px;align-items:start;margin-top:38px}
.intro{padding:40px 26px 20px}
.intro h1{font-size:clamp(38px,6vw,68px);line-height:.96;margin:0 0 20px;color:#1769e0;letter-spacing:-3px}
.intro p{font-size:18px;line-height:1.65;color:#526078;max-width:620px}
.feature-row{display:flex;gap:10px;flex-wrap:wrap;margin-top:24px}
.chip{background:#e0ebff;color:#1555ac;border-radius:999px;padding:9px 12px;font-size:13px;font-weight:700}
.auth-card,.card,.post{background:#fff;border:1px solid #dfe4ec;border-radius:14px;box-shadow:0 8px 28px #22304712}
.auth-card{padding:22px}
.auth-card h2{margin:0 0 5px}
.auth-card p{margin:0 0 17px;color:#6a768a;font-size:14px}
.field{display:flex;flex-direction:column;gap:6px;margin-bottom:12px}
.field label{font-size:13px;font-weight:700;color:#435067}
.field input,.composer textarea{width:100%;border:1px solid #ccd4df;border-radius:10px;padding:12px 13px;font:inherit;background:#fbfcfe;color:#172033;outline:none}
.field input:focus,.composer textarea:focus{border-color:#1769e0;box-shadow:0 0 0 3px #1769e022}
.primary{width:100%;border:0;border-radius:10px;background:#1769e0;color:#fff;padding:12px 16px;font-weight:800;cursor:pointer}
.secondary-title{border-top:1px solid #e7ebf0;margin-top:22px;padding-top:21px}
.app-grid{display:grid;grid-template-columns:280px minmax(0,1fr);gap:20px}
.card{padding:20px}
.profile-card{position:sticky;top:84px}
.avatar{width:72px;height:72px;border-radius:50%;display:grid;place-items:center;position:relative;overflow:hidden;isolation:isolate;background:linear-gradient(145deg,#1769e0,#55a2ff);color:#fff;font-size:30px;font-weight:900;box-shadow:inset 0 0 0 4px #ffffff55}
.avatar.small{width:43px;height:43px;font-size:17px;box-shadow:none;flex:0 0 auto}
.avatar img{position:absolute;inset:0;width:100%;height:100%;min-width:100%;min-height:100%;max-width:none;max-height:none;border-radius:inherit;object-fit:cover;object-position:center;display:block}
.profile-photo-tools{margin-top:16px;display:flex;flex-direction:column;gap:8px}
.profile-photo-button,.profile-photo-remove{border:1px solid #ccd4df;background:#fff;color:#344259;border-radius:9px;padding:9px 11px;font-weight:700;font-size:13px;cursor:pointer;text-align:center}
.profile-photo-button input{display:none}
.profile-photo-remove{display:none}
.profile-photo-status{font-size:12px;color:#6a768a;line-height:1.4}
.profile-card h2{margin:14px 0 2px}
.muted{color:#6a768a;line-height:1.55}
.mini-stat{margin-top:20px;background:#f4f7fb;border-radius:10px;padding:12px;font-size:13px;color:#526078}
.composer{padding:18px;margin-bottom:18px}
.composer-top{display:flex;gap:12px;align-items:flex-start}
.composer textarea{resize:vertical;min-height:98px}
.composer-actions{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:13px;flex-wrap:wrap}
.upload-tools{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.file-label,.clear-image{border:1px solid #ccd4df;background:#fff;color:#344259;border-radius:9px;padding:9px 11px;font-weight:700;font-size:13px;cursor:pointer}
.file-label input{display:none}
.clear-image{display:none}
.post-button{border:0;background:#1769e0;color:#fff;border-radius:9px;padding:10px 20px;font-weight:800;cursor:pointer}
.upload-status{width:100%;font-size:12px;color:#6a768a}
.preview{display:none;max-width:100%;max-height:330px;margin-top:12px;border-radius:12px;border:1px solid #dce2ea;object-fit:contain;background:#f4f6f9}
.feed-title{display:flex;justify-content:space-between;align-items:end;margin:8px 2px 12px}
.feed-title h2{margin:0}
.feed-title span{color:#788397;font-size:13px}
.post{padding:18px;margin-bottom:16px}
.post-head{display:flex;align-items:center;gap:11px}
.post-head strong{display:block}
.post-head span{display:block;color:#7b8697;font-size:12px;margin-top:3px}
.post-text{white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.55;margin-top:14px}
.post-text:empty{display:none}
.post-image{display:block;width:100%;max-height:620px;object-fit:contain;background:#f1f3f6;border-radius:11px;margin-top:14px;border:1px solid #e0e5ec}
.empty{padding:35px;text-align:center;color:#718096;background:#fff;border:1px dashed #c7d0dc;border-radius:14px}
.footer{text-align:center;color:#8791a1;font-size:12px;margin-top:30px}
@media(max-width:760px){.top-note{display:none}
.auth-shell,.app-grid{grid-template-columns:1fr}
.intro{padding:20px 2px}
.intro h1{letter-spacing:-2px}
.profile-card{position:static}
.page{padding-left:13px;padding-right:13px}
.composer-actions{align-items:stretch}
.post-button{width:100%}
}

</style>
</head>
<body>
<header class="topbar"><div class="top-inner"><div class="brand"><span class="brand-mark">fB</span> FaceBASIC</div><div class="top-note <?= GUEST_CLASS$ ?>">A tiny social network powered by ApacheBAS</div><a class="logout <?= LOGGED_CLASS$ ?>" href="index.bas">Log out</a></div></header>
<main class="page">
<?bas IF ERROR$ <> "" THEN PRINT "<div class=""alert"">"; HTML$(ERROR$); "</div>" ?>
<?bas IF NOTICE$ <> "" THEN PRINT "<div class=""notice"">"; HTML$(NOTICE$); "</div>" ?>
<section class="auth-shell <?= AUTH_CLASS$ ?>">
  <div class="intro">
    <h1>Social networking,<br>in BASIC.</h1>
    <p>FaceBASIC is a deliberately small but functional social site: create an account, sign in, publish text and images, and read a shared chronological feed.</p>
    <div class="feature-row"><span class="chip">File-based accounts</span><span class="chip">Account-token access</span><span class="chip">Text + image posts</span><span class="chip">Profile pictures</span><span class="chip">No database</span></div>
  </div>
  <div class="auth-card">
    <h2>Log in</h2><p>Continue to the shared FaceBASIC feed.</p>
    <form method="post" action="index.bas">
      <input type="hidden" name="action" value="login">
      <div class="field"><label>Username</label><input name="username" maxlength="64" autocomplete="username" required></div>
      <div class="field"><label>Password</label><input type="password" name="password" maxlength="64" autocomplete="current-password" required></div>
      <button class="primary" type="submit">Log in</button>
    </form>
    <div class="secondary-title"><h2>Create account</h2><p>Username or email-style name; 3-64 characters.</p></div>
    <form method="post" action="index.bas">
      <input type="hidden" name="action" value="register">
      <div class="field"><label>Username</label><input name="username" minlength="3" maxlength="64" pattern="[A-Za-z0-9._@-]+" autocomplete="username" required></div>
      <div class="field"><label>Password</label><input type="password" name="password" minlength="6" maxlength="64" autocomplete="new-password" required></div>
      <button class="primary" type="submit">Create account</button>
    </form>
  </div>
</section>

<section class="app-grid <?= APP_CLASS$ ?>">
  <aside><div class="card profile-card"><div class="avatar user-avatar" data-user="<?= HTML$(CURRENT_USER$) ?>"><?= AVATAR_CONTENT$ ?></div><h2>@<?= HTML$(CURRENT_USER$) ?></h2><div class="muted">FaceBASIC member</div><div class="profile-photo-tools"><label class="profile-photo-button">Change profile picture<input id="profileFileInput" type="file" accept="image/png,image/jpeg,image/gif,image/webp"></label><button id="removeProfilePicture" class="profile-photo-remove" type="button">Remove profile picture</button><div id="profilePhotoStatus" class="profile-photo-status">PNG, JPG, GIF or WebP; maximum 1 MiB.</div></div><div class="mini-stat"><b><?= POST_COUNT ?></b> total posts in the shared feed<br>Showing the latest 20.</div></div></aside>
  <div>
    <form class="card composer" method="post" action="index.bas?user=<?= HTML$(AUTH_USER$) ?>&amp;auth=<?= HTML$(AUTH_TOKEN$) ?>" id="postForm">
      <input type="hidden" name="action" value="post">
      <input type="hidden" name="user" value="<?= HTML$(AUTH_USER$) ?>">
      <input type="hidden" name="auth" value="<?= HTML$(AUTH_TOKEN$) ?>">
      <input type="hidden" name="image" id="imagePath" value="">
      <div class="composer-top"><div class="avatar small user-avatar" data-user="<?= HTML$(CURRENT_USER$) ?>"><?= AVATAR_CONTENT$ ?></div><textarea name="text" maxlength="500" placeholder="What is happening, @<?= HTML$(CURRENT_USER$) ?>?"></textarea></div>
      <img id="preview" class="preview" alt="Image preview">
      <div class="composer-actions"><div class="upload-tools"><label class="file-label">Add image<input id="fileInput" type="file" accept="image/png,image/jpeg,image/gif,image/webp"></label><button id="clearImage" class="clear-image" type="button">Remove image</button></div><button class="post-button" type="submit">Publish</button><div id="uploadStatus" class="upload-status">Text, image, or both. Images: maximum 1 MiB.</div></div>
    </form>
    <div id="feed" class="feed-title"><h2>Latest posts</h2><span>Newest first</span></div>
    <?bas
    FEED_NUMBER = 0
    IF CURRENT_USER$ <> "" THEN FEED_NUMBER = POST_COUNT
    FEED_SHOWN = 0
    WHILE FEED_NUMBER > 0 AND FEED_SHOWN < 20
      FEED_ID$ = RIGHT$("00000000" + STR$(FEED_NUMBER), 8)
      FEED_HTML$ = READFILE$("data/post-" + FEED_ID$ + ".txt")
      IF FEED_HTML$ <> "" THEN PRINT FEED_HTML$
      FEED_NUMBER = FEED_NUMBER - 1
      FEED_SHOWN = FEED_SHOWN + 1
    WEND
    IF CURRENT_USER$ <> "" AND POST_COUNT = 0 THEN PRINT "<div class=""empty""><b>No posts yet.</b><br>Publish the first FaceBASIC update above.</div>"
    ?>
    <div class="footer">FaceBASIC 1.3.1 · ApacheBAS-ASM v0.1.33.3 · avatar clipping fix</div>
  </div>
</section>
</main>
<script>
const authUser='<?= HTML$(AUTH_USER$) ?>';
const authToken='<?= HTML$(AUTH_TOKEN$) ?>';
const avatarRecords="<?= JSON$(AVATARS_CLIENT$) ?>";
const avatarMap={};
avatarRecords.split(/\r?\n/).forEach(line=>{const divider=line.indexOf('|');if(divider>0)avatarMap[line.slice(0,divider)]=line.slice(divider+1);});
if(authUser&&authToken){history.replaceState(null,'','index.bas?user='+encodeURIComponent(authUser)+'&auth='+encodeURIComponent(authToken));}
function applyAvatar(element,user){
  if(!element||!user)return;
  element.dataset.user=user;
  const url=avatarMap[user]||'';
  if(url){const image=document.createElement('img');image.src=url;image.alt='Profile picture';element.replaceChildren(image);}
  else{element.textContent=(user.charAt(0)||'?').toUpperCase();}
}
function refreshAvatars(){
  document.querySelectorAll('.user-avatar[data-user]').forEach(element=>applyAvatar(element,element.dataset.user));
  document.querySelectorAll('.post-head').forEach(head=>{const name=head.querySelector('strong');const avatar=head.querySelector('.avatar');if(!name||!avatar)return;const user=name.textContent.replace(/^@/,'').trim().toLowerCase();applyAvatar(avatar,user);});
}
refreshAvatars();
const profileFileInput=document.getElementById('profileFileInput');
const profilePhotoStatus=document.getElementById('profilePhotoStatus');
const removeProfilePicture=document.getElementById('removeProfilePicture');
if(removeProfilePicture&&avatarMap[authUser])removeProfilePicture.style.display='block';
if(profileFileInput){
  profileFileInput.addEventListener('change',async()=>{
    const file=profileFileInput.files[0];
    if(!file)return;
    if(file.size>1048576){profilePhotoStatus.textContent='Image is larger than 1 MiB.';profileFileInput.value='';return;}
    const extension=(file.name.split('.').pop()||'').toLowerCase();
    if(!['png','jpg','jpeg','gif','webp'].includes(extension)){profilePhotoStatus.textContent='Unsupported image type.';profileFileInput.value='';return;}
    const unique='avatar_'+Date.now()+'_'+Math.floor(Math.random()*1000000)+'.'+extension;
    profilePhotoStatus.textContent='Uploading profile picture...';
    try{
      const response=await fetch('upload-api.bas?mode=avatar&filename='+encodeURIComponent(unique)+'&user='+encodeURIComponent(authUser)+'&auth='+encodeURIComponent(authToken),{method:'POST',headers:{'Content-Type':file.type||'application/octet-stream'},body:file});
      const result=await response.json();
      if(!result.ok)throw new Error(result.error||'Upload failed.');
      avatarMap[authUser]=result.url;
      refreshAvatars();
      removeProfilePicture.style.display='block';
      profilePhotoStatus.textContent='Profile picture changed successfully.';
      profileFileInput.value='';
    }catch(error){profilePhotoStatus.textContent='Profile picture error: '+error.message;profileFileInput.value='';}
  });
}
if(removeProfilePicture){
  removeProfilePicture.addEventListener('click',async()=>{
    profilePhotoStatus.textContent='Removing profile picture...';
    try{
      const response=await fetch('upload-api.bas?mode=avatar-remove&user='+encodeURIComponent(authUser)+'&auth='+encodeURIComponent(authToken),{method:'POST'});
      const result=await response.json();
      if(!result.ok)throw new Error(result.error||'Removal failed.');
      avatarMap[authUser]='';
      refreshAvatars();
      removeProfilePicture.style.display='none';
      profilePhotoStatus.textContent='Profile picture removed.';
    }catch(error){profilePhotoStatus.textContent='Profile picture error: '+error.message;}
  });
}
const fileInput=document.getElementById('fileInput');
const imagePath=document.getElementById('imagePath');
const preview=document.getElementById('preview');
const statusBox=document.getElementById('uploadStatus');
const clearButton=document.getElementById('clearImage');
if(fileInput){
  fileInput.addEventListener('change',async()=>{
    const file=fileInput.files[0];
    if(!file)return;
    if(file.size>1048576){statusBox.textContent='Image is larger than 1 MiB.';fileInput.value='';return;}
    const originalExt=(file.name.split('.').pop()||'').toLowerCase();
    const allowed=['png','jpg','jpeg','gif','webp'];
    if(!allowed.includes(originalExt)){statusBox.textContent='Unsupported image type.';fileInput.value='';return;}
    const unique='fb_'+Date.now()+'_'+Math.floor(Math.random()*1000000)+'.'+originalExt;
    statusBox.textContent='Uploading image...';
    try{
      const response=await fetch('upload-api.bas?mode=post&filename='+encodeURIComponent(unique)+'&user='+encodeURIComponent(authUser)+'&auth='+encodeURIComponent(authToken),{method:'POST',headers:{'Content-Type':file.type||'application/octet-stream'},body:file});
      const result=await response.json();
      if(!result.ok)throw new Error(result.error||'Upload failed.');
      imagePath.value=result.url;
      preview.src=result.url;
      preview.style.display='block';
      clearButton.style.display='inline-block';
      statusBox.textContent='Image uploaded: '+result.name+' ('+result.size+' bytes).';
    }catch(error){statusBox.textContent='Upload error: '+error.message;imagePath.value='';preview.style.display='none';}
  });
  clearButton.addEventListener('click',()=>{fileInput.value='';imagePath.value='';preview.removeAttribute('src');preview.style.display='none';clearButton.style.display='none';statusBox.textContent='Image removed. You may publish text only.';});
}
</script>
</body>
</html>
