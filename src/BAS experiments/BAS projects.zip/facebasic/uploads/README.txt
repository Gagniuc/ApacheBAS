FaceBASIC image uploads
=======================

Uploaded PNG, JPG/JPEG, GIF and WebP files are stored here by SAVEUPLOAD.
The maximum upload size enforced by ApacheBAS v0.1.33.3 is 1 MiB.

This directory stores both post images and profile pictures.
