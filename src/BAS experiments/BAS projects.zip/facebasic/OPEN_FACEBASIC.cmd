@echo off
start "" "http://localhost/facebasic/index.bas"
