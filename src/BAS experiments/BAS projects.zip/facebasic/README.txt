FaceBASIC 1.3.1 for ApacheBAS-ASM v0.1.33.3
==========================================

FaceBASIC is a separate compact social-network example built with ApacheBAS,
HTML, CSS and a small amount of browser-side JavaScript.

FUNCTIONS
---------
- account registration;
- login and logout;
- usernames or email-style login names;
- direct file-based account-token authentication;
- shared chronological feed;
- changeable profile pictures, stored per account;
- text posts up to 500 characters;
- PNG, JPG/JPEG, GIF and WebP image posts, maximum 1 MiB;
- combined text and image posts;
- newest 20 posts displayed;
- responsive interface;
- no database or external runtime.

INSTALLATION
------------
Copy the complete folder as:

    <Apache htdocs>\facebasic\

Apache must be allowed to write to:

    facebasic\data\
    facebasic\uploads\

Open:

    http://localhost/facebasic/index.bas

UPGRADE PATCH FROM 1.2.1
------------------------
Copy the contents of the patch over the existing facebasic folder. Replace:

    index.bas
    upload-api.bas
    includes\load-avatar.inc
    data\avatars.txt

Do not delete data\users.txt, data\counter.txt, existing post files, or
uploads. Existing accounts are preserved.

PROFILE PICTURES IN 1.3.1
-------------------------
The profile card contains a Change profile picture control. Selecting a PNG,
JPG/JPEG, GIF or WebP file uploads it through the same authenticated binary
endpoint used by image posts. The selected picture is stored in data\avatars.txt
and is shown in the profile card, composer and feed avatars. Existing posts are
updated in the browser from the current avatar map whenever the feed is loaded.
A Remove profile picture button restores the initial-letter avatar.

Authentication remains the working direct account-token mechanism from 1.2.1.
Existing accounts, 6-24 digit access tokens, posts and uploaded images are kept.

STORAGE
-------
data\users.txt       account records and access tokens
data\counter.txt     post counter
data\avatars.txt     current profile-picture URL per account
data\post-*.txt      one HTML fragment per post
uploads\             uploaded images

data\sessions.txt may remain present for compatibility but is unused by 1.3.1.

SECURITY SCOPE
--------------
This is a functional educational/local-LAN example. The access token is visible
in the URL and browser history. Public deployment requires TLS, production-grade
password hashing, expiring secure sessions, CSRF protection, rate limiting,
moderation and the usual web hardening.

AVATAR CLIPPING FIX IN 1.3.1
----------------------------
The circular avatar container now clips its contents with overflow:hidden.
The image is positioned inside the fixed square with object-fit:cover, so wide,
tall, animated or unusually proportioned images cannot protrude outside the circle.
