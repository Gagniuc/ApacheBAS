@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo Resetting FaceBASIC runtime data...
type nul > "data\users.txt"
type nul > "data\sessions.txt"
type nul > "data\avatars.txt"
del /q "data\post-*.txt" 2>nul
>"data\counter.txt" echo 0
del /q "uploads\*.png" 2>nul
del /q "uploads\*.jpg" 2>nul
del /q "uploads\*.jpeg" 2>nul
del /q "uploads\*.gif" 2>nul
del /q "uploads\*.webp" 2>nul
echo FaceBASIC has been reset.
pause
