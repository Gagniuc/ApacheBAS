FaceBASIC runtime data
======================

users.txt       account records: user|24-character password hash|6-24 character access token; new accounts receive a 24-digit token
avatars.txt     current profile-picture URL per account: user|uploads/file.ext
counter.txt     last numeric post id
post-*.txt      one rendered post fragment per file
sessions.txt    retained for compatibility; unused by FaceBASIC 1.3.0

The directory is protected by .htaccess and must remain writable by Apache.
