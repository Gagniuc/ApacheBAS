APACHEBAS REMOTE DESKTOP - READ ONLY
====================================

Scop
----
Acest exemplu afiseaza in browser desktopul principal al calculatorului pe care
ruleaza Apache/XAMPP. Intervalul de actualizare poate fi schimbat din slider intre 0,5 si 10 secunde; valoarea initiala este 2,5 secunde.
Nu exista control de mouse, tastatura, comenzi, fisiere sau procese.

Instalare
---------
1. Copiaza folderul "remote-admin" in:

   C:\xampp\htdocs\remote-admin\

2. Deschide local:

   http://localhost/remote-admin/remote-admin.bas

Configuratia initiala din .htaccess permite accesul numai de pe localhost.

Acces de la distanta
--------------------
1. Ruleaza SETUP_REMOTE_ACCESS.cmd.
2. Alege utilizatorul si parola HTTP Basic.
3. Deschide din LAN:

   http://IP-UL-SERVERULUI/remote-admin/remote-admin.bas

Pentru acces din Internet trebuie folosit HTTPS si firewall configurat strict.
Nu publica pagina fara autentificare.

Cum functioneaza
----------------
- remote-admin.bas afiseaza interfata si solicita periodic capture.bas.
- remote-admin.bas solicita bridge\capture.bas.
- bridge\capture.bas ruleaza controlat ScreenCapture.exe prin EXEC.
- helperul este inclus atat langa endpoint, cat si in bridge\tools, pentru
  compatibilitate cu ambele reguli de rezolvare EXEC folosite de ApacheBAS.
- helperul scrie alternativ:

  uploads\desktop-a.bmp
  uploads\desktop-b.bmp

- browserul incarca imaginea noua.

Helperul este PE32 nativ, fara runtime C. Codul sursa se afla in:

  tools\ScreenCapture.c
  tools\imports.s

Observatie importanta despre Windows
------------------------------------
Apache trebuie sa ruleze in aceeasi sesiune interactiva Windows cu desktopul
care trebuie capturat. In XAMPP Control Panel, porneste Apache normal, din
sesiunea utilizatorului conectat. Daca Apache ruleaza ca serviciu Windows in
Session 0, captura poate fi neagra, goala sau poate reprezenta alt desktop.
Ecranul Windows blocat poate de asemenea sa nu poata fi capturat normal.

Limite
------
- desktopul principal, nu toate monitoarele;
- imagine BMP redimensionata la maximum 1280 x 800;
- numai vizualizare;
- EXEC are limita de timp a motorului ApacheBAS;
- refreshul se opreste cand tabul este ascuns sau cand se apasa Pause.

Securitate
----------
- folderul tools este blocat pentru acces HTTP;
- uploads permite imagini, dar blocheaza fisiere executabile si scripturi;
- configuratia initiala este localhost-only;
- pentru remote se foloseste autentificarea Apache, nu un token in URL;
- parola nu este stocata in sursa .bas.
