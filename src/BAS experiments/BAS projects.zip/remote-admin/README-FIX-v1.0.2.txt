APACHEBAS REMOTE DESKTOP v1.0.2 - REFRESH SLIDER
==================================================

Copiaza continutul folderului remote-admin din acest patch peste:

  C:\xampp\htdocs\remote-admin\

Patchul schimba numai interfata si documentatia. Nu inlocuieste .htaccess,
.htpasswd, helperul ScreenCapture.exe sau configurarile de acces.

Noutati
-------
- slider pentru intervalul de refresh;
- domeniu: 0,5 - 10 secunde;
- pas: 0,25 secunde;
- valoare initiala: 2,5 secunde;
- valoarea aleasa este pastrata in localStorage-ul browserului;
- nu sunt pornite capturi suprapuse: o captura noua este programata numai dupa
  terminarea celei curente.

Pentru o imagine mai apropiata de timp real, foloseste 0,5 sau 0,75 secunde.
Valorile foarte mici cresc utilizarea procesorului si scrierile pe disc.

Deschide din nou:

  http://localhost/remote-admin/remote-admin.bas

Apoi apasa Ctrl+F5.
