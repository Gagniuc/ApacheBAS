# ApacheBAS Remote Desktop

A small **read-only** desktop viewer for ApacheBAS-ASM v0.1.33.3.

Open locally:

```text
http://localhost/remote-admin/remote-admin.bas
```

The initial `.htaccess` is localhost-only. Run `SETUP_REMOTE_ACCESS.cmd` to
create Apache Basic Authentication before accessing it from another computer.

The viewer includes a refresh slider from 0.5 to 10 seconds, with 2.5 seconds as
the default. The selected interval is remembered by the browser. It provides no
mouse, keyboard, command, process, or file control.

See `README-RO.txt` for installation, security, and Windows session notes.
