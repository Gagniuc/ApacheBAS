Reserved for future local state.
