PRINT "@@CONTENT-TYPE application/json; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store, no-cache, must-revalidate"
PRINT "@@HEADER Pragma: no-cache"

SLOT$ = "a"
SECOND_NOW = INT(TIMER) MOD 2
IF SECOND_NOW = 1 THEN SLOT$ = "b"

EXEC "ScreenCapture.exe", SLOT$

IF EXEC_OK = 0 THEN GOTO CAPTURE_LAUNCH_ERROR
IF EXEC_CODE <> 0 THEN GOTO CAPTURE_TOOL_ERROR

PRINT "{""ok"":true,""url"":""uploads/desktop-"; SLOT$; ".bmp""}"
END

CAPTURE_LAUNCH_ERROR:
MESSAGE$ = "The capture helper could not be started. " + EXEC_ERROR$
PRINT "{""ok"":false,""error"":"""; JSON$(MESSAGE$); """}"
END

CAPTURE_TOOL_ERROR:
MESSAGE$ = "Screen capture failed with helper exit code " + STR$(EXEC_CODE) + "."
IF EXEC_ERROR$ <> "" THEN MESSAGE$ = MESSAGE$ + " " + EXEC_ERROR$
PRINT "{""ok"":false,""error"":"""; JSON$(MESSAGE$); """}"
END
