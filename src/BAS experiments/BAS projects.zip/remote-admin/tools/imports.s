        .section .idata$2,"dw"
        .p2align 2
dll0_descriptor:
        .rva dll0_ilt
        .long 0
        .long 0
        .rva dll0_name
        .rva dll0_iat
dll1_descriptor:
        .rva dll1_ilt
        .long 0
        .long 0
        .rva dll1_name
        .rva dll1_iat
dll2_descriptor:
        .rva dll2_ilt
        .long 0
        .long 0
        .rva dll2_name
        .rva dll2_iat

        .section .idata$3,"dw"
        .zero 20

        .section .idata$4,"dw"
        .p2align 2
dll0_ilt:
        .rva hn_ExitProcess
        .rva hn_CreateFileA
        .rva hn_WriteFile
        .rva hn_CloseHandle
        .rva hn_VirtualAlloc
        .rva hn_GetCommandLineA
        .rva hn_GetModuleFileNameA
        .rva hn_GetFileAttributesA
        .long 0
dll1_ilt:
        .rva hn_GetSystemMetrics
        .rva hn_GetDC
        .rva hn_ReleaseDC
        .long 0
dll2_ilt:
        .rva hn_CreateCompatibleDC
        .rva hn_CreateCompatibleBitmap
        .rva hn_SelectObject
        .rva hn_StretchBlt
        .rva hn_SetStretchBltMode
        .rva hn_GetDIBits
        .rva hn_DeleteObject
        .rva hn_DeleteDC
        .long 0

        .section .idata$5,"dw"
        .p2align 2
dll0_iat:
        .globl __imp__ExitProcess@4
__imp__ExitProcess@4:
        .rva hn_ExitProcess
        .globl __imp__CreateFileA@28
__imp__CreateFileA@28:
        .rva hn_CreateFileA
        .globl __imp__WriteFile@20
__imp__WriteFile@20:
        .rva hn_WriteFile
        .globl __imp__CloseHandle@4
__imp__CloseHandle@4:
        .rva hn_CloseHandle
        .globl __imp__VirtualAlloc@16
__imp__VirtualAlloc@16:
        .rva hn_VirtualAlloc
        .globl __imp__GetCommandLineA@0
__imp__GetCommandLineA@0:
        .rva hn_GetCommandLineA
        .globl __imp__GetModuleFileNameA@12
__imp__GetModuleFileNameA@12:
        .rva hn_GetModuleFileNameA
        .globl __imp__GetFileAttributesA@4
__imp__GetFileAttributesA@4:
        .rva hn_GetFileAttributesA
        .long 0
dll1_iat:
        .globl __imp__GetSystemMetrics@4
__imp__GetSystemMetrics@4:
        .rva hn_GetSystemMetrics
        .globl __imp__GetDC@4
__imp__GetDC@4:
        .rva hn_GetDC
        .globl __imp__ReleaseDC@8
__imp__ReleaseDC@8:
        .rva hn_ReleaseDC
        .long 0
dll2_iat:
        .globl __imp__CreateCompatibleDC@4
__imp__CreateCompatibleDC@4:
        .rva hn_CreateCompatibleDC
        .globl __imp__CreateCompatibleBitmap@12
__imp__CreateCompatibleBitmap@12:
        .rva hn_CreateCompatibleBitmap
        .globl __imp__SelectObject@8
__imp__SelectObject@8:
        .rva hn_SelectObject
        .globl __imp__StretchBlt@44
__imp__StretchBlt@44:
        .rva hn_StretchBlt
        .globl __imp__SetStretchBltMode@8
__imp__SetStretchBltMode@8:
        .rva hn_SetStretchBltMode
        .globl __imp__GetDIBits@28
__imp__GetDIBits@28:
        .rva hn_GetDIBits
        .globl __imp__DeleteObject@4
__imp__DeleteObject@4:
        .rva hn_DeleteObject
        .globl __imp__DeleteDC@4
__imp__DeleteDC@4:
        .rva hn_DeleteDC
        .long 0

        .section .idata$6,"dw"
        .p2align 1
hn_ExitProcess:
        .short 0
        .asciz "ExitProcess"
        .p2align 1
hn_CreateFileA:
        .short 0
        .asciz "CreateFileA"
        .p2align 1
hn_WriteFile:
        .short 0
        .asciz "WriteFile"
        .p2align 1
hn_CloseHandle:
        .short 0
        .asciz "CloseHandle"
        .p2align 1
hn_VirtualAlloc:
        .short 0
        .asciz "VirtualAlloc"
        .p2align 1
hn_GetCommandLineA:
        .short 0
        .asciz "GetCommandLineA"
        .p2align 1
hn_GetModuleFileNameA:
        .short 0
        .asciz "GetModuleFileNameA"
        .p2align 1
hn_GetFileAttributesA:
        .short 0
        .asciz "GetFileAttributesA"
        .p2align 1
hn_GetSystemMetrics:
        .short 0
        .asciz "GetSystemMetrics"
        .p2align 1
hn_GetDC:
        .short 0
        .asciz "GetDC"
        .p2align 1
hn_ReleaseDC:
        .short 0
        .asciz "ReleaseDC"
        .p2align 1
hn_CreateCompatibleDC:
        .short 0
        .asciz "CreateCompatibleDC"
        .p2align 1
hn_CreateCompatibleBitmap:
        .short 0
        .asciz "CreateCompatibleBitmap"
        .p2align 1
hn_SelectObject:
        .short 0
        .asciz "SelectObject"
        .p2align 1
hn_StretchBlt:
        .short 0
        .asciz "StretchBlt"
        .p2align 1
hn_SetStretchBltMode:
        .short 0
        .asciz "SetStretchBltMode"
        .p2align 1
hn_GetDIBits:
        .short 0
        .asciz "GetDIBits"
        .p2align 1
hn_DeleteObject:
        .short 0
        .asciz "DeleteObject"
        .p2align 1
hn_DeleteDC:
        .short 0
        .asciz "DeleteDC"
        .p2align 1
dll0_name:
        .asciz "KERNEL32.dll"
        .p2align 1
dll1_name:
        .asciz "USER32.dll"
        .p2align 1
dll2_name:
        .asciz "GDI32.dll"
        .p2align 1
