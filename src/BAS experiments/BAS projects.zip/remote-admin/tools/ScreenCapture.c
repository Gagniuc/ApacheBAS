/*
  ScreenCapture.exe - read-only desktop capture helper for ApacheBAS.
  Win32 PE32, no C runtime.

  The executable can be started either from the same directory as capture.bas
  or from that application's tools directory. It locates the nearest parent
  directory containing an uploads folder and writes desktop-a.bmp or
  desktop-b.bmp there.
*/

typedef void *HANDLE;
typedef void *HDC;
typedef void *HBITMAP;
typedef void *HGDIOBJ;
typedef void *HWND;
typedef void *LPVOID;
typedef const char *LPCSTR;
typedef char *LPSTR;
typedef unsigned long DWORD;
typedef unsigned int UINT;
typedef unsigned short WORD;
typedef long LONG;
typedef int BOOL;
typedef unsigned char BYTE;

#define NULL ((void *)0)
#define INVALID_HANDLE_VALUE ((HANDLE)(LONG)-1)
#define INVALID_FILE_ATTRIBUTES 0xFFFFFFFFUL
#define FILE_ATTRIBUTE_DIRECTORY 0x00000010UL
#define GENERIC_WRITE 0x40000000UL
#define FILE_SHARE_READ 0x00000001UL
#define CREATE_ALWAYS 2UL
#define FILE_ATTRIBUTE_NORMAL 0x00000080UL
#define MEM_COMMIT 0x00001000UL
#define MEM_RESERVE 0x00002000UL
#define PAGE_READWRITE 0x00000004UL
#define SM_CXSCREEN 0
#define SM_CYSCREEN 1
#define SRCCOPY 0x00CC0020UL
#define CAPTUREBLT 0x40000000UL
#define HALFTONE 4
#define BI_RGB 0UL
#define DIB_RGB_COLORS 0U
#define PATH_CAPACITY 768U

#pragma pack(push, 1)
typedef struct {
    WORD  bfType;
    DWORD bfSize;
    WORD  bfReserved1;
    WORD  bfReserved2;
    DWORD bfOffBits;
} BITMAPFILEHEADER;
#pragma pack(pop)

typedef struct {
    DWORD biSize;
    LONG  biWidth;
    LONG  biHeight;
    WORD  biPlanes;
    WORD  biBitCount;
    DWORD biCompression;
    DWORD biSizeImage;
    LONG  biXPelsPerMeter;
    LONG  biYPelsPerMeter;
    DWORD biClrUsed;
    DWORD biClrImportant;
} BITMAPINFOHEADER;

typedef struct {
    BITMAPINFOHEADER bmiHeader;
    DWORD bmiColors[1];
} BITMAPINFO;

__declspec(dllimport) void   __stdcall ExitProcess(UINT code);
__declspec(dllimport) HANDLE __stdcall CreateFileA(LPCSTR name, DWORD access, DWORD share, LPVOID security, DWORD creation, DWORD attributes, HANDLE template_file);
__declspec(dllimport) BOOL   __stdcall WriteFile(HANDLE file, const void *buffer, DWORD bytes, DWORD *written, LPVOID overlapped);
__declspec(dllimport) BOOL   __stdcall CloseHandle(HANDLE object);
__declspec(dllimport) LPVOID __stdcall VirtualAlloc(LPVOID address, DWORD size, DWORD allocation_type, DWORD protect);
__declspec(dllimport) char * __stdcall GetCommandLineA(void);
__declspec(dllimport) DWORD  __stdcall GetModuleFileNameA(HANDLE module, LPSTR filename, DWORD size);
__declspec(dllimport) DWORD  __stdcall GetFileAttributesA(LPCSTR filename);

__declspec(dllimport) int    __stdcall GetSystemMetrics(int index);
__declspec(dllimport) HDC    __stdcall GetDC(HWND window);
__declspec(dllimport) int    __stdcall ReleaseDC(HWND window, HDC dc);

__declspec(dllimport) HDC     __stdcall CreateCompatibleDC(HDC dc);
__declspec(dllimport) HBITMAP __stdcall CreateCompatibleBitmap(HDC dc, int width, int height);
__declspec(dllimport) HGDIOBJ __stdcall SelectObject(HDC dc, HGDIOBJ object);
__declspec(dllimport) BOOL    __stdcall StretchBlt(HDC dst, int x, int y, int width, int height, HDC src, int src_x, int src_y, int src_width, int src_height, DWORD rop);
__declspec(dllimport) int     __stdcall SetStretchBltMode(HDC dc, int mode);
__declspec(dllimport) int     __stdcall GetDIBits(HDC dc, HBITMAP bitmap, UINT start, UINT lines, LPVOID bits, BITMAPINFO *info, UINT usage);
__declspec(dllimport) BOOL    __stdcall DeleteObject(HGDIOBJ object);
__declspec(dllimport) BOOL    __stdcall DeleteDC(HDC dc);

static BITMAPFILEHEADER file_header;
static BITMAPINFO bitmap_info;
static DWORD bytes_written;
static char module_path[PATH_CAPACITY];
static char search_dir[PATH_CAPACITY];
static char candidate_path[PATH_CAPACITY];
static char output_path[PATH_CAPACITY];

static DWORD string_length(const char *text) {
    DWORD length = 0;
    if (!text) return 0;
    while (text[length]) ++length;
    return length;
}

static BOOL copy_text(char *target, DWORD capacity, const char *source) {
    DWORD index = 0;
    if (!target || !source || capacity == 0) return 0;
    while (source[index]) {
        if (index + 1 >= capacity) return 0;
        target[index] = source[index];
        ++index;
    }
    target[index] = 0;
    return 1;
}

static BOOL append_text(char *target, DWORD capacity, const char *suffix) {
    DWORD length = string_length(target);
    DWORD index = 0;
    if (!target || !suffix || length >= capacity) return 0;
    while (suffix[index]) {
        if (length + index + 1 >= capacity) return 0;
        target[length + index] = suffix[index];
        ++index;
    }
    target[length + index] = 0;
    return 1;
}

static BOOL strip_last_component(char *path) {
    DWORD length = string_length(path);
    if (length == 0) return 0;
    while (length > 0 && (path[length - 1] == '\\' || path[length - 1] == '/')) {
        path[length - 1] = 0;
        --length;
    }
    while (length > 0) {
        if (path[length - 1] == '\\' || path[length - 1] == '/') {
            path[length - 1] = 0;
            return 1;
        }
        --length;
    }
    return 0;
}

static char read_slot(void) {
    char *p = GetCommandLineA();
    if (!p) return 0;

    if (*p == '"') {
        ++p;
        while (*p && *p != '"') ++p;
        if (*p == '"') ++p;
    } else {
        while (*p && *p != ' ' && *p != '\t') ++p;
    }

    while (*p == ' ' || *p == '\t') ++p;
    if (*p == '"') ++p;
    if ((*p == 'a' || *p == 'A') && (p[1] == 0 || p[1] == '"' || p[1] == ' ' || p[1] == '\t')) return 'a';
    if ((*p == 'b' || *p == 'B') && (p[1] == 0 || p[1] == '"' || p[1] == ' ' || p[1] == '\t')) return 'b';
    return 0;
}

static BOOL locate_output_path(char slot) {
    DWORD length;
    DWORD attributes;
    int level;

    length = GetModuleFileNameA(NULL, module_path, PATH_CAPACITY - 1);
    if (length == 0 || length >= PATH_CAPACITY - 1) return 0;
    module_path[length] = 0;
    if (!copy_text(search_dir, PATH_CAPACITY, module_path)) return 0;
    if (!strip_last_component(search_dir)) return 0;

    for (level = 0; level < 6; ++level) {
        if (!copy_text(candidate_path, PATH_CAPACITY, search_dir)) return 0;
        if (!append_text(candidate_path, PATH_CAPACITY, "\\uploads")) return 0;
        attributes = GetFileAttributesA(candidate_path);
        if (attributes != INVALID_FILE_ATTRIBUTES && (attributes & FILE_ATTRIBUTE_DIRECTORY)) {
            if (!copy_text(output_path, PATH_CAPACITY, candidate_path)) return 0;
            if (slot == 'a') return append_text(output_path, PATH_CAPACITY, "\\desktop-a.bmp");
            return append_text(output_path, PATH_CAPACITY, "\\desktop-b.bmp");
        }
        if (!strip_last_component(search_dir)) break;
    }
    return 0;
}

static BOOL write_all(HANDLE file, const BYTE *buffer, DWORD size) {
    DWORD offset = 0;
    while (offset < size) {
        DWORD part = 0;
        if (!WriteFile(file, buffer + offset, size - offset, &part, NULL)) return 0;
        if (part == 0) return 0;
        offset += part;
    }
    return 1;
}

void start(void) {
    char slot;
    int source_width, source_height, target_width, target_height;
    DWORD row_bytes, image_size;
    HDC screen_dc = NULL;
    HDC memory_dc = NULL;
    HBITMAP bitmap = NULL;
    HGDIOBJ old_object = NULL;
    BYTE *pixels = NULL;
    HANDLE file = INVALID_HANDLE_VALUE;
    int lines;

    slot = read_slot();
    if (!slot) ExitProcess(2);
    if (!locate_output_path(slot)) ExitProcess(14);

    source_width = GetSystemMetrics(SM_CXSCREEN);
    source_height = GetSystemMetrics(SM_CYSCREEN);
    if (source_width <= 0 || source_height <= 0) ExitProcess(3);

    target_width = source_width;
    target_height = source_height;
    if (target_width > 1280) {
        target_height = (source_height * 1280) / source_width;
        target_width = 1280;
    }
    if (target_height > 800) {
        target_width = (target_width * 800) / target_height;
        target_height = 800;
    }
    if (target_width <= 0 || target_height <= 0) ExitProcess(4);

    row_bytes = (((DWORD)target_width * 3UL) + 3UL) & ~3UL;
    image_size = row_bytes * (DWORD)target_height;
    if (image_size == 0 || image_size > 64UL * 1024UL * 1024UL) ExitProcess(5);

    screen_dc = GetDC(NULL);
    if (!screen_dc) ExitProcess(6);
    memory_dc = CreateCompatibleDC(screen_dc);
    if (!memory_dc) {
        ReleaseDC(NULL, screen_dc);
        ExitProcess(7);
    }
    bitmap = CreateCompatibleBitmap(screen_dc, target_width, target_height);
    if (!bitmap) {
        DeleteDC(memory_dc);
        ReleaseDC(NULL, screen_dc);
        ExitProcess(8);
    }

    old_object = SelectObject(memory_dc, (HGDIOBJ)bitmap);
    SetStretchBltMode(memory_dc, HALFTONE);
    if (!StretchBlt(memory_dc, 0, 0, target_width, target_height,
                    screen_dc, 0, 0, source_width, source_height,
                    SRCCOPY | CAPTUREBLT)) {
        if (old_object) SelectObject(memory_dc, old_object);
        DeleteObject((HGDIOBJ)bitmap);
        DeleteDC(memory_dc);
        ReleaseDC(NULL, screen_dc);
        ExitProcess(9);
    }
    if (old_object) SelectObject(memory_dc, old_object);

    bitmap_info.bmiHeader.biSize = (DWORD)sizeof(BITMAPINFOHEADER);
    bitmap_info.bmiHeader.biWidth = target_width;
    bitmap_info.bmiHeader.biHeight = target_height;
    bitmap_info.bmiHeader.biPlanes = 1;
    bitmap_info.bmiHeader.biBitCount = 24;
    bitmap_info.bmiHeader.biCompression = BI_RGB;
    bitmap_info.bmiHeader.biSizeImage = image_size;
    bitmap_info.bmiHeader.biXPelsPerMeter = 0;
    bitmap_info.bmiHeader.biYPelsPerMeter = 0;
    bitmap_info.bmiHeader.biClrUsed = 0;
    bitmap_info.bmiHeader.biClrImportant = 0;

    pixels = (BYTE *)VirtualAlloc(NULL, image_size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!pixels) {
        DeleteObject((HGDIOBJ)bitmap);
        DeleteDC(memory_dc);
        ReleaseDC(NULL, screen_dc);
        ExitProcess(10);
    }

    lines = GetDIBits(memory_dc, bitmap, 0, (UINT)target_height, pixels, &bitmap_info, DIB_RGB_COLORS);
    if (lines != target_height) {
        DeleteObject((HGDIOBJ)bitmap);
        DeleteDC(memory_dc);
        ReleaseDC(NULL, screen_dc);
        ExitProcess(11);
    }

    file_header.bfType = 0x4D42;
    file_header.bfSize = (DWORD)sizeof(BITMAPFILEHEADER) + (DWORD)sizeof(BITMAPINFOHEADER) + image_size;
    file_header.bfReserved1 = 0;
    file_header.bfReserved2 = 0;
    file_header.bfOffBits = (DWORD)sizeof(BITMAPFILEHEADER) + (DWORD)sizeof(BITMAPINFOHEADER);

    file = CreateFileA(output_path, GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (file == INVALID_HANDLE_VALUE) {
        DeleteObject((HGDIOBJ)bitmap);
        DeleteDC(memory_dc);
        ReleaseDC(NULL, screen_dc);
        ExitProcess(12);
    }

    if (!write_all(file, (const BYTE *)&file_header, (DWORD)sizeof(file_header)) ||
        !write_all(file, (const BYTE *)&bitmap_info.bmiHeader, (DWORD)sizeof(BITMAPINFOHEADER)) ||
        !write_all(file, pixels, image_size)) {
        CloseHandle(file);
        DeleteObject((HGDIOBJ)bitmap);
        DeleteDC(memory_dc);
        ReleaseDC(NULL, screen_dc);
        ExitProcess(13);
    }

    CloseHandle(file);
    DeleteObject((HGDIOBJ)bitmap);
    DeleteDC(memory_dc);
    ReleaseDC(NULL, screen_dc);
    ExitProcess(0);
}
