@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "HTPASSWD=%~dp0..\..\apache\bin\htpasswd.exe"
if not exist "%HTPASSWD%" set "HTPASSWD=C:\xampp\apache\bin\htpasswd.exe"

if not exist "%HTPASSWD%" (
  echo ERROR: htpasswd.exe was not found.
  echo Expected location: C:\xampp\apache\bin\htpasswd.exe
  pause
  exit /b 1
)

set "AUTH_USER=admin"
set /p "AUTH_USER=Username [admin]: "
if "%AUTH_USER%"=="" set "AUTH_USER=admin"

 echo.
echo Choose a strong password. It will be requested twice.
"%HTPASSWD%" -c "%CD%\.htpasswd" "%AUTH_USER%"
if errorlevel 1 (
  echo Password setup failed.
  pause
  exit /b 1
)

set "AUTH_FILE=%CD%\.htpasswd"
set "AUTH_FILE=%AUTH_FILE:\=/%"

> "%CD%\.htaccess" echo Options -Indexes
>>"%CD%\.htaccess" echo AuthType Basic
>>"%CD%\.htaccess" echo AuthName "ApacheBAS Remote Desktop"
>>"%CD%\.htaccess" echo AuthUserFile "%AUTH_FILE%"
>>"%CD%\.htaccess" echo Require valid-user
>>"%CD%\.htaccess" echo.
>>"%CD%\.htaccess" echo ^<FilesMatch "^^\."^>
>>"%CD%\.htaccess" echo     Require all denied
>>"%CD%\.htaccess" echo ^</FilesMatch^>

echo.
echo Remote access protection has been enabled.
echo Open: http://SERVER-IP/remote-admin/remote-admin.bas
echo Use HTTPS before exposing this page outside a trusted LAN.
echo If Apache ignores .htaccess, enable AllowOverride AuthConfig or AllowOverride All.
pause
