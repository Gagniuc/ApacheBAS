Screenshots are generated here at runtime.
