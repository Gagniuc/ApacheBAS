<?bas
IF GET_API$ = "1" THEN GOTO API_MODE
GOTO PAGE_MODE

API_MODE:
PRINT "@@CONTENT-TYPE text/plain; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
EXEC "tasklist.exe"
IF EXEC_OK = 0 THEN GOTO API_ERROR
PRINT EXEC_OUTPUT$
END

API_ERROR:
PRINT "ERROR|"; EXEC_ERROR$
END

PAGE_MODE:
PRINT "@@CONTENT-TYPE text/html; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ApacheBAS Task Manager</title>
<style>
:root{color-scheme:dark;--bg:#050b08;--panel:#09140e;--panel2:#0d1d14;--line:#1c5f3d;--accent:#68f5a5;--text:#effff6;--muted:#9bc8ae;--danger:#ff8383}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Consolas,"Courier New",monospace}.app{min-height:100vh;display:grid;grid-template-rows:auto auto 1fr auto}.top{display:flex;align-items:center;gap:14px;padding:14px 18px;border-bottom:1px solid var(--line);background:#030705}.lights{display:flex;gap:7px}.lights i{width:11px;height:11px;border:1px solid var(--line);border-radius:50%;display:block}.title{font-weight:700;letter-spacing:.08em}.tag{font-size:11px;color:var(--accent);border:1px solid var(--line);padding:4px 8px;border-radius:20px}.toolbar{display:grid;grid-template-columns:1fr auto auto;gap:10px;padding:12px 18px;border-bottom:1px solid #103722;background:var(--panel)}input,button{font:inherit;border:1px solid var(--line);background:#06100b;color:var(--text);padding:10px 12px}input:focus{outline:1px solid var(--accent)}button{cursor:pointer;color:var(--accent)}button:hover{background:#10271a}.main{padding:16px 18px;overflow:auto}.summary{display:flex;justify-content:space-between;gap:20px;margin-bottom:12px;color:var(--muted);font-size:13px}.tablewrap{border:1px solid var(--line);background:var(--panel);overflow:auto;min-height:320px}table{width:100%;border-collapse:collapse;table-layout:fixed}th,td{text-align:left;padding:9px 11px;border-bottom:1px solid #123722;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}th{position:sticky;top:0;background:#0c2015;color:var(--accent);z-index:2}tbody tr:hover{background:#10261a}.name{width:38%}.pid{width:12%}.session{width:24%}.sessionno{width:12%}.memory{width:14%;text-align:right}.empty,.error{padding:28px;color:var(--muted)}.error{color:var(--danger)}.warning{display:none;margin:0 18px 12px;padding:10px 12px;border:1px solid #7b6424;color:#ffe28a;background:#221c08}.footer{padding:10px 18px;border-top:1px solid var(--line);color:var(--muted);font-size:12px}.dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--accent);margin-right:7px}.paused{background:#d7a536}.bad{background:var(--danger)}@media(max-width:760px){.toolbar{grid-template-columns:1fr}.summary{display:block}.session,.sessionno{display:none}.name{width:55%}.pid{width:20%}.memory{width:25%}}
</style>
</head>
<body>
<div class="app">
  <header class="top"><span class="lights"><i></i><i></i><i></i></span><span class="title">APACHEBAS TASK MANAGER</span><span class="tag">READ ONLY</span></header>
  <section class="toolbar">
    <input id="filter" type="search" placeholder="Filter by process name, PID or session">
    <button id="refresh" type="button">Refresh</button>
    <button id="pause" type="button">Pause auto-refresh</button>
  </section>
  <div id="warning" class="warning">The process output reached the current EXEC_OUTPUT$ limit and may be truncated.</div>
  <main class="main">
    <div class="summary"><span><span id="statusDot" class="dot"></span><span id="status">Loading processes...</span></span><span id="updated">Not refreshed yet</span></div>
    <div class="tablewrap">
      <table>
        <thead><tr><th class="name">Image name</th><th class="pid">PID</th><th class="session">Session</th><th class="sessionno">Session #</th><th class="memory">Memory</th></tr></thead>
        <tbody id="rows"><tr><td colspan="5" class="empty">Reading the Windows process list...</td></tr></tbody>
      </table>
    </div>
  </main>
  <footer class="footer">Source: Windows tasklist.exe · refresh interval: 3 seconds · ApacheBAS v0.1.34</footer>
</div>
<script>
const rows=document.getElementById('rows');
const filter=document.getElementById('filter');
const status=document.getElementById('status');
const statusDot=document.getElementById('statusDot');
const updated=document.getElementById('updated');
const warning=document.getElementById('warning');
const pauseButton=document.getElementById('pause');
let processes=[];
let paused=false;
let busy=false;

function parseTasklist(text){
  const lines=text.replace(/\r/g,'').split('\n');
  let separator=lines.findIndex(line=>/^=+\s+=+/.test(line));
  const data=separator>=0?lines.slice(separator+1):lines;
  return data.filter(line=>line.trim()).map(line=>({
    name:line.slice(0,25).trim(),
    pid:line.slice(25,34).trim(),
    session:line.slice(34,52).trim(),
    sessionNo:line.slice(52,64).trim(),
    memory:line.slice(64).trim(),
    raw:line.trim()
  })).filter(p=>p.name && /^\d+$/.test(p.pid));
}

function esc(value){return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}

function render(){
  const q=filter.value.trim().toLowerCase();
  const list=processes.filter(p=>(p.name+' '+p.pid+' '+p.session+' '+p.sessionNo+' '+p.memory).toLowerCase().includes(q));
  if(!list.length){rows.innerHTML='<tr><td colspan="5" class="empty">No matching processes.</td></tr>';return;}
  rows.innerHTML=list.map(p=>`<tr title="${esc(p.raw)}"><td class="name">${esc(p.name)}</td><td class="pid">${esc(p.pid)}</td><td class="session">${esc(p.session)}</td><td class="sessionno">${esc(p.sessionNo)}</td><td class="memory">${esc(p.memory)}</td></tr>`).join('');
}

async function refresh(){
  if(paused||busy)return;
  busy=true;
  status.textContent='Refreshing...';
  statusDot.className='dot';
  try{
    const response=await fetch('task_manager.bas?api=1&_='+Date.now(),{cache:'no-store'});
    const text=await response.text();
    if(!response.ok)throw new Error('HTTP '+response.status);
    if(text.startsWith('ERROR|'))throw new Error(text.slice(6).trim());
    warning.style.display=text.length>=2040?'block':'none';
    processes=parseTasklist(text);
    render();
    status.textContent=processes.length+' running processes';
    updated.textContent='Updated '+new Date().toLocaleTimeString();
  }catch(error){
    rows.innerHTML='<tr><td colspan="5" class="error">'+esc(error.message)+'</td></tr>';
    status.textContent='Could not read the process list';
    statusDot.className='dot bad';
  }finally{busy=false;}
}

filter.addEventListener('input',render);
document.getElementById('refresh').addEventListener('click',refresh);
pauseButton.addEventListener('click',()=>{
  paused=!paused;
  pauseButton.textContent=paused?'Resume auto-refresh':'Pause auto-refresh';
  statusDot.className=paused?'dot paused':'dot';
  if(!paused)refresh();
});
refresh();
setInterval(refresh,3000);
</script>
</body>
</html>
