ApacheBAS Picture Repositories v1.5 - clean source
==================================================

Copy these two folders directly into any directory below C:\xampp\htdocs:

  apachebas-picture-account
  apachebas-picture-simple

There are no CMD files, installers, auxiliary EXE files or EXEC statements.

Account repository v1.5:
- account creation and login use ordinary server-side HTML POST forms;
- no JavaScript is required for login;
- successful login renders the repository directly;
- a short demonstration session token is then kept in the page URL so upload,
  delete and refresh continue to work regardless of the installation folder;
- JavaScript is used only where necessary for raw binary upload and deletion.

When updating an existing installation, preserve its data and uploads folders.
Replace index.bas and the includes folder only.
