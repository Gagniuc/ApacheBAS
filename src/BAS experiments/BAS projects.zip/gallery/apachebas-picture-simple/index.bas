ACTION$ = LCASE$(TRIM$(GET_ACTION$))
IF ACTION$ = "upload" OR ACTION$ = "delete" THEN PRINT "@@CONTENT-TYPE text/plain; charset=utf-8"
IF ACTION$ <> "upload" AND ACTION$ <> "delete" THEN PRINT "@@CONTENT-TYPE text/html; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"

COUNT_TEXT$ = READFILE$("data/count.txt")
PHOTO_COUNT = VAL(COUNT_TEXT$)

IF ACTION$ <> "delete" THEN GOTO simple_delete_done
DELETE_ID_TEXT$ = TRIM$(GET_ID$)
DELETE_ID_OK = 1
IF LEN(DELETE_ID_TEXT$) < 1 THEN DELETE_ID_OK = 0
IF LEN(DELETE_ID_TEXT$) > 6 THEN DELETE_ID_OK = 0
FOR J = 1 TO LEN(DELETE_ID_TEXT$)
C = ASC(MID$(DELETE_ID_TEXT$, J, 1))
IF (C < 48 OR C > 57) THEN DELETE_ID_OK = 0
NEXT J
DELETE_ID = VAL(DELETE_ID_TEXT$)
IF (DELETE_ID_OK = 0 OR DELETE_ID < 1 OR DELETE_ID > PHOTO_COUNT) THEN PRINT "ERROR: Invalid picture identifier."
IF (DELETE_ID_OK = 0 OR DELETE_ID < 1 OR DELETE_ID > PHOTO_COUNT) THEN END
CARD_FILE$ = "data/photo-" + HEX$(DELETE_ID) + ".txt"
CARD_HTML$ = READFILE$(CARD_FILE$)
IF CARD_HTML$ = "__DELETED__" THEN PRINT "ERROR: Picture is already deleted."
IF CARD_HTML$ = "__DELETED__" THEN END
EXT_FILE$ = "data/photo-" + HEX$(DELETE_ID) + "-ext.txt"
PHOTO_EXT$ = LCASE$(TRIM$(READFILE$(EXT_FILE$)))
EXT_OK = 0
IF PHOTO_EXT$ = ".png" THEN EXT_OK = 1
IF PHOTO_EXT$ = ".jpg" THEN EXT_OK = 1
IF PHOTO_EXT$ = ".jpeg" THEN EXT_OK = 1
IF PHOTO_EXT$ = ".gif" THEN EXT_OK = 1
IF PHOTO_EXT$ = ".webp" THEN EXT_OK = 1
IF EXT_OK = 0 THEN PRINT "ERROR: Picture metadata is incomplete."
IF EXT_OK = 0 THEN END
TARGET_NAME$ = "public-" + HEX$(DELETE_ID) + PHOTO_EXT$
SAVEUPLOAD TARGET_NAME$
IF UPLOAD_OK = 0 THEN PRINT "ERROR: The image content could not be erased: "; UPLOAD_ERROR$
IF UPLOAD_OK = 0 THEN END
WRITEFILE CARD_FILE$, "__DELETED__"
CARD_DELETED = FILE_OK
DELETE_ERROR$ = FILE_ERROR$
IF CARD_DELETED THEN WRITEFILE EXT_FILE$, "__DELETED__"
EXT_DELETED = FILE_OK
IF CARD_DELETED = 0 THEN PRINT "ERROR: Gallery metadata could not be updated: "; DELETE_ERROR$
IF CARD_DELETED = 0 THEN END
IF EXT_DELETED = 0 THEN PRINT "ERROR: Picture was removed, but extension metadata could not be updated: "; FILE_ERROR$
IF EXT_DELETED = 0 THEN END
PRINT "OK"
END
simple_delete_done:
IF ACTION$ <> "upload" THEN GOTO simple_upload_done
LOWER_FILE$ = LCASE$(TRIM$(GET_FILENAME$))
EXT$ = ""
IF RIGHT$(LOWER_FILE$, 5) = ".jpeg" THEN EXT$ = ".jpeg"
IF EXT$ = "" AND RIGHT$(LOWER_FILE$, 4) = ".jpg" THEN EXT$ = ".jpg"
IF EXT$ = "" AND RIGHT$(LOWER_FILE$, 4) = ".png" THEN EXT$ = ".png"
IF EXT$ = "" AND RIGHT$(LOWER_FILE$, 4) = ".gif" THEN EXT$ = ".gif"
IF EXT$ = "" AND RIGHT$(LOWER_FILE$, 5) = ".webp" THEN EXT$ = ".webp"
IF EXT$ = "" THEN PRINT "ERROR: Select a PNG, JPEG, GIF or WebP image."
IF EXT$ = "" THEN END
ACTIVE_COUNT = 0
NEW_ID = 0
FOR J = 1 TO PHOTO_COUNT
CARD_FILE$ = "data/photo-" + HEX$(J) + ".txt"
CARD_HTML$ = READFILE$(CARD_FILE$)
IF CARD_HTML$ <> "__DELETED__" THEN ACTIVE_COUNT = ACTIVE_COUNT + 1
IF CARD_HTML$ = "__DELETED__" AND NEW_ID = 0 THEN NEW_ID = J
NEXT J
IF ACTIVE_COUNT >= 500 THEN PRINT "ERROR: The public demonstration limit of 500 active pictures was reached."
IF ACTIVE_COUNT >= 500 THEN END
IF NEW_ID = 0 THEN NEW_ID = PHOTO_COUNT + 1
TARGET_NAME$ = "public-" + HEX$(NEW_ID) + EXT$
SAVEUPLOAD TARGET_NAME$
IF UPLOAD_OK = 0 THEN PRINT "ERROR: "; UPLOAD_ERROR$
IF UPLOAD_OK = 0 THEN END
TITLE$ = LEFT$(TRIM$(GET_TITLE$), 120)
IF TITLE$ = "" THEN TITLE$ = "Untitled picture"
STAMP$ = DATE$ + " " + TIME$
CARD$ = "<article class=""photo-card""><a href=""" + HTML$(UPLOAD_URL$) + """ target=""_blank""><img src=""" + HTML$(UPLOAD_URL$) + """ alt=""" + HTML$(TITLE$) + """ loading=""lazy""></a><div class=""photo-info""><strong>" + HTML$(TITLE$) + "</strong><span>" + HTML$(STAMP$) + "</span></div></article>"
CARD_FILE$ = "data/photo-" + HEX$(NEW_ID) + ".txt"
EXT_FILE$ = "data/photo-" + HEX$(NEW_ID) + "-ext.txt"
WRITEFILE CARD_FILE$, CARD$
CARD_SAVED = FILE_OK
CARD_ERROR$ = FILE_ERROR$
WRITEFILE EXT_FILE$, EXT$
EXT_SAVED = FILE_OK
EXT_ERROR$ = FILE_ERROR$
IF CARD_SAVED AND EXT_SAVED AND NEW_ID > PHOTO_COUNT THEN WRITEFILE "data/count.txt", STR$(NEW_ID)
IF CARD_SAVED AND EXT_SAVED AND NEW_ID <= PHOTO_COUNT THEN FILE_OK = 1
IF CARD_SAVED AND EXT_SAVED AND FILE_OK THEN PRINT "OK:"; NEW_ID
IF CARD_SAVED AND EXT_SAVED AND FILE_OK THEN END
IF CARD_SAVED AND EXT_SAVED AND FILE_OK = 0 THEN PRINT "ERROR: Picture saved, but the counter could not be updated: "; FILE_ERROR$
IF CARD_SAVED AND EXT_SAVED AND FILE_OK = 0 THEN END
IF CARD_SAVED = 0 THEN PRINT "ERROR: Picture uploaded, but gallery metadata could not be saved: "; CARD_ERROR$
IF CARD_SAVED = 0 THEN END
IF EXT_SAVED = 0 THEN PRINT "ERROR: Picture uploaded, but extension metadata could not be saved: "; EXT_ERROR$
IF EXT_SAVED = 0 THEN END
simple_upload_done:
ACTIVE_COUNT = 0
FOR I = 1 TO PHOTO_COUNT
    CARD_FILE$ = "data/photo-" + HEX$(I) + ".txt"
    CARD_HTML$ = READFILE$(CARD_FILE$)
    IF CARD_HTML$ <> "__DELETED__" THEN ACTIVE_COUNT = ACTIVE_COUNT + 1
NEXT I
INCLUDE("includes/gallery.inc")
