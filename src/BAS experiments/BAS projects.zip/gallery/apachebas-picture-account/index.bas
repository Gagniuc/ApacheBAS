ACTION$ = LCASE$(TRIM$(GET_ACTION$))
API_ACTION = 0
IF ACTION$ = "upload" OR ACTION$ = "delete" THEN API_ACTION = 1
IF API_ACTION THEN PRINT "@@CONTENT-TYPE text/plain; charset=utf-8"
IF API_ACTION = 0 THEN PRINT "@@CONTENT-TYPE text/html; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"

USERS$ = READFILE$("data/users.txt")

' Authentication is deliberately independent of cookies.
' The normal login form uses POST. Gallery requests use a short session token in GET.
AUTH_USER$ = LCASE$(TRIM$(GET_U$))
AUTH_KEY$ = TRIM$(GET_K$)
AUTH_INPUT_OK = 1
IF LEN(AUTH_USER$) < 3 OR LEN(AUTH_USER$) > 20 THEN AUTH_INPUT_OK = 0
FOR I = 1 TO LEN(AUTH_USER$)
    C = ASC(MID$(AUTH_USER$, I, 1))
    CHAR_OK = 0
    IF C >= 48 AND C <= 57 THEN CHAR_OK = 1
    IF C >= 97 AND C <= 122 THEN CHAR_OK = 1
    IF C = 95 THEN CHAR_OK = 1
    IF CHAR_OK = 0 THEN AUTH_INPUT_OK = 0
NEXT I
IF LEN(AUTH_KEY$) < 2 OR LEN(AUTH_KEY$) > 32 THEN AUTH_INPUT_OK = 0
FOR I = 1 TO LEN(AUTH_KEY$)
    C = ASC(UCASE$(MID$(AUTH_KEY$, I, 1)))
    CHAR_OK = 0
    IF C >= 48 AND C <= 57 THEN CHAR_OK = 1
    IF C >= 65 AND C <= 70 THEN CHAR_OK = 1
    IF CHAR_OK = 0 THEN AUTH_INPUT_OK = 0
NEXT I
AUTH = 0
AUTH_MARKER$ = "|" + AUTH_USER$ + "|" + AUTH_KEY$ + "|"
IF AUTH_INPUT_OK AND INSTR(USERS$, AUTH_MARKER$) > 0 THEN AUTH = 1

' Normal server-side registration and login. No JavaScript is involved.
MODE$ = LCASE$(TRIM$(POST_MODE$))
FORM_USER$ = LCASE$(TRIM$(POST_USERNAME$))
PASSWORD$ = POST_PASSWORD$
ERROR_MESSAGE$ = ""
CREDENTIAL_REQUEST = 0
IF MODE$ = "register" OR MODE$ = "login" THEN CREDENTIAL_REQUEST = 1
VALID_USER = 1
IF LEN(FORM_USER$) < 3 OR LEN(FORM_USER$) > 20 THEN VALID_USER = 0
FOR I = 1 TO LEN(FORM_USER$)
    C = ASC(MID$(FORM_USER$, I, 1))
    CHAR_OK = 0
    IF C >= 48 AND C <= 57 THEN CHAR_OK = 1
    IF C >= 97 AND C <= 122 THEN CHAR_OK = 1
    IF C = 95 THEN CHAR_OK = 1
    IF CHAR_OK = 0 THEN VALID_USER = 0
NEXT I
IF CREDENTIAL_REQUEST AND VALID_USER = 0 THEN ERROR_MESSAGE$ = "Username: 3-20 characters; use only a-z, 0-9 and underscore."
IF CREDENTIAL_REQUEST AND (LEN(PASSWORD$) < 6 OR LEN(PASSWORD$) > 40) THEN ERROR_MESSAGE$ = "Password length must be between 6 and 40 characters."

HASH_SOURCE$ = FORM_USER$ + ":" + PASSWORD$
HASH1 = 17
HASH2 = 23
FOR I = 1 TO LEN(HASH_SOURCE$)
    C = ASC(MID$(HASH_SOURCE$, I, 1))
    HASH1 = (HASH1 * 31 + C) MOD 1000003
    HASH2 = (HASH2 * 37 + C + I) MOD 1000033
NEXT I
LOGIN_KEY$ = HEX$(HASH1) + HEX$(HASH2)
LOGIN_MARKER$ = "|" + FORM_USER$ + "|" + LOGIN_KEY$ + "|"
USER_MARKER$ = "|" + FORM_USER$ + "|"

IF MODE$ = "register" AND ERROR_MESSAGE$ = "" AND INSTR(USERS$, USER_MARKER$) > 0 THEN ERROR_MESSAGE$ = "This username already exists."
IF MODE$ = "register" AND ERROR_MESSAGE$ = "" AND LEN(USERS$) > 1800 THEN ERROR_MESSAGE$ = "The demonstration account database is full."
REGISTER_OK = 0
COUNT_FILE$ = "data/u-" + FORM_USER$ + "-count.txt"
IF MODE$ = "register" AND ERROR_MESSAGE$ = "" THEN WRITEFILE COUNT_FILE$, "0"
IF MODE$ = "register" AND ERROR_MESSAGE$ = "" THEN COUNT_CREATED = FILE_OK
IF MODE$ = "register" AND ERROR_MESSAGE$ = "" AND COUNT_CREATED = 0 THEN ERROR_MESSAGE$ = "Could not initialize the account repository: " + FILE_ERROR$
IF MODE$ = "register" AND ERROR_MESSAGE$ = "" THEN APPENDFILE "data/users.txt", CHR$(13) + CHR$(10) + LOGIN_MARKER$
IF MODE$ = "register" AND ERROR_MESSAGE$ = "" THEN REGISTER_OK = FILE_OK
IF MODE$ = "register" AND ERROR_MESSAGE$ = "" AND REGISTER_OK = 0 THEN ERROR_MESSAGE$ = "Could not save the account: " + FILE_ERROR$
IF MODE$ = "register" AND REGISTER_OK THEN AUTH = 1
IF MODE$ = "register" AND REGISTER_OK THEN AUTH_USER$ = FORM_USER$
IF MODE$ = "register" AND REGISTER_OK THEN AUTH_KEY$ = LOGIN_KEY$

LOGIN_OK = 0
IF MODE$ = "login" AND ERROR_MESSAGE$ = "" AND INSTR(USERS$, LOGIN_MARKER$) > 0 THEN LOGIN_OK = 1
IF MODE$ = "login" AND ERROR_MESSAGE$ = "" AND LOGIN_OK = 0 THEN ERROR_MESSAGE$ = "Incorrect username or password."
IF MODE$ = "login" AND LOGIN_OK THEN AUTH = 1
IF MODE$ = "login" AND LOGIN_OK THEN AUTH_USER$ = FORM_USER$
IF MODE$ = "login" AND LOGIN_OK THEN AUTH_KEY$ = LOGIN_KEY$

IF ACTION$ = "upload" AND AUTH = 0 THEN PRINT "ERROR: Authentication required."
IF ACTION$ = "upload" AND AUTH = 0 THEN END
IF ACTION$ = "delete" AND AUTH = 0 THEN PRINT "ERROR: Authentication required."
IF ACTION$ = "delete" AND AUTH = 0 THEN END

IF ACTION$ <> "delete" THEN GOTO account_delete_done
USER_COUNT_FILE$ = "data/u-" + AUTH_USER$ + "-count.txt"
COUNT_TEXT$ = READFILE$(USER_COUNT_FILE$)
PHOTO_COUNT = VAL(COUNT_TEXT$)
DELETE_ID_TEXT$ = TRIM$(GET_ID$)
DELETE_ID_OK = 1
IF LEN(DELETE_ID_TEXT$) < 1 THEN DELETE_ID_OK = 0
IF LEN(DELETE_ID_TEXT$) > 6 THEN DELETE_ID_OK = 0
FOR J = 1 TO LEN(DELETE_ID_TEXT$)
    C = ASC(MID$(DELETE_ID_TEXT$, J, 1))
    IF (C < 48 OR C > 57) THEN DELETE_ID_OK = 0
NEXT J
DELETE_ID = VAL(DELETE_ID_TEXT$)
IF (DELETE_ID_OK = 0 OR DELETE_ID < 1 OR DELETE_ID > PHOTO_COUNT) THEN PRINT "ERROR: Invalid picture identifier."
IF (DELETE_ID_OK = 0 OR DELETE_ID < 1 OR DELETE_ID > PHOTO_COUNT) THEN END
CARD_FILE$ = "data/u-" + AUTH_USER$ + "-photo-" + HEX$(DELETE_ID) + ".txt"
CARD_HTML$ = READFILE$(CARD_FILE$)
IF CARD_HTML$ = "__DELETED__" THEN PRINT "ERROR: Picture is already deleted."
IF CARD_HTML$ = "__DELETED__" THEN END
EXT_FILE$ = "data/u-" + AUTH_USER$ + "-photo-" + HEX$(DELETE_ID) + "-ext.txt"
PHOTO_EXT$ = LCASE$(TRIM$(READFILE$(EXT_FILE$)))
EXT_OK = 0
IF PHOTO_EXT$ = ".png" THEN EXT_OK = 1
IF PHOTO_EXT$ = ".jpg" THEN EXT_OK = 1
IF PHOTO_EXT$ = ".jpeg" THEN EXT_OK = 1
IF PHOTO_EXT$ = ".gif" THEN EXT_OK = 1
IF PHOTO_EXT$ = ".webp" THEN EXT_OK = 1
IF EXT_OK = 0 THEN PRINT "ERROR: Picture metadata is incomplete."
IF EXT_OK = 0 THEN END
TARGET_NAME$ = AUTH_USER$ + "-" + HEX$(DELETE_ID) + PHOTO_EXT$
SAVEUPLOAD TARGET_NAME$
IF UPLOAD_OK = 0 THEN PRINT "ERROR: The image content could not be erased: "; UPLOAD_ERROR$
IF UPLOAD_OK = 0 THEN END
WRITEFILE CARD_FILE$, "__DELETED__"
CARD_DELETED = FILE_OK
DELETE_ERROR$ = FILE_ERROR$
IF CARD_DELETED THEN WRITEFILE EXT_FILE$, "__DELETED__"
EXT_DELETED = FILE_OK
IF CARD_DELETED = 0 THEN PRINT "ERROR: Gallery metadata could not be updated: "; DELETE_ERROR$
IF CARD_DELETED = 0 THEN END
IF EXT_DELETED = 0 THEN PRINT "ERROR: Picture was removed, but extension metadata could not be updated: "; FILE_ERROR$
IF EXT_DELETED = 0 THEN END
PRINT "OK"
END
account_delete_done:

IF ACTION$ <> "upload" THEN GOTO account_upload_done
LOWER_FILE$ = LCASE$(TRIM$(GET_FILENAME$))
EXT$ = ""
IF RIGHT$(LOWER_FILE$, 5) = ".jpeg" THEN EXT$ = ".jpeg"
IF EXT$ = "" AND RIGHT$(LOWER_FILE$, 4) = ".jpg" THEN EXT$ = ".jpg"
IF EXT$ = "" AND RIGHT$(LOWER_FILE$, 4) = ".png" THEN EXT$ = ".png"
IF EXT$ = "" AND RIGHT$(LOWER_FILE$, 4) = ".gif" THEN EXT$ = ".gif"
IF EXT$ = "" AND RIGHT$(LOWER_FILE$, 5) = ".webp" THEN EXT$ = ".webp"
IF EXT$ = "" THEN PRINT "ERROR: Select a PNG, JPEG, GIF or WebP image."
IF EXT$ = "" THEN END
USER_COUNT_FILE$ = "data/u-" + AUTH_USER$ + "-count.txt"
COUNT_TEXT$ = READFILE$(USER_COUNT_FILE$)
PHOTO_COUNT = VAL(COUNT_TEXT$)
ACTIVE_COUNT = 0
NEW_ID = 0
FOR J = 1 TO PHOTO_COUNT
    CARD_FILE$ = "data/u-" + AUTH_USER$ + "-photo-" + HEX$(J) + ".txt"
    CARD_HTML$ = READFILE$(CARD_FILE$)
    IF CARD_HTML$ <> "__DELETED__" THEN ACTIVE_COUNT = ACTIVE_COUNT + 1
    IF CARD_HTML$ = "__DELETED__" AND NEW_ID = 0 THEN NEW_ID = J
NEXT J
IF ACTIVE_COUNT >= 200 THEN PRINT "ERROR: The demonstration limit is 200 active pictures per account."
IF ACTIVE_COUNT >= 200 THEN END
IF NEW_ID = 0 THEN NEW_ID = PHOTO_COUNT + 1
TARGET_NAME$ = AUTH_USER$ + "-" + HEX$(NEW_ID) + EXT$
SAVEUPLOAD TARGET_NAME$
IF UPLOAD_OK = 0 THEN PRINT "ERROR: "; UPLOAD_ERROR$
IF UPLOAD_OK = 0 THEN END
CAPTION$ = LEFT$(TRIM$(GET_CAPTION$), 120)
IF CAPTION$ = "" THEN CAPTION$ = "Untitled picture"
STAMP$ = DATE$ + " " + TIME$
CARD$ = "<article class=""photo-card""><a href=""" + HTML$(UPLOAD_URL$) + """ target=""_blank""><img src=""" + HTML$(UPLOAD_URL$) + """ alt=""" + HTML$(CAPTION$) + """ loading=""lazy""></a><div class=""photo-info""><strong>" + HTML$(CAPTION$) + "</strong><span>" + HTML$(STAMP$) + "</span></div></article>"
CARD_FILE$ = "data/u-" + AUTH_USER$ + "-photo-" + HEX$(NEW_ID) + ".txt"
EXT_FILE$ = "data/u-" + AUTH_USER$ + "-photo-" + HEX$(NEW_ID) + "-ext.txt"
WRITEFILE CARD_FILE$, CARD$
CARD_SAVED = FILE_OK
CARD_ERROR$ = FILE_ERROR$
WRITEFILE EXT_FILE$, EXT$
EXT_SAVED = FILE_OK
EXT_ERROR$ = FILE_ERROR$
IF CARD_SAVED AND EXT_SAVED AND NEW_ID > PHOTO_COUNT THEN WRITEFILE USER_COUNT_FILE$, STR$(NEW_ID)
IF CARD_SAVED AND EXT_SAVED AND NEW_ID <= PHOTO_COUNT THEN FILE_OK = 1
IF CARD_SAVED AND EXT_SAVED AND FILE_OK THEN PRINT "OK:"; NEW_ID
IF CARD_SAVED AND EXT_SAVED AND FILE_OK THEN END
IF CARD_SAVED AND EXT_SAVED AND FILE_OK = 0 THEN PRINT "ERROR: Picture saved, but the counter could not be updated: "; FILE_ERROR$
IF CARD_SAVED AND EXT_SAVED AND FILE_OK = 0 THEN END
IF CARD_SAVED = 0 THEN PRINT "ERROR: Picture uploaded, but gallery metadata could not be saved: "; CARD_ERROR$
IF CARD_SAVED = 0 THEN END
IF EXT_SAVED = 0 THEN PRINT "ERROR: Picture uploaded, but extension metadata could not be saved: "; EXT_ERROR$
IF EXT_SAVED = 0 THEN END
account_upload_done:

IF AUTH = 0 THEN INCLUDE("includes/guest.inc")
IF AUTH = 0 THEN END

USER_COUNT_FILE$ = "data/u-" + AUTH_USER$ + "-count.txt"
COUNT_TEXT$ = READFILE$(USER_COUNT_FILE$)
PHOTO_COUNT = VAL(COUNT_TEXT$)
ACTIVE_COUNT = 0
FOR I = 1 TO PHOTO_COUNT
    CARD_FILE$ = "data/u-" + AUTH_USER$ + "-photo-" + HEX$(I) + ".txt"
    CARD_HTML$ = READFILE$(CARD_FILE$)
    IF CARD_HTML$ <> "__DELETED__" THEN ACTIVE_COUNT = ACTIVE_COUNT + 1
NEXT I
INCLUDE("includes/repository.inc")
