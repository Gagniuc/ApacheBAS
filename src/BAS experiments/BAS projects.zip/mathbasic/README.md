# MathBASIC Studio 1.0.3

A server-side mathematical drawing laboratory for ApacheBAS.

## Install

Copy the `mathbasic` folder to:

```text
C:\xampp\htdocs\mathbasic\
```

Open:

```text
http://localhost/mathbasic/mathbasic.bas
```

## Included systems

- Mandelbrot set
- Julia set
- Burning Ship fractal
- Sierpinski chaos game
- Lissajous curves
- Polar roses
- Hypotrochoid / spirograph curves
- Phyllotaxis
- Lorenz attractor
- Wave interference fields

All mathematical coordinates are calculated by `mathbasic.bas` on the server and returned as SVG. JavaScript is used only for controls, preview refresh, presets and SVG download. No helper executable, database or write permission is required.

Designed for ApacheBAS-ASM v0.1.33.3 or newer.

## 1.0.3 correction

The remaining hypotrochoid error came from this intermediate calculation:

```basic
STEPDEG = ROTS * 360 / N
```

`ROTS` is supplied by `VAL()` and is evaluated through ApacheBAS decimal arithmetic. With the default value 13, the intermediate product `13 * 360 = 4680` exceeded the approximately ±2147 fixed-point range before division occurred. Version 1.0.3 evaluates the bounded fraction first:

```basic
STEPDEG = (ROTS / N) * 360
```

The mathematical result is unchanged, but every decimal intermediate remains within range. The Lissajous, polar rose, phyllotaxis and wave-interference corrections from versions 1.0.1–1.0.2 are retained.
