IF GET_RENDER$ = "1" THEN GOTO RENDER_MODE
PRINT "@@CONTENT-TYPE text/html; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
PRINT "@@HEADER X-Content-Type-Options: nosniff"
PRINT "<!doctype html>"
PRINT "<html lang=""en"">"
PRINT "<head>"
PRINT "<meta charset=""utf-8"">"
PRINT "<meta name=""viewport"" content=""width=device-width,initial-scale=1"">"
PRINT "<title>MathBASIC Studio 1.0.3</title>"
PRINT "<style>"
PRINT "*{box-sizing:border-box}"
PRINT ":root{--bg:#070a14;--panel:#10172a;--panel2:#151f37;--line:#263653;--text:#edf4ff;--muted:#93a5c3;--cyan:#65e8ff;--pink:#ff6bd6;--gold:#ffd166}"
PRINT "body{margin:0;background:radial-gradient(circle at 80% 0,#18234a 0,transparent 32%),linear-gradient(145deg,#070a14,#0b1020 58%,#080b15);color:var(--text);font-family:Inter,Segoe UI,Arial,sans-serif;min-height:100vh}"
PRINT "header{height:68px;border-bottom:1px solid var(--line);background:#080d19dd;backdrop-filter:blur(14px);display:flex;align-items:center;justify-content:space-between;padding:0 28px;position:sticky;top:0;z-index:10}"
PRINT ".brand{display:flex;align-items:center;gap:12px;font-weight:850;font-size:21px}.mark{width:40px;height:40px;border-radius:12px;background:linear-gradient(135deg,var(--cyan),var(--pink));color:#06101b;display:grid;place-items:center;font:900 21px Georgia;box-shadow:0 0 30px #65e8ff44}.tag{font-size:12px;color:var(--muted)}"
PRINT "main{max-width:1500px;margin:auto;padding:24px;display:grid;grid-template-columns:330px minmax(0,1fr);gap:20px}.panel{background:#10172ae8;border:1px solid var(--line);border-radius:18px;box-shadow:0 22px 70px #0007}.controls{padding:20px;align-self:start;position:sticky;top:92px}.controls h1{font-size:24px;margin:0 0 8px}.controls>p{color:var(--muted);line-height:1.55;margin:0 0 18px}.field{margin:13px 0}.field label{display:flex;justify-content:space-between;font-size:12px;font-weight:750;color:#c9d8f2;margin-bottom:7px}.field small{color:var(--muted);font-weight:500}.field input,.field select{width:100%;height:42px;border:1px solid var(--line);border-radius:10px;background:#0a1020;color:var(--text);padding:0 11px;font:inherit;outline:none}.field input:focus,.field select:focus{border-color:var(--cyan);box-shadow:0 0 0 3px #65e8ff1c}.row{display:grid;grid-template-columns:1fr 1fr;gap:10px}.buttons{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:17px}.btn{height:42px;border:1px solid var(--line);border-radius:10px;background:#17233d;color:var(--text);font-weight:800;cursor:pointer}.btn.primary{background:linear-gradient(135deg,#26b8ef,#8a6cff);border:0}.btn:hover{filter:brightness(1.12)}.btn.wide{grid-column:1/-1}.server-note{margin-top:15px;padding:12px;border-radius:11px;background:#0a1020;border:1px solid var(--line);font-size:12px;color:var(--muted);line-height:1.5}.server-note b{color:var(--cyan)}"
PRINT ".workspace{min-width:0}.preview-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px 18px;border-bottom:1px solid var(--line)}.preview-head h2{font-size:18px;margin:0}.status{font:12px Consolas,monospace;color:var(--cyan)}.stage{position:relative;min-height:620px;background:#03050b;display:grid;place-items:center;overflow:hidden;border-radius:0 0 18px 18px}.stage img{display:block;width:100%;height:auto;max-height:calc(100vh - 150px);object-fit:contain}.stage.loading:after{content:'ApacheBAS is calculating…';position:absolute;inset:0;display:grid;place-items:center;background:#050814cc;color:var(--cyan);font-weight:800;letter-spacing:.02em}.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:18px}.info{padding:18px}.info h3{margin:0 0 8px}.info p{margin:0;color:var(--muted);line-height:1.55;font-size:14px}.presets{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}.chip{border:1px solid var(--line);background:#111a2e;color:#cfe0fa;border-radius:999px;padding:8px 11px;font-size:12px;cursor:pointer}.chip:hover{border-color:var(--pink);color:white}"
PRINT "@media(max-width:900px){main{grid-template-columns:1fr}.controls{position:static}.stage{min-height:400px}.info-grid{grid-template-columns:1fr}header{padding:0 16px}.tag{display:none}}"
PRINT "</style>"
PRINT "</head>"
PRINT "<body>"
PRINT "<header><div class=""brand""><div class=""mark"">M</div>MathBASIC Studio</div><div class=""tag"">Mathematical art calculated server-side by ApacheBAS</div></header>"
PRINT "<main>"
PRINT "<section class=""panel controls"">"
PRINT "<h1>Mathematical drawing laboratory</h1>"
PRINT "<p>Choose a system, adjust its parameters and let the <code>.bas</code> program generate an SVG on the server.</p>"
PRINT "<div class=""field""><label>Drawing</label><select id=""artType""><option value=""mandelbrot"">Mandelbrot set</option><option value=""julia"">Julia set</option><option value=""burningship"">Burning Ship fractal</option><option value=""sierpinski"">Sierpiński chaos game</option><option value=""lissajous"">Lissajous curve</option><option value=""rose"">Polar rose</option><option value=""spirograph"">Hypotrochoid / spirograph</option><option value=""phyllotaxis"">Phyllotaxis</option><option value=""lorenz"">Lorenz attractor</option><option value=""waves"">Wave interference</option></select></div>"
PRINT "<div class=""field""><label id=""p1Label"">Center X</label><input id=""p1"" type=""number"" step=""any""></div>"
PRINT "<div class=""field""><label id=""p2Label"">Center Y</label><input id=""p2"" type=""number"" step=""any""></div>"
PRINT "<div class=""field""><label id=""p3Label"">Zoom</label><input id=""p3"" type=""number"" step=""any""></div>"
PRINT "<div class=""row""><div class=""field""><label>Detail <small>server work</small></label><select id=""quality""><option value=""1"">Quick</option><option value=""2"" selected>Standard</option><option value=""3"">Detailed</option></select></div><div class=""field""><label>Palette</label><select id=""theme""><option value=""1"">Neon</option><option value=""2"">Fire</option><option value=""3"">Ocean</option><option value=""4"">Monochrome</option></select></div></div>"
PRINT "<div class=""row""><div class=""field""><label>Iterations</label><input id=""iterations"" type=""number"" min=""10"" max=""120"" value=""50""></div><div class=""field""><label>Seed</label><input id=""seed"" type=""number"" value=""42""></div></div>"
PRINT "<div class=""buttons""><button class=""btn primary"" id=""renderButton"">Render</button><button class=""btn"" id=""randomButton"">Randomize</button><button class=""btn"" id=""downloadButton"">Download SVG</button><button class=""btn"" id=""fullButton"">Fullscreen</button><button class=""btn wide"" id=""resetButton"">Reset current drawing</button></div>"
PRINT "<div class=""server-note""><b>Server-side mathematics.</b> The browser only requests and displays the SVG. Fractal iterations, trigonometric curves and differential equations are evaluated by <code>mathbasic.bas</code>.</div>"
PRINT "</section>"
PRINT "<section class=""workspace"">"
PRINT "<div class=""panel""><div class=""preview-head""><div><h2 id=""drawingTitle"">Mandelbrot set</h2><div id=""drawingDesc"" class=""tag"">Escape-time fractal in the complex plane.</div></div><div class=""status"" id=""status"">READY</div></div><div class=""stage"" id=""stage""><img id=""art"" alt=""Server-generated mathematical drawing""></div></div>"
PRINT "<div class=""info-grid""><div class=""panel info""><h3>Instant presets</h3><p>Jump between very different mathematical structures.</p><div class=""presets""><button class=""chip"" data-type=""mandelbrot"">Mandelbrot</button><button class=""chip"" data-type=""julia"">Julia</button><button class=""chip"" data-type=""burningship"">Burning Ship</button><button class=""chip"" data-type=""sierpinski"">Sierpiński</button><button class=""chip"" data-type=""lissajous"">Lissajous</button><button class=""chip"" data-type=""rose"">Rose</button><button class=""chip"" data-type=""spirograph"">Spirograph</button><button class=""chip"" data-type=""phyllotaxis"">Phyllotaxis</button><button class=""chip"" data-type=""lorenz"">Lorenz</button><button class=""chip"" data-type=""waves"">Waves</button></div></div><div class=""panel info""><h3>How it works</h3><p>The same ApacheBAS file has two modes. Normal mode prints this interface. With <code>?render=1</code>, it prints an SVG generated line by line from BASIC loops, real arithmetic, <code>SIN</code>, <code>COS</code>, <code>SQR</code> and <code>RND</code>.</p></div></div>"
PRINT "</section>"
PRINT "</main>"
PRINT "<script>"
PRINT "const cfg={"
PRINT "mandelbrot:{title:'Mandelbrot set',desc:'Escape-time fractal in the complex plane.',labels:['Center X','Center Y','Zoom'],values:[-0.5,0,1],iter:50},"
PRINT "julia:{title:'Julia set',desc:'A complex quadratic map with a fixed parameter c.',labels:['c real','c imaginary','Zoom'],values:[-0.745,0.113,1],iter:55},"
PRINT "burningship:{title:'Burning Ship fractal',desc:'Absolute-value variation of the Mandelbrot recurrence.',labels:['Center X','Center Y','Zoom'],values:[-0.5,-0.55,1],iter:55},"
PRINT "sierpinski:{title:'Sierpiński chaos game',desc:'A fractal triangle produced by repeated random midpoints.',labels:['Point count','Dot radius','Unused'],values:[7000,1.15,0],iter:40},"
PRINT "lissajous:{title:'Lissajous curve',desc:'Two perpendicular harmonic oscillations.',labels:['X frequency','Y frequency','Phase (degrees)'],values:[5,4,90],iter:40},"
PRINT "rose:{title:'Polar rose',desc:'The polar curve r = R cos(kθ).',labels:['k','Radius','Rotations'],values:[5,300,2],iter:40},"
PRINT "spirograph:{title:'Hypotrochoid',desc:'A point attached to a circle rolling inside another circle.',labels:['Rolling radius','Pen distance','Rotations'],values:[73,120,13],iter:40},"
PRINT "phyllotaxis:{title:'Phyllotaxis',desc:'Golden-angle packing seen in sunflower heads.',labels:['Divergence angle','Radial scale','Dot radius'],values:[137.5,7.2,2.1],iter:40},"
PRINT "lorenz:{title:'Lorenz attractor',desc:'Numerical integration of a chaotic differential system.',labels:['Sigma','Rho','Beta'],values:[10,28,2.666667],iter:40},"
PRINT "waves:{title:'Wave interference',desc:'Two circular sources producing a scalar interference field.',labels:['Wavelength','Source separation','Phase'],values:[28,360,0],iter:40}"
PRINT "};"
PRINT "const $=id=>document.getElementById(id);let currentUrl='';"
PRINT "function applyConfig(type,render=true){const c=cfg[type];$('artType').value=type;$('drawingTitle').textContent=c.title;$('drawingDesc').textContent=c.desc;$('p1Label').textContent=c.labels[0];$('p2Label').textContent=c.labels[1];$('p3Label').textContent=c.labels[2];$('p1').value=c.values[0];$('p2').value=c.values[1];$('p3').value=c.values[2];$('iterations').value=c.iter;if(render)renderArt();}"
PRINT "function buildUrl(cache=true){const p=new URLSearchParams({render:'1',type:$('artType').value,p1:$('p1').value,p2:$('p2').value,p3:$('p3').value,q:$('quality').value,theme:$('theme').value,iter:$('iterations').value,seed:$('seed').value});if(cache)p.set('_',Date.now());return 'mathbasic.bas?'+p.toString();}"
PRINT "function renderArt(){const stage=$('stage'),img=$('art');stage.classList.add('loading');$('status').textContent='CALCULATING';currentUrl=buildUrl(false);img.onload=()=>{stage.classList.remove('loading');$('status').textContent='SERVER SVG READY'};img.onerror=()=>{stage.classList.remove('loading');$('status').textContent='RENDER ERROR'};img.src=buildUrl(true);}"
PRINT "function randomize(){const t=$('artType').value;const r=(a,b,d=3)=>(a+Math.random()*(b-a)).toFixed(d);if(t==='mandelbrot'){$('p1').value=r(-1.3,0.2);$('p2').value=r(-0.65,0.65);$('p3').value=r(1.2,12,2)}else if(t==='julia'){$('p1').value=r(-1,1);$('p2').value=r(-1,1);$('p3').value=r(0.8,3,2)}else if(t==='burningship'){$('p1').value=r(-1.9,0.5);$('p2').value=r(-1.7,0.3);$('p3').value=r(1,8,2)}else if(t==='sierpinski'){$('p1').value=Math.floor(r(3000,11000,0));$('p2').value=r(.7,2.2,2)}else if(t==='lissajous'){$('p1').value=Math.floor(r(2,11,0));$('p2').value=Math.floor(r(2,11,0));$('p3').value=Math.floor(r(0,180,0))}else if(t==='rose'){$('p1').value=r(2,9,.1);$('p2').value=Math.floor(r(220,330,0));$('p3').value=Math.floor(r(1,5,0))}else if(t==='spirograph'){$('p1').value=Math.floor(r(35,165,0));$('p2').value=Math.floor(r(40,170,0));$('p3').value=Math.floor(r(6,22,0))}else if(t==='phyllotaxis'){$('p1').value=r(130,145,3);$('p2').value=r(5,9,2);$('p3').value=r(1,3.2,2)}else if(t==='lorenz'){$('p1').value=r(8,14,2);$('p2').value=r(22,34,2);$('p3').value=r(2.2,3.2,3)}else{$('p1').value=r(16,55,2);$('p2').value=Math.floor(r(140,560,0));$('p3').value=r(0,6.28,3)}$('seed').value=Math.floor(Math.random()*999999)+1;renderArt();}"
PRINT "$('renderButton').onclick=renderArt;$('randomButton').onclick=randomize;$('resetButton').onclick=()=>applyConfig($('artType').value);$('artType').onchange=()=>applyConfig($('artType').value);$('downloadButton').onclick=()=>{const a=document.createElement('a');a.href=currentUrl||buildUrl(false);a.download='mathbasic-'+$('artType').value+'.svg';document.body.appendChild(a);a.click();a.remove()};$('fullButton').onclick=()=>$('stage').requestFullscreen?.();document.querySelectorAll('.chip').forEach(b=>b.onclick=()=>applyConfig(b.dataset.type));document.querySelectorAll('input,select').forEach(e=>e.addEventListener('keydown',ev=>{if(ev.key==='Enter')renderArt()}));applyConfig('mandelbrot');"
PRINT "</script>"
PRINT "</body>"
PRINT "</html>"
END

RENDER_MODE:
PRINT "@@CONTENT-TYPE image/svg+xml; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
TYPE$ = LCASE$(TRIM$(GET_TYPE$))
Q = VAL(GET_Q$)
IF Q < 1 THEN Q = 2
IF Q > 3 THEN Q = 2
THEME = VAL(GET_THEME$)
IF THEME < 1 THEN THEME = 1
IF THEME > 4 THEN THEME = 1
BG1$ = "#050816"
BG2$ = "#101a38"
C1$ = "#65e8ff"
C2$ = "#ff6bd6"
C3$ = "#ffd166"
HUE_BASE = 190
IF THEME = 2 THEN BG1$ = "#160605"
IF THEME = 2 THEN BG2$ = "#431408"
IF THEME = 2 THEN C1$ = "#ffcf5a"
IF THEME = 2 THEN C2$ = "#ff5c35"
IF THEME = 2 THEN C3$ = "#fff1c1"
IF THEME = 2 THEN HUE_BASE = 8
IF THEME = 3 THEN BG1$ = "#03131d"
IF THEME = 3 THEN BG2$ = "#063e55"
IF THEME = 3 THEN C1$ = "#65f5ff"
IF THEME = 3 THEN C2$ = "#2e8cff"
IF THEME = 3 THEN C3$ = "#a4fff0"
IF THEME = 3 THEN HUE_BASE = 175
IF THEME = 4 THEN BG1$ = "#050505"
IF THEME = 4 THEN BG2$ = "#252525"
IF THEME = 4 THEN C1$ = "#ffffff"
IF THEME = 4 THEN C2$ = "#9e9e9e"
IF THEME = 4 THEN C3$ = "#d8d8d8"
IF THEME = 4 THEN HUE_BASE = 0
PRINT "<svg xmlns=""http://www.w3.org/2000/svg"" width=""960"" height=""720"" viewBox=""0 0 960 720"">"
PRINT "<defs><linearGradient id=""bg"" x1=""0"" y1=""0"" x2=""1"" y2=""1""><stop offset=""0"" stop-color="""; BG1$; """/><stop offset=""1"" stop-color="""; BG2$; """/></linearGradient><linearGradient id=""stroke"" x1=""0"" y1=""0"" x2=""1"" y2=""1""><stop offset=""0"" stop-color="""; C1$; """/><stop offset="".52"" stop-color="""; C2$; """/><stop offset=""1"" stop-color="""; C3$; """/></linearGradient><filter id=""glow""><feGaussianBlur stdDeviation=""2.2"" result=""b""/><feMerge><feMergeNode in=""b""/><feMergeNode in=""SourceGraphic""/></feMerge></filter><clipPath id=""clip""><rect width=""960"" height=""720"" rx=""12""/></clipPath></defs>"
PRINT "<rect width=""960"" height=""720"" fill=""url(#bg)""/>"
IF TYPE$ = "julia" THEN GOTO DRAW_JULIA
IF TYPE$ = "burningship" THEN GOTO DRAW_BURNING_SHIP
IF TYPE$ = "sierpinski" THEN GOTO DRAW_SIERPINSKI
IF TYPE$ = "lissajous" THEN GOTO DRAW_LISSAJOUS
IF TYPE$ = "rose" THEN GOTO DRAW_ROSE
IF TYPE$ = "spirograph" THEN GOTO DRAW_SPIROGRAPH
IF TYPE$ = "phyllotaxis" THEN GOTO DRAW_PHYLLOTAXIS
IF TYPE$ = "lorenz" THEN GOTO DRAW_LORENZ
IF TYPE$ = "waves" THEN GOTO DRAW_WAVES
GOTO DRAW_MANDELBROT

DRAW_MANDELBROT:
TITLE$ = "Mandelbrot set"
SUBTITLE$ = "z(n+1) = z(n)^2 + c"
FW = 90
FH = 63
IF Q = 2 THEN FW = 120
IF Q = 2 THEN FH = 84
IF Q = 3 THEN FW = 150
IF Q = 3 THEN FH = 105
MAXITER = VAL(GET_ITER$)
IF MAXITER < 10 THEN MAXITER = 50
IF MAXITER > 120 THEN MAXITER = 120
CX0 = -0.5
CY0 = 0
ZOOM = 1
IF TRIM$(GET_P1$) <> "" THEN CX0 = VAL(GET_P1$)
IF TRIM$(GET_P2$) <> "" THEN CY0 = VAL(GET_P2$)
IF TRIM$(GET_P3$) <> "" THEN ZOOM = VAL(GET_P3$)
IF ZOOM < 0.2 THEN ZOOM = 0.2
IF ZOOM > 100 THEN ZOOM = 100
SPANX = 3.2 / ZOOM
SPANY = 2.4 / ZOOM
PW = 960 / FW
PH = 720 / FH
PRINT "<g clip-path=""url(#clip)"" shape-rendering=""crispEdges"">"
FOR YI = 0 TO FH - 1
CI = CY0 - SPANY / 2 + YI * SPANY / (FH - 1)
FOR XI = 0 TO FW - 1
CR = CX0 - SPANX / 2 + XI * SPANX / (FW - 1)
ZR = 0
ZI = 0
IT = 0
WHILE IT < MAXITER AND ZR * ZR + ZI * ZI <= 4
TEMP = ZR * ZR - ZI * ZI + CR
ZI = 2 * ZR * ZI + CI
ZR = TEMP
IT = IT + 1
WEND
COLOR$ = BG1$
IF IT < MAXITER THEN HUE = (HUE_BASE + IT * 17) MOD 360
IF IT < MAXITER THEN COLOR$ = "hsl(" + STR$(HUE) + ",86%,55%)"
PRINT "<rect x="""; XI * PW; """ y="""; YI * PH; """ width="""; PW + 0.25; """ height="""; PH + 0.25; """ fill="""; COLOR$; """/>"
NEXT XI
NEXT YI
PRINT "</g>"
GOTO DRAW_FINISH

DRAW_JULIA:
TITLE$ = "Julia set"
SUBTITLE$ = "fixed c, varying initial z"
FW = 90
FH = 63
IF Q = 2 THEN FW = 120
IF Q = 2 THEN FH = 84
IF Q = 3 THEN FW = 150
IF Q = 3 THEN FH = 105
MAXITER = VAL(GET_ITER$)
IF MAXITER < 10 THEN MAXITER = 55
IF MAXITER > 120 THEN MAXITER = 120
JCR = -0.745
JCI = 0.113
ZOOM = 1
IF TRIM$(GET_P1$) <> "" THEN JCR = VAL(GET_P1$)
IF TRIM$(GET_P2$) <> "" THEN JCI = VAL(GET_P2$)
IF TRIM$(GET_P3$) <> "" THEN ZOOM = VAL(GET_P3$)
IF ZOOM < 0.2 THEN ZOOM = 0.2
IF ZOOM > 60 THEN ZOOM = 60
SPANX = 3 / ZOOM
SPANY = 2.25 / ZOOM
PW = 960 / FW
PH = 720 / FH
PRINT "<g clip-path=""url(#clip)"" shape-rendering=""crispEdges"">"
FOR YI = 0 TO FH - 1
FOR XI = 0 TO FW - 1
ZR = -SPANX / 2 + XI * SPANX / (FW - 1)
ZI = -SPANY / 2 + YI * SPANY / (FH - 1)
IT = 0
WHILE IT < MAXITER AND ZR * ZR + ZI * ZI <= 4
TEMP = ZR * ZR - ZI * ZI + JCR
ZI = 2 * ZR * ZI + JCI
ZR = TEMP
IT = IT + 1
WEND
COLOR$ = BG1$
IF IT < MAXITER THEN HUE = (HUE_BASE + IT * 21) MOD 360
IF IT < MAXITER THEN COLOR$ = "hsl(" + STR$(HUE) + ",88%,57%)"
PRINT "<rect x="""; XI * PW; """ y="""; YI * PH; """ width="""; PW + 0.25; """ height="""; PH + 0.25; """ fill="""; COLOR$; """/>"
NEXT XI
NEXT YI
PRINT "</g>"
GOTO DRAW_FINISH

DRAW_BURNING_SHIP:
TITLE$ = "Burning Ship fractal"
SUBTITLE$ = "absolute-value quadratic recurrence"
FW = 90
FH = 63
IF Q = 2 THEN FW = 120
IF Q = 2 THEN FH = 84
IF Q = 3 THEN FW = 150
IF Q = 3 THEN FH = 105
MAXITER = VAL(GET_ITER$)
IF MAXITER < 10 THEN MAXITER = 55
IF MAXITER > 120 THEN MAXITER = 120
CX0 = -0.5
CY0 = -0.55
ZOOM = 1
IF TRIM$(GET_P1$) <> "" THEN CX0 = VAL(GET_P1$)
IF TRIM$(GET_P2$) <> "" THEN CY0 = VAL(GET_P2$)
IF TRIM$(GET_P3$) <> "" THEN ZOOM = VAL(GET_P3$)
IF ZOOM < 0.2 THEN ZOOM = 0.2
IF ZOOM > 80 THEN ZOOM = 80
SPANX = 3.4 / ZOOM
SPANY = 2.5 / ZOOM
PW = 960 / FW
PH = 720 / FH
PRINT "<g clip-path=""url(#clip)"" shape-rendering=""crispEdges"">"
FOR YI = 0 TO FH - 1
CI = CY0 - SPANY / 2 + YI * SPANY / (FH - 1)
FOR XI = 0 TO FW - 1
CR = CX0 - SPANX / 2 + XI * SPANX / (FW - 1)
ZR = 0
ZI = 0
IT = 0
WHILE IT < MAXITER AND ZR * ZR + ZI * ZI <= 4
AR = ABS(ZR)
AI = ABS(ZI)
TEMP = AR * AR - AI * AI + CR
ZI = 2 * AR * AI + CI
ZR = TEMP
IT = IT + 1
WEND
COLOR$ = BG1$
IF IT < MAXITER THEN HUE = (HUE_BASE + 35 + IT * 13) MOD 360
IF IT < MAXITER THEN COLOR$ = "hsl(" + STR$(HUE) + ",90%,55%)"
PRINT "<rect x="""; XI * PW; """ y="""; YI * PH; """ width="""; PW + 0.25; """ height="""; PH + 0.25; """ fill="""; COLOR$; """/>"
NEXT XI
NEXT YI
PRINT "</g>"
GOTO DRAW_FINISH

DRAW_SIERPINSKI:
TITLE$ = "Sierpinski chaos game"
SUBTITLE$ = "random midpoint iteration"
POINTS = 4200
IF Q = 2 THEN POINTS = 7000
IF Q = 3 THEN POINTS = 10500
IF TRIM$(GET_P1$) <> "" THEN POINTS = INT(VAL(GET_P1$))
IF POINTS < 500 THEN POINTS = 500
IF POINTS > 12000 THEN POINTS = 12000
DOTR = 1.15
IF TRIM$(GET_P2$) <> "" THEN DOTR = VAL(GET_P2$)
IF DOTR < 0.4 THEN DOTR = 0.4
IF DOTR > 4 THEN DOTR = 4
SEED = VAL(GET_SEED$)
IF SEED = 0 THEN SEED = 42
RANDOMIZE SEED
PX = 480
PY = 360
PRINT "<g clip-path=""url(#clip)"" opacity="".84"">"
FOR I = 1 TO POINTS
V = INT(RND * 3)
VX = 480
VY = 45
IF V = 1 THEN VX = 65
IF V = 1 THEN VY = 665
IF V = 2 THEN VX = 895
IF V = 2 THEN VY = 665
PX = (PX + VX) / 2
PY = (PY + VY) / 2
HUE = (HUE_BASE + I * 5) MOD 360
IF I > 20 THEN PRINT "<circle cx="""; PX; """ cy="""; PY; """ r="""; DOTR; """ fill=""hsl("; HUE; ",88%,62%)""/>"
NEXT I
PRINT "</g>"
GOTO DRAW_FINISH

DRAW_LISSAJOUS:
TITLE$ = "Lissajous curve"
SUBTITLE$ = "x = sin(at + phase), y = sin(bt)"
A = 5
B = 4
PHASE = 90
IF TRIM$(GET_P1$) <> "" THEN A = VAL(GET_P1$)
IF TRIM$(GET_P2$) <> "" THEN B = VAL(GET_P2$)
IF TRIM$(GET_P3$) <> "" THEN PHASE = VAL(GET_P3$)
IF A < 1 THEN A = 1
IF A > 20 THEN A = 20
IF B < 1 THEN B = 1
IF B > 20 THEN B = 20
N = 650
IF Q = 2 THEN N = 1100
IF Q = 3 THEN N = 1800
PHR = PHASE * PI / 180
PX = 480 + 400 * SIN(PHR)
PY = 360
PRINT "<g clip-path=""url(#clip)"" fill=""none"" stroke=""url(#stroke)"" stroke-width=""1.8"" opacity="".82"" filter=""url(#glow)"">"
FOR I = 1 TO N
T = (I / N) * 2 * PI
SX = 480 + 400 * SIN(A * T + PHR)
SY = 360 + 300 * SIN(B * T)
PRINT "<line x1="""; PX; """ y1="""; PY; """ x2="""; SX; """ y2="""; SY; """/>"
PX = SX
PY = SY
NEXT I
PRINT "</g>"
GOTO DRAW_FINISH

DRAW_ROSE:
TITLE$ = "Polar rose"
SUBTITLE$ = "r = R cos(k theta)"
K = 5
RAD = 300
ROTS = 2
IF TRIM$(GET_P1$) <> "" THEN K = VAL(GET_P1$)
IF TRIM$(GET_P2$) <> "" THEN RAD = VAL(GET_P2$)
IF TRIM$(GET_P3$) <> "" THEN ROTS = VAL(GET_P3$)
IF K < 0.5 THEN K = 0.5
IF K > 20 THEN K = 20
IF RAD < 40 THEN RAD = 40
IF RAD > 335 THEN RAD = 335
IF ROTS < 1 THEN ROTS = 1
IF ROTS > 12 THEN ROTS = 12
N = 700
IF Q = 2 THEN N = 1300
IF Q = 3 THEN N = 2100
T = 0
RR = RAD * COS(K * T)
PX = 480 + RR * COS(T)
PY = 360 + RR * SIN(T)
PRINT "<g clip-path=""url(#clip)"" fill=""none"" stroke=""url(#stroke)"" stroke-width=""1.7"" opacity="".86"" filter=""url(#glow)"">"
FOR I = 1 TO N
T = (I / N) * ROTS * 2 * PI
RR = RAD * COS(K * T)
SX = 480 + RR * COS(T)
SY = 360 + RR * SIN(T)
PRINT "<line x1="""; PX; """ y1="""; PY; """ x2="""; SX; """ y2="""; SY; """/>"
PX = SX
PY = SY
NEXT I
PRINT "</g>"
GOTO DRAW_FINISH

DRAW_SPIROGRAPH:
TITLE$ = "Hypotrochoid spirograph"
SUBTITLE$ = "a circle rolling inside a larger circle"
SMALLR = 73
DIST = 120
ROTS = 13
IF TRIM$(GET_P1$) <> "" THEN SMALLR = VAL(GET_P1$)
IF TRIM$(GET_P2$) <> "" THEN DIST = VAL(GET_P2$)
IF TRIM$(GET_P3$) <> "" THEN ROTS = VAL(GET_P3$)
IF SMALLR < 20 THEN SMALLR = 20
IF SMALLR > 180 THEN SMALLR = 180
IF DIST < 5 THEN DIST = 5
IF DIST > 180 THEN DIST = 180
IF ROTS < 1 THEN ROTS = 1
IF ROTS > 40 THEN ROTS = 40
BIGR = 210
RATIO = (BIGR - SMALLR) / SMALLR
N = 900
IF Q = 2 THEN N = 1700
IF Q = 3 THEN N = 2800
STEPDEG = (ROTS / N) * 360
STEPINNER = STEPDEG * RATIO
ANGLE1 = 0
ANGLE2 = 0
T1 = 0
T2 = 0
PX = 480 + (BIGR - SMALLR) * COS(T1) + DIST * COS(T2)
PY = 360 + (BIGR - SMALLR) * SIN(T1) - DIST * SIN(T2)
PRINT "<g clip-path=""url(#clip)"" fill=""none"" stroke=""url(#stroke)"" stroke-width=""1.35"" opacity="".75"" filter=""url(#glow)"">"
FOR I = 1 TO N
ANGLE1 = ANGLE1 + STEPDEG
ANGLE2 = ANGLE2 + STEPINNER
IF ANGLE1 >= 360 THEN ANGLE1 = ANGLE1 - 360
IF ANGLE2 >= 360 THEN ANGLE2 = ANGLE2 - 360
T1 = ANGLE1 * PI / 180
T2 = ANGLE2 * PI / 180
SX = 480 + (BIGR - SMALLR) * COS(T1) + DIST * COS(T2)
SY = 360 + (BIGR - SMALLR) * SIN(T1) - DIST * SIN(T2)
PRINT "<line x1="""; PX; """ y1="""; PY; """ x2="""; SX; """ y2="""; SY; """/>"
PX = SX
PY = SY
NEXT I
PRINT "</g>"
GOTO DRAW_FINISH

DRAW_PHYLLOTAXIS:
TITLE$ = "Phyllotaxis"
SUBTITLE$ = "golden-angle radial packing"
ANGLEDEG = 137.5
SCALE = 7.2
DOTR = 2.1
IF TRIM$(GET_P1$) <> "" THEN ANGLEDEG = VAL(GET_P1$)
IF TRIM$(GET_P2$) <> "" THEN SCALE = VAL(GET_P2$)
IF TRIM$(GET_P3$) <> "" THEN DOTR = VAL(GET_P3$)
IF ANGLEDEG < 1 THEN ANGLEDEG = 1
IF ANGLEDEG > 359 THEN ANGLEDEG = 359
IF SCALE < 2 THEN SCALE = 2
IF SCALE > 9 THEN SCALE = 9
IF DOTR < 0.5 THEN DOTR = 0.5
IF DOTR > 5 THEN DOTR = 5
N = 750
IF Q = 2 THEN N = 1400
IF Q = 3 THEN N = 2200
PRINT "<g clip-path=""url(#clip)"" opacity="".86"">"
ANGLE = 0
FOR I = 1 TO N
ANGLE = ANGLE + ANGLEDEG
IF ANGLE >= 360 THEN ANGLE = ANGLE - 360
T = ANGLE * PI / 180
RR = SCALE * SQR(I)
SX = 480 + RR * COS(T)
SY = 360 + RR * SIN(T)
HUE = (HUE_BASE + I * 7) MOD 360
PRINT "<circle cx="""; SX; """ cy="""; SY; """ r="""; DOTR; """ fill=""hsl("; HUE; ",90%,62%)""/>"
NEXT I
PRINT "</g>"
GOTO DRAW_FINISH

DRAW_LORENZ:
TITLE$ = "Lorenz attractor"
SUBTITLE$ = "numerically integrated chaotic flow"
SIGMA = 10
RHO = 28
BETA = 2.666667
IF TRIM$(GET_P1$) <> "" THEN SIGMA = VAL(GET_P1$)
IF TRIM$(GET_P2$) <> "" THEN RHO = VAL(GET_P2$)
IF TRIM$(GET_P3$) <> "" THEN BETA = VAL(GET_P3$)
IF SIGMA < 1 THEN SIGMA = 1
IF SIGMA > 30 THEN SIGMA = 30
IF RHO < 1 THEN RHO = 1
IF RHO > 60 THEN RHO = 60
IF BETA < 0.1 THEN BETA = 0.1
IF BETA > 10 THEN BETA = 10
STEPS = 4200
SKIP = 4
IF Q = 2 THEN STEPS = 7200
IF Q = 2 THEN SKIP = 3
IF Q = 3 THEN STEPS = 11000
IF Q = 3 THEN SKIP = 2
DT = 0.005
LX = 0.1
LY = 0
LZ = 0
PX = 480 + LX * 11
PY = 680 - LZ * 9
PRINT "<g clip-path=""url(#clip)"" fill=""none"" stroke=""url(#stroke)"" stroke-width=""1.05"" opacity="".54"" filter=""url(#glow)"">"
FOR I = 1 TO STEPS
DX = SIGMA * (LY - LX)
DY = LX * (RHO - LZ) - LY
DZ = LX * LY - BETA * LZ
LX = LX + DX * DT
LY = LY + DY * DT
LZ = LZ + DZ * DT
SX = 480 + LX * 11
SY = 680 - LZ * 9
IF I > 500 AND I MOD SKIP = 0 THEN PRINT "<line x1="""; PX; """ y1="""; PY; """ x2="""; SX; """ y2="""; SY; """/>"
IF I > 500 AND I MOD SKIP = 0 THEN PX = SX
IF I > 500 AND I MOD SKIP = 0 THEN PY = SY
NEXT I
PRINT "</g>"
GOTO DRAW_FINISH

DRAW_WAVES:
TITLE$ = "Wave interference"
SUBTITLE$ = "two circular sources, scalar superposition"
WAVELEN = 28
SEP = 360
PHASE = 0
IF TRIM$(GET_P1$) <> "" THEN WAVELEN = VAL(GET_P1$)
IF TRIM$(GET_P2$) <> "" THEN SEP = VAL(GET_P2$)
IF TRIM$(GET_P3$) <> "" THEN PHASE = VAL(GET_P3$)
IF WAVELEN < 5 THEN WAVELEN = 5
IF WAVELEN > 120 THEN WAVELEN = 120
IF SEP < 20 THEN SEP = 20
IF SEP > 800 THEN SEP = 800
FW = 90
FH = 63
IF Q = 2 THEN FW = 120
IF Q = 2 THEN FH = 84
IF Q = 3 THEN FW = 150
IF Q = 3 THEN FH = 105
PW = 960 / FW
PH = 720 / FH
S1X = 480 - SEP / 2
S2X = 480 + SEP / 2
S1Y = 360
S2Y = 360
PRINT "<g clip-path=""url(#clip)"" shape-rendering=""crispEdges"">"
FOR YI = 0 TO FH - 1
CY = YI * PH + PH / 2
FOR XI = 0 TO FW - 1
CX = XI * PW + PW / 2
DXA = CINT(CX - S1X)
DYA = CINT(CY - S1Y)
DXB = CINT(CX - S2X)
DYB = CINT(CY - S2Y)
D1 = SQR(DXA * DXA + DYA * DYA)
D2 = SQR(DXB * DXB + DYB * DYB)
WV = SIN(D1 / WAVELEN + PHASE) + SIN(D2 / WAVELEN - PHASE)
HUE = (HUE_BASE + INT((WV + 2) * 70)) MOD 360
LIGHT = 30 + INT((WV + 2) * 11)
COLOR$ = "hsl(" + STR$(HUE) + ",88%," + STR$(LIGHT) + "%)"
PRINT "<rect x="""; XI * PW; """ y="""; YI * PH; """ width="""; PW + 0.25; """ height="""; PH + 0.25; """ fill="""; COLOR$; """/>"
NEXT XI
NEXT YI
PRINT "</g><circle cx="""; S1X; """ cy="""; S1Y; """ r=""6"" fill="""; C3$; """/><circle cx="""; S2X; """ cy="""; S2Y; """ r=""6"" fill="""; C3$; """/>"
GOTO DRAW_FINISH

DRAW_FINISH:
PRINT "<rect x=""20"" y=""18"" width=""520"" height=""64"" rx=""13"" fill=""#02040bbb"" stroke=""#ffffff22""/>"
PRINT "<text x=""40"" y=""47"" fill=""#ffffff"" font-family=""Segoe UI,Arial"" font-size=""22"" font-weight=""700"">"; TITLE$; "</text>"
PRINT "<text x=""40"" y=""68"" fill=""#b8c8e6"" font-family=""Consolas,monospace"" font-size=""12"">"; SUBTITLE$; "</text>"
PRINT "<text x=""940"" y=""700"" text-anchor=""end"" fill=""#ffffff77"" font-family=""Consolas,monospace"" font-size=""11"">MathBASIC 1.0.3 / ApacheBAS server SVG</text>"
PRINT "</svg>"
END
