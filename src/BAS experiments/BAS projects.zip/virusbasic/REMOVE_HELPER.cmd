@echo off
setlocal
set "TARGET=%~dp0..\..\cgi-bin\VirusBASICHash.exe"
if exist "%TARGET%" del /F /Q "%TARGET%"
echo VirusBASIC CGI helper removed.
pause
