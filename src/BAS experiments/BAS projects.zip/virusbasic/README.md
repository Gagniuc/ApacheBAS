# VirusBASIC

VirusBASIC is a small VirusTotal-style local file triage page for ApacheBAS.
It calculates MD5, SHA-1 and SHA-256, detects several common magic signatures,
checks a local hash list, and displays basic filename/structure indicators.

## Installation

1. Copy the `virusbasic` directory to `C:\xampp\htdocs\virusbasic`.
2. Run `INSTALL_HELPER.cmd` once. It copies the native hashing CGI to
   `C:\xampp\cgi-bin\VirusBASICHash.exe`.
3. Open `http://localhost/virusbasic/virusbasic.bas`.

## Important behavior

- The selected file is sent only to the local XAMPP server.
- The helper reads the file in memory and does not store or execute it.
- Maximum file size is 32 MiB.
- The local signature database is `data\signatures.txt`.
- The included database recognizes the standard EICAR antivirus test hash.
- A `0 / 1` result is not proof that a file is safe.
- The VirusTotal button searches by SHA-256; it does not automatically upload the sample.

## Components

- `virusbasic.bas` — ApacheBAS interface and local signature check.
- `tools\VirusBASICHash.exe` — native PE32 CGI hashing helper.
- `tools\VirusBASICHash.c` and `tools\imports.s` — complete helper source.
- `INSTALL_HELPER.cmd` — installs the helper into XAMPP `cgi-bin`.
