@echo off
setlocal
set "SOURCE=%~dp0tools\VirusBASICHash.exe"
set "TARGET=%~dp0..\..\cgi-bin\VirusBASICHash.exe"
if not exist "%SOURCE%" (
  echo ERROR: tools\VirusBASICHash.exe is missing.
  pause
  exit /b 1
)
copy /Y "%SOURCE%" "%TARGET%" >nul
if errorlevel 1 (
  echo ERROR: Could not copy the helper to C:\xampp\cgi-bin.
  echo Run this file with sufficient permissions and verify the project is under htdocs.
  pause
  exit /b 1
)
echo VirusBASICHash.exe installed in the XAMPP cgi-bin directory.
echo Open: http://localhost/virusbasic/virusbasic.bas
pause
