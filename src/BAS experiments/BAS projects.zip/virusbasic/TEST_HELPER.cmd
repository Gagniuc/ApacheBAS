@echo off
setlocal
set "TMP=%TEMP%\virusbasic-harmless-test.txt"
>"%TMP%" echo VirusBASIC harmless hashing test
curl.exe -s -X POST -H "Content-Type: application/octet-stream" --data-binary "@%TMP%" "http://localhost/cgi-bin/VirusBASICHash.exe?name=harmless-test.txt"
echo.
del /Q "%TMP%" >nul 2>nul
pause
