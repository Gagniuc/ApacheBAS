/*
  VirusBASICHash.exe
  Read-only CGI hashing helper for VirusBASIC / ApacheBAS.
  PE32, no C runtime. Imports only KERNEL32.dll.

  The request body is scanned in memory and is never written to disk.
  Output: JSON containing MD5, SHA-1, SHA-256 and basic file indicators.
*/

typedef void *HANDLE;
typedef void *LPVOID;
typedef const char *LPCSTR;
typedef char *LPSTR;
typedef unsigned int DWORD;
typedef unsigned int UINT;
typedef int BOOL;
typedef unsigned char U8;
typedef unsigned short U16;
typedef unsigned int U32;
typedef unsigned long long U64;

#define NULL ((void*)0)
#define STD_INPUT_HANDLE  ((DWORD)-10)
#define STD_OUTPUT_HANDLE ((DWORD)-11)
#define MAX_FILE_SIZE (32U * 1024U * 1024U)
#define READ_BUFFER_SIZE 65536U
#define ENV_BUFFER_SIZE 4096U
#define OUTPUT_SIZE 8192U

__declspec(dllimport) void   __stdcall ExitProcess(UINT code);
__declspec(dllimport) HANDLE __stdcall GetStdHandle(DWORD which);
__declspec(dllimport) BOOL   __stdcall ReadFile(HANDLE file, LPVOID buffer, DWORD bytes, DWORD *read_bytes, LPVOID overlapped);
__declspec(dllimport) BOOL   __stdcall WriteFile(HANDLE file, const void *buffer, DWORD bytes, DWORD *written, LPVOID overlapped);
__declspec(dllimport) DWORD  __stdcall GetEnvironmentVariableA(LPCSTR name, LPSTR value, DWORD size);

static U8 read_buffer[READ_BUFFER_SIZE];
static char env_buffer[ENV_BUFFER_SIZE];
static char filename[512];
static char output[OUTPUT_SIZE];
static U8 first_bytes[32];
static U32 first_count;
static U32 total_size;
static U32 printable_count;
static U32 nul_count;
static U32 unique_table[256];

static U32 strlen_c(const char *s) { U32 n=0; if(!s)return 0; while(s[n])n++; return n; }
static char lower_c(char c) { return (c>='A'&&c<='Z')?(char)(c+32):c; }
static int eq_i(const char *a,const char *b){ while(*a&&*b){ if(lower_c(*a)!=lower_c(*b))return 0; a++;b++; } return *a==0&&*b==0; }
static int ends_i(const char *s,const char *tail){ U32 a=strlen_c(s),b=strlen_c(tail),i; if(b>a)return 0; for(i=0;i<b;i++) if(lower_c(s[a-b+i])!=lower_c(tail[i])) return 0; return 1; }
static int contains_i(const char *s,const char *needle){ U32 i,j,n=strlen_c(needle); if(!n)return 1; for(i=0;s[i];i++){ for(j=0;j<n;j++){ if(!s[i+j]||lower_c(s[i+j])!=lower_c(needle[j]))break; } if(j==n)return 1; } return 0; }
static U32 parse_u32(const char *s, int *ok){ U32 n=0,d; *ok=0; if(!s||!*s)return 0; while(*s){ if(*s<'0'||*s>'9')return 0; d=(U32)(*s-'0'); if(n>429496729U||(n==429496729U&&d>5U))return 0; n=n*10U+d; s++; } *ok=1; return n; }
static int hexval(char c){ if(c>='0'&&c<='9')return c-'0'; c=lower_c(c); if(c>='a'&&c<='f')return c-'a'+10; return -1; }
static void decode_query_name(const char *q){ U32 o=0,i=0; filename[0]=0; if(!q)return; while(q[i]){ if((q[i]=='n'||q[i]=='N')&&(q[i+1]=='a'||q[i+1]=='A')&&(q[i+2]=='m'||q[i+2]=='M')&&(q[i+3]=='e'||q[i+3]=='E')&&q[i+4]=='='){ i+=5; break; } while(q[i]&&q[i]!='&')i++; if(q[i]=='&')i++; }
 while(q[i]&&q[i]!='&'&&o<sizeof(filename)-1){ char c=q[i++]; if(c=='+')c=' '; else if(c=='%'&&q[i]&&q[i+1]){ int h1=hexval(q[i]),h2=hexval(q[i+1]); if(h1>=0&&h2>=0){ c=(char)((h1<<4)|h2); i+=2; } } if((unsigned char)c<32)c='_'; if(c=='\\'||c=='/')c='_'; filename[o++]=c; } filename[o]=0; if(o==0){ filename[0]='u';filename[1]='n';filename[2]='n';filename[3]='a';filename[4]='m';filename[5]='e';filename[6]='d';filename[7]=0; } }

static BOOL write_all(HANDLE h,const char *s,U32 len){ U32 off=0,w=0; while(off<len){ w=0; if(!WriteFile(h,s+off,len-off,&w,NULL)||w==0)return 0; off+=w; } return 1; }
static U32 out_pos;
static void out_reset(void){out_pos=0;output[0]=0;}
static void out_char(char c){if(out_pos+1<OUTPUT_SIZE){output[out_pos++]=c;output[out_pos]=0;}}
static void out_text(const char *s){while(*s)out_char(*s++);}
static void out_json(const char *s){ while(*s){ unsigned char c=(unsigned char)*s++; if(c=='"'||c=='\\'){out_char('\\');out_char((char)c);} else if(c=='\n'){out_text("\\n");} else if(c=='\r'){out_text("\\r");} else if(c=='\t'){out_text("\\t");} else if(c<32){out_char('_');} else out_char((char)c); } }
static void out_u32(U32 n){ char tmp[16];U32 p=0; if(n==0){out_char('0');return;} while(n&&p<15){tmp[p++]=(char)('0'+(n%10U));n/=10U;} while(p)out_char(tmp[--p]); }
static void out_hex(const U8 *data,U32 n){ static const char h[]="0123456789abcdef";U32 i;for(i=0;i<n;i++){out_char(h[data[i]>>4]);out_char(h[data[i]&15]);}}
static void send_error(HANDLE out,const char *message){ out_reset();out_text("Content-Type: application/json; charset=utf-8\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n\r\n{\"ok\":false,\"error\":\"");out_json(message);out_text("\"}");write_all(out,output,out_pos);ExitProcess(1); }

/* MD5 */
typedef struct { U32 h[4]; U64 bits; U8 block[64]; U32 used; } MD5CTX;
static U32 rol32(U32 x,U32 n){return (x<<n)|(x>>(32-n));}
static U32 load_le32(const U8*p){return (U32)p[0]|((U32)p[1]<<8)|((U32)p[2]<<16)|((U32)p[3]<<24);}
static void store_le32(U8*p,U32 x){p[0]=(U8)x;p[1]=(U8)(x>>8);p[2]=(U8)(x>>16);p[3]=(U8)(x>>24);}
static void md5_transform(MD5CTX*c,const U8*b){ static const U32 k[64]={
0xd76aa478U,0xe8c7b756U,0x242070dbU,0xc1bdceeeU,0xf57c0fafU,0x4787c62aU,0xa8304613U,0xfd469501U,0x698098d8U,0x8b44f7afU,0xffff5bb1U,0x895cd7beU,0x6b901122U,0xfd987193U,0xa679438eU,0x49b40821U,
0xf61e2562U,0xc040b340U,0x265e5a51U,0xe9b6c7aaU,0xd62f105dU,0x02441453U,0xd8a1e681U,0xe7d3fbc8U,0x21e1cde6U,0xc33707d6U,0xf4d50d87U,0x455a14edU,0xa9e3e905U,0xfcefa3f8U,0x676f02d9U,0x8d2a4c8aU,
0xfffa3942U,0x8771f681U,0x6d9d6122U,0xfde5380cU,0xa4beea44U,0x4bdecfa9U,0xf6bb4b60U,0xbebfbc70U,0x289b7ec6U,0xeaa127faU,0xd4ef3085U,0x04881d05U,0xd9d4d039U,0xe6db99e5U,0x1fa27cf8U,0xc4ac5665U,
0xf4292244U,0x432aff97U,0xab9423a7U,0xfc93a039U,0x655b59c3U,0x8f0ccc92U,0xffeff47dU,0x85845dd1U,0x6fa87e4fU,0xfe2ce6e0U,0xa3014314U,0x4e0811a1U,0xf7537e82U,0xbd3af235U,0x2ad7d2bbU,0xeb86d391U};
static const U8 s[64]={7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21};
 U32 a=c->h[0],d=c->h[3],cc=c->h[2],bb=c->h[1],m[16],f,g,t,i;for(i=0;i<16;i++)m[i]=load_le32(b+4*i);for(i=0;i<64;i++){if(i<16){f=(bb&cc)|((~bb)&d);g=i;}else if(i<32){f=(d&bb)|((~d)&cc);g=(5*i+1)&15;}else if(i<48){f=bb^cc^d;g=(3*i+5)&15;}else{f=cc^(bb|(~d));g=(7*i)&15;}t=d;d=cc;cc=bb;bb=bb+rol32(a+f+k[i]+m[g],s[i]);a=t;}c->h[0]+=a;c->h[1]+=bb;c->h[2]+=cc;c->h[3]+=d;}
static void md5_init(MD5CTX*c){c->h[0]=0x67452301U;c->h[1]=0xefcdab89U;c->h[2]=0x98badcfeU;c->h[3]=0x10325476U;c->bits=0;c->used=0;}
static void md5_update(MD5CTX*c,const U8*p,U32 n){U32 take;c->bits+=(U64)n*8ULL;while(n){take=64-c->used;if(take>n)take=n;{U32 i;for(i=0;i<take;i++)c->block[c->used+i]=p[i];}c->used+=take;p+=take;n-=take;if(c->used==64){md5_transform(c,c->block);c->used=0;}}}
static void md5_final(MD5CTX*c,U8 out[16]){U32 i;c->block[c->used++]=0x80;if(c->used>56){while(c->used<64)c->block[c->used++]=0;md5_transform(c,c->block);c->used=0;}while(c->used<56)c->block[c->used++]=0;for(i=0;i<8;i++)c->block[56+i]=(U8)(c->bits>>(8*i));md5_transform(c,c->block);for(i=0;i<4;i++)store_le32(out+4*i,c->h[i]);}

/* SHA-1 */
typedef struct { U32 h[5]; U64 bits; U8 block[64]; U32 used; } SHA1CTX;
static U32 load_be32(const U8*p){return ((U32)p[0]<<24)|((U32)p[1]<<16)|((U32)p[2]<<8)|(U32)p[3];}
static void store_be32(U8*p,U32 x){p[0]=(U8)(x>>24);p[1]=(U8)(x>>16);p[2]=(U8)(x>>8);p[3]=(U8)x;}
static void sha1_transform(SHA1CTX*c,const U8*b){U32 w[80],a,bb,cc,d,e,f,k,t,i;for(i=0;i<16;i++)w[i]=load_be32(b+4*i);for(i=16;i<80;i++)w[i]=rol32(w[i-3]^w[i-8]^w[i-14]^w[i-16],1);a=c->h[0];bb=c->h[1];cc=c->h[2];d=c->h[3];e=c->h[4];for(i=0;i<80;i++){if(i<20){f=(bb&cc)|((~bb)&d);k=0x5a827999U;}else if(i<40){f=bb^cc^d;k=0x6ed9eba1U;}else if(i<60){f=(bb&cc)|(bb&d)|(cc&d);k=0x8f1bbcdcU;}else{f=bb^cc^d;k=0xca62c1d6U;}t=rol32(a,5)+f+e+k+w[i];e=d;d=cc;cc=rol32(bb,30);bb=a;a=t;}c->h[0]+=a;c->h[1]+=bb;c->h[2]+=cc;c->h[3]+=d;c->h[4]+=e;}
static void sha1_init(SHA1CTX*c){c->h[0]=0x67452301U;c->h[1]=0xefcdab89U;c->h[2]=0x98badcfeU;c->h[3]=0x10325476U;c->h[4]=0xc3d2e1f0U;c->bits=0;c->used=0;}
static void sha1_update(SHA1CTX*c,const U8*p,U32 n){U32 take;c->bits+=(U64)n*8ULL;while(n){take=64-c->used;if(take>n)take=n;{U32 i;for(i=0;i<take;i++)c->block[c->used+i]=p[i];}c->used+=take;p+=take;n-=take;if(c->used==64){sha1_transform(c,c->block);c->used=0;}}}
static void sha1_final(SHA1CTX*c,U8 out[20]){U32 i;c->block[c->used++]=0x80;if(c->used>56){while(c->used<64)c->block[c->used++]=0;sha1_transform(c,c->block);c->used=0;}while(c->used<56)c->block[c->used++]=0;for(i=0;i<8;i++)c->block[63-i]=(U8)(c->bits>>(8*i));sha1_transform(c,c->block);for(i=0;i<5;i++)store_be32(out+4*i,c->h[i]);}

/* SHA-256 */
typedef struct { U32 h[8]; U64 bits; U8 block[64]; U32 used; } SHA256CTX;
static U32 ror32(U32 x,U32 n){return (x>>n)|(x<<(32-n));}
static void sha256_transform(SHA256CTX*c,const U8*b){static const U32 k[64]={0x428a2f98U,0x71374491U,0xb5c0fbcfU,0xe9b5dba5U,0x3956c25bU,0x59f111f1U,0x923f82a4U,0xab1c5ed5U,0xd807aa98U,0x12835b01U,0x243185beU,0x550c7dc3U,0x72be5d74U,0x80deb1feU,0x9bdc06a7U,0xc19bf174U,0xe49b69c1U,0xefbe4786U,0x0fc19dc6U,0x240ca1ccU,0x2de92c6fU,0x4a7484aaU,0x5cb0a9dcU,0x76f988daU,0x983e5152U,0xa831c66dU,0xb00327c8U,0xbf597fc7U,0xc6e00bf3U,0xd5a79147U,0x06ca6351U,0x14292967U,0x27b70a85U,0x2e1b2138U,0x4d2c6dfcU,0x53380d13U,0x650a7354U,0x766a0abbU,0x81c2c92eU,0x92722c85U,0xa2bfe8a1U,0xa81a664bU,0xc24b8b70U,0xc76c51a3U,0xd192e819U,0xd6990624U,0xf40e3585U,0x106aa070U,0x19a4c116U,0x1e376c08U,0x2748774cU,0x34b0bcb5U,0x391c0cb3U,0x4ed8aa4aU,0x5b9cca4fU,0x682e6ff3U,0x748f82eeU,0x78a5636fU,0x84c87814U,0x8cc70208U,0x90befffaU,0xa4506cebU,0xbef9a3f7U,0xc67178f2U};
U32 w[64],a,bb,cc,d,e,f,g,h,t1,t2,s0,s1,ch,maj,i;for(i=0;i<16;i++)w[i]=load_be32(b+4*i);for(i=16;i<64;i++){s0=ror32(w[i-15],7)^ror32(w[i-15],18)^(w[i-15]>>3);s1=ror32(w[i-2],17)^ror32(w[i-2],19)^(w[i-2]>>10);w[i]=w[i-16]+s0+w[i-7]+s1;}a=c->h[0];bb=c->h[1];cc=c->h[2];d=c->h[3];e=c->h[4];f=c->h[5];g=c->h[6];h=c->h[7];for(i=0;i<64;i++){s1=ror32(e,6)^ror32(e,11)^ror32(e,25);ch=(e&f)^((~e)&g);t1=h+s1+ch+k[i]+w[i];s0=ror32(a,2)^ror32(a,13)^ror32(a,22);maj=(a&bb)^(a&cc)^(bb&cc);t2=s0+maj;h=g;g=f;f=e;e=d+t1;d=cc;cc=bb;bb=a;a=t1+t2;}c->h[0]+=a;c->h[1]+=bb;c->h[2]+=cc;c->h[3]+=d;c->h[4]+=e;c->h[5]+=f;c->h[6]+=g;c->h[7]+=h;}
static void sha256_init(SHA256CTX*c){c->h[0]=0x6a09e667U;c->h[1]=0xbb67ae85U;c->h[2]=0x3c6ef372U;c->h[3]=0xa54ff53aU;c->h[4]=0x510e527fU;c->h[5]=0x9b05688cU;c->h[6]=0x1f83d9abU;c->h[7]=0x5be0cd19U;c->bits=0;c->used=0;}
static void sha256_update(SHA256CTX*c,const U8*p,U32 n){U32 take;c->bits+=(U64)n*8ULL;while(n){take=64-c->used;if(take>n)take=n;{U32 i;for(i=0;i<take;i++)c->block[c->used+i]=p[i];}c->used+=take;p+=take;n-=take;if(c->used==64){sha256_transform(c,c->block);c->used=0;}}}
static void sha256_final(SHA256CTX*c,U8 out[32]){U32 i;c->block[c->used++]=0x80;if(c->used>56){while(c->used<64)c->block[c->used++]=0;sha256_transform(c,c->block);c->used=0;}while(c->used<56)c->block[c->used++]=0;for(i=0;i<8;i++)c->block[63-i]=(U8)(c->bits>>(8*i));sha256_transform(c,c->block);for(i=0;i<8;i++)store_be32(out+4*i,c->h[i]);}

static const char* detect_magic(void){
 if(first_count>=2&&first_bytes[0]=='M'&&first_bytes[1]=='Z')return "PE/DOS executable";
 if(first_count>=4&&first_bytes[0]==0x7f&&first_bytes[1]=='E'&&first_bytes[2]=='L'&&first_bytes[3]=='F')return "ELF executable";
 if(first_count>=4&&first_bytes[0]=='P'&&first_bytes[1]=='K'&&first_bytes[2]==3&&first_bytes[3]==4)return "ZIP archive / Office package";
 if(first_count>=5&&first_bytes[0]=='%'&&first_bytes[1]=='P'&&first_bytes[2]=='D'&&first_bytes[3]=='F'&&first_bytes[4]=='-')return "PDF document";
 if(first_count>=8&&first_bytes[0]==0x89&&first_bytes[1]=='P'&&first_bytes[2]=='N'&&first_bytes[3]=='G')return "PNG image";
 if(first_count>=3&&first_bytes[0]==0xff&&first_bytes[1]==0xd8&&first_bytes[2]==0xff)return "JPEG image";
 if(first_count>=6&&first_bytes[0]=='G'&&first_bytes[1]=='I'&&first_bytes[2]=='F')return "GIF image";
 if(first_count>=4&&first_bytes[0]=='R'&&first_bytes[1]=='I'&&first_bytes[2]=='F'&&first_bytes[3]=='F')return "RIFF container";
 if(first_count>=4&&first_bytes[0]==0xd0&&first_bytes[1]==0xcf&&first_bytes[2]==0x11&&first_bytes[3]==0xe0)return "OLE compound document";
 if(first_count>=4&&first_bytes[0]==0xca&&first_bytes[1]==0xfe&&first_bytes[2]==0xba&&first_bytes[3]==0xbe)return "Java class";
 if(first_count>=2&&first_bytes[0]=='#'&&first_bytes[1]=='!')return "Script with shebang";
 return "Unknown / plain data";
}
static int is_exec_ext(void){return ends_i(filename,".exe")||ends_i(filename,".dll")||ends_i(filename,".scr")||ends_i(filename,".com")||ends_i(filename,".sys")||ends_i(filename,".cpl");}
static int is_script_ext(void){return ends_i(filename,".bat")||ends_i(filename,".cmd")||ends_i(filename,".ps1")||ends_i(filename,".vbs")||ends_i(filename,".js")||ends_i(filename,".jse")||ends_i(filename,".wsf")||ends_i(filename,".hta");}
static int has_double_extension(void){U32 i,dots=0;for(i=0;filename[i];i++)if(filename[i]=='.')dots++;return dots>=2&&(is_exec_ext()||is_script_ext());}

void start(void){
 HANDLE in=GetStdHandle(STD_INPUT_HANDLE),out=GetStdHandle(STD_OUTPUT_HANDLE);DWORD nread=0;U32 expected=0,i,unique=0,print_pct=0,risk=0;int ok=0;MD5CTX m5;SHA1CTX s1;SHA256CTX s256;U8 d5[16],d1[20],d256[32];const char*magic;int pe,elf,script,double_ext,mismatch=0;
 DWORD got=GetEnvironmentVariableA("CONTENT_LENGTH",env_buffer,ENV_BUFFER_SIZE-1);if(got==0||got>=ENV_BUFFER_SIZE-1)send_error(out,"Missing or invalid CONTENT_LENGTH.");env_buffer[got]=0;expected=parse_u32(env_buffer,&ok);if(!ok||expected==0)send_error(out,"The uploaded file is empty.");if(expected>MAX_FILE_SIZE)send_error(out,"The file exceeds the 32 MiB VirusBASIC limit.");
 got=GetEnvironmentVariableA("QUERY_STRING",env_buffer,ENV_BUFFER_SIZE-1);if(got>=ENV_BUFFER_SIZE-1)got=ENV_BUFFER_SIZE-2;env_buffer[got]=0;decode_query_name(env_buffer);
 md5_init(&m5);sha1_init(&s1);sha256_init(&s256);first_count=0;total_size=0;printable_count=0;nul_count=0;for(i=0;i<256;i++)unique_table[i]=0;
 while(total_size<expected){U32 want=READ_BUFFER_SIZE;U32 left=expected-total_size;if(left<want)want=left;nread=0;if(!ReadFile(in,read_buffer,want,&nread,NULL))send_error(out,"Could not read the CGI request body.");if(nread==0)break;md5_update(&m5,read_buffer,nread);sha1_update(&s1,read_buffer,nread);sha256_update(&s256,read_buffer,nread);for(i=0;i<nread;i++){U8 c=read_buffer[i];if(first_count<32)first_bytes[first_count++]=c;unique_table[c]=1;if(c==0)nul_count++;if((c>=32&&c<=126)||c==9||c==10||c==13)printable_count++;}total_size+=nread;}
 if(total_size!=expected)send_error(out,"The request body ended before CONTENT_LENGTH bytes were received.");md5_final(&m5,d5);sha1_final(&s1,d1);sha256_final(&s256,d256);for(i=0;i<256;i++)if(unique_table[i])unique++;if(total_size)print_pct=(printable_count*100U)/total_size;magic=detect_magic();pe=first_count>=2&&first_bytes[0]=='M'&&first_bytes[1]=='Z';elf=first_count>=4&&first_bytes[0]==0x7f&&first_bytes[1]=='E'&&first_bytes[2]=='L'&&first_bytes[3]=='F';script=is_script_ext();double_ext=has_double_extension();if(pe&&!is_exec_ext())mismatch=1;if(!pe&&is_exec_ext())mismatch=1;if(elf&&!(ends_i(filename,".elf")||ends_i(filename,".so")||ends_i(filename,".bin")))mismatch=1;if(pe)risk+=20;if(elf)risk+=15;if(script)risk+=15;if(double_ext)risk+=25;if(mismatch)risk+=20;if(print_pct<10&&unique>180)risk+=10;if(total_size<64)risk+=5;if(risk>100)risk=100;
 out_reset();out_text("Content-Type: application/json; charset=utf-8\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n\r\n{");out_text("\"ok\":true,\"name\":\"");out_json(filename);out_text("\",\"size\":");out_u32(total_size);out_text(",\"md5\":\"");out_hex(d5,16);out_text("\",\"sha1\":\"");out_hex(d1,20);out_text("\",\"sha256\":\"");out_hex(d256,32);out_text("\",\"magic\":\"");out_json(magic);out_text("\",\"unique_bytes\":");out_u32(unique);out_text(",\"printable_percent\":");out_u32(print_pct);out_text(",\"nul_bytes\":");out_u32(nul_count);out_text(",\"pe\":");out_text(pe?"true":"false");out_text(",\"script_extension\":");out_text(script?"true":"false");out_text(",\"double_extension\":");out_text(double_ext?"true":"false");out_text(",\"extension_mismatch\":");out_text(mismatch?"true":"false");out_text(",\"attention_score\":");out_u32(risk);out_text(",\"stored\":false}");write_all(out,output,out_pos);ExitProcess(0);
}
