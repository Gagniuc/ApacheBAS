        .section .idata$2,"dw"
        .p2align 2
dll0_descriptor:
        .rva dll0_ilt
        .long 0
        .long 0
        .rva dll0_name
        .rva dll0_iat

        .section .idata$3,"dw"
        .zero 20

        .section .idata$4,"dw"
        .p2align 2
dll0_ilt:
        .rva hn_ExitProcess
        .rva hn_GetStdHandle
        .rva hn_ReadFile
        .rva hn_WriteFile
        .rva hn_GetEnvironmentVariableA
        .long 0

        .section .idata$5,"dw"
        .p2align 2
dll0_iat:
        .globl __imp__ExitProcess@4
__imp__ExitProcess@4:
        .rva hn_ExitProcess
        .globl __imp__GetStdHandle@4
__imp__GetStdHandle@4:
        .rva hn_GetStdHandle
        .globl __imp__ReadFile@20
__imp__ReadFile@20:
        .rva hn_ReadFile
        .globl __imp__WriteFile@20
__imp__WriteFile@20:
        .rva hn_WriteFile
        .globl __imp__GetEnvironmentVariableA@12
__imp__GetEnvironmentVariableA@12:
        .rva hn_GetEnvironmentVariableA
        .long 0

        .section .idata$6,"dw"
        .p2align 1
hn_ExitProcess:
        .short 0
        .asciz "ExitProcess"
        .p2align 1
hn_GetStdHandle:
        .short 0
        .asciz "GetStdHandle"
        .p2align 1
hn_ReadFile:
        .short 0
        .asciz "ReadFile"
        .p2align 1
hn_WriteFile:
        .short 0
        .asciz "WriteFile"
        .p2align 1
hn_GetEnvironmentVariableA:
        .short 0
        .asciz "GetEnvironmentVariableA"
        .p2align 1
dll0_name:
        .asciz "KERNEL32.dll"
        .p2align 1
