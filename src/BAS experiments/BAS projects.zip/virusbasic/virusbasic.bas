<?bas
ACTION$ = LCASE$(TRIM$(POST_ACTION$))
IF ACTION$ = "check" THEN GOTO API_CHECK
GOTO PAGE_MAIN

API_CHECK:
MD5$ = LCASE$(TRIM$(POST_MD5$))
SHA1$ = LCASE$(TRIM$(POST_SHA1$))
SHA256$ = LCASE$(TRIM$(POST_SHA256$))
FILE_NAME$ = LEFT$(TRIM$(POST_NAME$), 240)
MAGIC$ = LEFT$(TRIM$(POST_MAGIC$), 120)
SCORE = VAL(POST_SCORE$)
IF LEN(MD5$) <> 32 OR LEN(SHA1$) <> 40 OR LEN(SHA256$) <> 64 THEN GOTO API_BAD
SIGNATURES$ = LCASE$(READFILE$("data/signatures.txt"))
KNOWN = 0
IF INSTR(SIGNATURES$, SHA256$) > 0 THEN KNOWN = 1
IF INSTR(SIGNATURES$, MD5$) > 0 THEN KNOWN = 1
VERDICT$ = "No local signature match"
IF KNOWN THEN VERDICT$ = "Known local signature"
IF KNOWN = 0 AND SCORE >= 50 THEN VERDICT$ = "No signature match; several static indicators"
IF KNOWN = 0 AND SCORE >= 25 AND SCORE < 50 THEN VERDICT$ = "No signature match; review suggested"
KNOWN_JSON$ = "false"
IF KNOWN THEN KNOWN_JSON$ = "true"
PRINT "@@CONTENT-TYPE application/json; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
PRINT "@@HEADER X-Content-Type-Options: nosniff"
PRINT "{""ok"":true,""known"":"; KNOWN_JSON$; ",""verdict"":"""; JSON$(VERDICT$); """,""engines"":1,""detections"":"; STR$(KNOWN); "}"
END

API_BAD:
PRINT "@@STATUS 400"
PRINT "@@CONTENT-TYPE application/json; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
PRINT "{""ok"":false,""error"":""Invalid hash result.""}"
END

PAGE_MAIN:
PRINT "@@CONTENT-TYPE text/html; charset=utf-8"
PRINT "@@HEADER Cache-Control: no-store"
PRINT "@@HEADER X-Content-Type-Options: nosniff"
PRINT "@@HEADER X-Frame-Options: DENY"
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>VirusBASIC · local file analysis</title>
<style>
*{box-sizing:border-box}html{background:#0b111b;color:#e6edf3;font-family:Inter,Segoe UI,Arial,sans-serif}body{margin:0;background:radial-gradient(circle at 20% 0,#162a43 0,#0b111b 43%,#070b12 100%);min-height:100vh}.top{height:70px;border-bottom:1px solid #26364a;background:#0d1522dd;backdrop-filter:blur(12px);display:flex;align-items:center}.topin{width:min(1160px,calc(100% - 32px));margin:auto;display:flex;align-items:center;justify-content:space-between}.brand{font-size:23px;font-weight:850;display:flex;align-items:center;gap:12px}.mark{width:42px;height:42px;border-radius:12px;background:linear-gradient(135deg,#2f81f7,#55d38a);display:grid;place-items:center;color:#07101d;font-weight:950}.sub{font-size:13px;color:#8da2ba}.page{width:min(1160px,calc(100% - 32px));margin:34px auto 70px}.hero{display:grid;grid-template-columns:1.1fr .9fr;gap:24px}.panel{background:#111c2b;border:1px solid #2a3d54;border-radius:18px;box-shadow:0 22px 50px #0007}.intro{padding:34px}.intro h1{font-size:46px;line-height:1.02;margin:0 0 16px;letter-spacing:-2px}.intro p{font-size:17px;line-height:1.65;color:#a9bbcf;max-width:650px}.pills{display:flex;gap:8px;flex-wrap:wrap;margin-top:22px}.pill{padding:7px 11px;border:1px solid #30465f;border-radius:999px;color:#b7c9dd;font-size:12px;background:#172539}.upload{padding:25px}.drop{min-height:270px;border:2px dashed #3a5877;border-radius:15px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:24px;transition:.2s;background:#0b1522}.drop.drag{border-color:#55d38a;background:#10271f}.shield{font-size:54px}.drop h2{margin:10px 0 6px}.drop p{margin:0;color:#8ea4bb;line-height:1.5}.filebtn,.scanbtn{border:0;border-radius:10px;padding:11px 17px;font-weight:800;cursor:pointer}.filebtn{background:#21334a;color:#dbeafe;margin-top:17px;display:inline-block}.scanbtn{width:100%;margin-top:13px;background:#2f81f7;color:white;font-size:15px}.scanbtn:disabled{opacity:.45;cursor:not-allowed}#file{display:none}.selected{margin-top:12px;color:#c9d8e7;font-size:13px;min-height:18px}.progress{height:7px;background:#22334a;border-radius:99px;overflow:hidden;margin-top:14px;display:none}.bar{height:100%;width:0;background:linear-gradient(90deg,#2f81f7,#55d38a);transition:width .12s}.status{margin-top:12px;color:#91a8c0;font-size:13px;min-height:18px}.results{display:none;margin-top:24px}.summary{display:grid;grid-template-columns:210px 1fr;gap:18px}.scorebox{padding:22px;display:grid;place-items:center;text-align:center}.ring{width:142px;height:142px;border-radius:50%;display:grid;place-items:center;background:conic-gradient(#55d38a 0deg,#55d38a 0deg,#24354a 0deg);position:relative}.ring:after{content:"";position:absolute;inset:13px;border-radius:50%;background:#111c2b}.ringtext{position:relative;z-index:2}.ratio{font-size:31px;font-weight:900}.small{font-size:12px;color:#8ea4bb}.verdict{padding:24px}.verdict h2{margin:0 0 8px;font-size:25px}.verdict p{margin:0;color:#9db0c4;line-height:1.55}.good{color:#55d38a}.bad{color:#ff6b7a}.warn{color:#ffcc66}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:18px}.card{padding:21px}.card h3{margin:0 0 15px}.row{display:grid;grid-template-columns:145px 1fr;gap:12px;padding:10px 0;border-top:1px solid #24364b}.row:first-of-type{border-top:0}.key{color:#8ea4bb}.val{overflow-wrap:anywhere}.hash{font-family:Consolas,monospace;font-size:12px;color:#c8daf0}.flag{display:inline-block;padding:3px 7px;border-radius:6px;background:#203249;margin:2px;font-size:12px}.actions{display:flex;gap:10px;margin-top:18px;flex-wrap:wrap}.action{color:#dbeafe;text-decoration:none;background:#21334a;padding:9px 12px;border-radius:9px;border:1px solid #324962;font-weight:700;font-size:13px}.notice{margin-top:20px;color:#7f95ad;font-size:12px;line-height:1.6}.error{color:#ff8a95}.footer{text-align:center;color:#607891;font-size:12px;margin-top:35px}@media(max-width:850px){.hero,.summary,.grid{grid-template-columns:1fr}.intro h1{font-size:38px}.sub{display:none}.page{width:min(100% - 20px,1160px)}}
</style>
</head>
<body>
<header class="top"><div class="topin"><div class="brand"><span class="mark">VB</span>VirusBASIC</div><div class="sub">Local VirusTotal-style analysis powered by ApacheBAS</div></div></header>
<main class="page">
<section class="hero">
<div class="panel intro"><h1>Inspect a file<br>without executing it.</h1><p>VirusBASIC sends the selected file to a small native CGI helper. The helper calculates MD5, SHA-1 and SHA-256 in memory, recognizes common file signatures and returns the result to ApacheBAS for a local signature check.</p><div class="pills"><span class="pill">No sample execution</span><span class="pill">Not stored on disk</span><span class="pill">32 MiB maximum</span><span class="pill">Local signature database</span></div></div>
<div class="panel upload"><div id="drop" class="drop"><div class="shield">🛡️</div><h2>Select a file</h2><p>Drag and drop any file here or browse from your computer.</p><label class="filebtn" for="file">Choose file</label><input id="file" type="file"><div id="selected" class="selected">No file selected.</div></div><button id="scan" class="scanbtn" disabled>Analyze file</button><div id="progress" class="progress"><div id="bar" class="bar"></div></div><div id="status" class="status">Install the supplied CGI helper before the first scan.</div></div>
</section>
<section id="results" class="results">
<div class="summary"><div class="panel scorebox"><div id="ring" class="ring"><div class="ringtext"><div id="ratio" class="ratio">0 / 1</div><div class="small">local signatures</div></div></div></div><div class="panel verdict"><h2 id="verdict">Analysis complete</h2><p id="verdictText"></p><div class="actions"><a id="vt" class="action" target="_blank" rel="noopener">Search SHA-256 on VirusTotal</a><a class="action" href="#" id="again">Analyze another file</a></div></div></div>
<div class="grid"><div class="panel card"><h3>File details</h3><div class="row"><div class="key">Name</div><div id="rName" class="val"></div></div><div class="row"><div class="key">Size</div><div id="rSize" class="val"></div></div><div class="row"><div class="key">Detected type</div><div id="rMagic" class="val"></div></div><div class="row"><div class="key">Static attention</div><div id="rScore" class="val"></div></div><div class="row"><div class="key">Indicators</div><div id="rFlags" class="val"></div></div></div>
<div class="panel card"><h3>Cryptographic hashes</h3><div class="row"><div class="key">MD5</div><div id="rMd5" class="val hash"></div></div><div class="row"><div class="key">SHA-1</div><div id="rSha1" class="val hash"></div></div><div class="row"><div class="key">SHA-256</div><div id="rSha256" class="val hash"></div></div><div class="row"><div class="key">Byte diversity</div><div id="rUnique" class="val"></div></div><div class="row"><div class="key">Printable data</div><div id="rPrintable" class="val"></div></div></div></div>
<div class="notice">This is a primitive local triage tool, not a replacement for VirusTotal or a full antivirus engine. A missing local signature does not mean that a file is safe. The native helper does not save or execute the uploaded file.</div>
</section>
<div class="footer">VirusBASIC v1.0 · ApacheBAS-ASM</div>
</main>
<script>
const fileInput=document.getElementById('file'),drop=document.getElementById('drop'),scan=document.getElementById('scan'),selected=document.getElementById('selected'),statusBox=document.getElementById('status'),progress=document.getElementById('progress'),bar=document.getElementById('bar'),results=document.getElementById('results');let currentFile=null;
function choose(file){currentFile=file||null;if(!file){selected.textContent='No file selected.';scan.disabled=true;return}selected.textContent=file.name+' · '+formatBytes(file.size);scan.disabled=file.size===0||file.size>33554432;statusBox.textContent=scan.disabled?'File must be between 1 byte and 32 MiB.':'Ready to analyze.'}
fileInput.addEventListener('change',()=>choose(fileInput.files[0]));['dragenter','dragover'].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.classList.add('drag')}));['dragleave','drop'].forEach(e=>drop.addEventListener(e,x=>{x.preventDefault();drop.classList.remove('drag')}));drop.addEventListener('drop',e=>choose(e.dataTransfer.files[0]));
function formatBytes(n){if(n<1024)return n+' bytes';if(n<1048576)return(n/1024).toFixed(1)+' KiB';return(n/1048576).toFixed(2)+' MiB'}
function helperScan(file){return new Promise((resolve,reject)=>{const xhr=new XMLHttpRequest();xhr.open('POST','/cgi-bin/VirusBASICHash.exe?name='+encodeURIComponent(file.name));xhr.setRequestHeader('Content-Type','application/octet-stream');xhr.upload.onprogress=e=>{if(e.lengthComputable)bar.style.width=Math.round(e.loaded/e.total*100)+'%'};xhr.onerror=()=>reject(new Error('The CGI hashing helper could not be reached. Run INSTALL_HELPER.cmd.'));xhr.onload=()=>{try{const r=JSON.parse(xhr.responseText);if(!r.ok)throw new Error(r.error||'Hashing failed.');resolve(r)}catch(e){reject(new Error('Invalid helper response. Verify /cgi-bin/VirusBASICHash.exe.'))}};xhr.send(file)})}
async function localCheck(r){const body=new URLSearchParams({action:'check',name:r.name,md5:r.md5,sha1:r.sha1,sha256:r.sha256,magic:r.magic,score:String(r.attention_score)});const response=await fetch('virusbasic.bas',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});const data=await response.json();if(!data.ok)throw new Error(data.error||'ApacheBAS signature check failed.');return data}
scan.addEventListener('click',async()=>{if(!currentFile)return;scan.disabled=true;progress.style.display='block';bar.style.width='2%';statusBox.className='status';statusBox.textContent='Uploading to the local hashing helper...';try{const r=await helperScan(currentFile);bar.style.width='100%';statusBox.textContent='Hashes calculated. Asking ApacheBAS to check local signatures...';const check=await localCheck(r);render(r,check);statusBox.textContent='Analysis complete. The file was not stored.'}catch(e){statusBox.className='status error';statusBox.textContent=e.message}finally{scan.disabled=false;setTimeout(()=>progress.style.display='none',700)}});
function render(r,c){results.style.display='block';document.getElementById('ratio').textContent=c.detections+' / '+c.engines;const title=document.getElementById('verdict');title.textContent=c.verdict;title.className=c.known?'bad':(r.attention_score>=50?'warn':'good');document.getElementById('verdictText').textContent=c.known?'The hash exists in the local signature database. Do not execute the sample.':(r.attention_score>=50?'No local hash match was found, but the filename or file structure contains indicators that deserve manual review.':'No local signature match was found. This is not proof that the file is harmless.');document.getElementById('rName').textContent=r.name;document.getElementById('rSize').textContent=formatBytes(r.size);document.getElementById('rMagic').textContent=r.magic;document.getElementById('rScore').textContent=r.attention_score+' / 100';document.getElementById('rMd5').textContent=r.md5;document.getElementById('rSha1').textContent=r.sha1;document.getElementById('rSha256').textContent=r.sha256;document.getElementById('rUnique').textContent=r.unique_bytes+' of 256 byte values';document.getElementById('rPrintable').textContent=r.printable_percent+'% · '+r.nul_bytes+' NUL bytes';const flags=[];if(r.pe)flags.push('PE executable');if(r.script_extension)flags.push('script extension');if(r.double_extension)flags.push('double extension');if(r.extension_mismatch)flags.push('extension mismatch');if(!flags.length)flags.push('no basic naming mismatch');document.getElementById('rFlags').innerHTML=flags.map(x=>'<span class="flag">'+x+'</span>').join('');const deg=c.known?360:Math.min(360,r.attention_score*3.6);document.getElementById('ring').style.background='conic-gradient('+(c.known?'#ff5d70':'#55d38a')+' 0deg '+deg+'deg,#24354a '+deg+'deg)';document.getElementById('vt').href='https://www.virustotal.com/gui/file/'+r.sha256;results.scrollIntoView({behavior:'smooth',block:'start'})}
document.getElementById('again').addEventListener('click',e=>{e.preventDefault();fileInput.value='';choose(null);results.style.display='none';statusBox.className='status';statusBox.textContent='Select another file.';window.scrollTo({top:0,behavior:'smooth'})});
</script>
</body>
</html>
