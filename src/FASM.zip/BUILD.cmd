@echo off
setlocal
cd /d "%~dp0"

if exist "%~dp0fasm.exe" (
    set "FASM=%~dp0fasm.exe"
) else (
    where fasm.exe >nul 2>nul
    if errorlevel 1 (
        echo fasm.exe was not found.
        echo Put fasm.exe beside BUILD.cmd or add it to PATH.
        pause
        exit /b 1
    )
    set "FASM=fasm.exe"
)

"%FASM%" "%~dp0ApacheBAS.asm" "%~dp0ApacheBAS.exe"
if errorlevel 1 (
    echo.
    echo Build failed.
    pause
    exit /b 1
)

echo.
echo Build successful: %~dp0ApacheBAS.exe
pause
