ApacheBAS-ASM v0.2.0
====================

Single-source FASM CGI runtime for Apache/XAMPP.
The runtime remains entirely inside ApacheBAS.asm.

Added since v0.1.1
------------------
- integer expression precedence and parentheses
- comparisons and Boolean/bitwise operators
- LET and scalar DIM
- labels, GOTO / GO TO
- GOSUB / RETURN
- FOR / NEXT, including STEP
- WHILE / WEND
- DO / LOOP in pre-test and post-test forms
- one-line IF / THEN / ELSE
- SLEEP, CLS, CLEAR, STOP and END
- larger variable table and program-line representation

Not yet implemented
-------------------
- allocated arrays and array indexing
- floating-point scientific functions
- DATA / READ / RESTORE
- full 44/44 compatibility

Build
-----
Place fasm.exe beside BUILD.cmd and run BUILD.cmd, or use:

    fasm ApacheBAS.asm ApacheBAS.exe

Installation
------------
1. Stop Apache.
2. Back up C:\xampp\cgi-bin\ApacheBAS.exe.
3. Copy the new ApacheBAS.exe there.
4. Start Apache.
5. Copy tests\v02-control-flow.bas into an Apache-served directory and open it.

This is a development milestone. Compile it locally first and report the first
FASM error verbatim if compilation stops.
